#!/bin/bash
function usage()
{
	echo "Usage: ./countDetectedFunc.sh -d DIR_NAME -o OUTPUT_FILE" 
}

if [ "$#" -lt 4 ]; then
	usage
	exit 1
fi

while [ "$1" != "" ]; do
	case $1 in
		-d )	shift
			DIR_NAME=$1
			;;
		-o )	shift
			OUTPUT_FILE=$1
			;;
		* )	usage
			exit 1
	esac
	shift
done

#for f in $DIR_NAME/*_Loop*.txt; do 
#  awk '/^Loop Exit Condition is Data Related/{print FILENAME}' "$f" >> $OUTPUT_FILE; 
#done

for f in $DIR_NAME/*_Loop*.txt; do 
  num=$(grep -nr "Loop Exit Condition is Data Related" "$f" | wc -l)
  if [ "$num" -gt 0 ]; then
    echo $f >> $OUTPUT_FILE; 
  fi
done
