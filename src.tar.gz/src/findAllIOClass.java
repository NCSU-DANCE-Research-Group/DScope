
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import java.util.regex.PatternSyntaxException;

import datastruct.DiGraphMatrix;
import datastruct.Graph;
//import datastruct.MultiTree;


/* This class is original from the numberizeALLFuncReturn class.
 * In numberizeALLFuncReturn, we didn't consider the combinations of interfaces, abstract classes, super/subclasses. 
 * */
public class findAllIOClass {

	
	static String analysisClassPath = "";
	static String abstractClassPath = "";
	static String interfacePath = "";
	static String outputFile="";
	static String splitSymb = "=";
	/*If the interface is IO class, then the implements is also IO class*/
	/*If the super is the IO class, then the sub is also IO class*/
	// key is the implementations/subclass, value is the interface/superclass
	static Map<String, Set<String>> classDependMap = new HashMap<String, Set<String>>();
	// key is the interface/superclass, value is the implementations/subclass
	static Map<String, Set<String>> classDependMapR = new HashMap<String, Set<String>>();
	static Map<String, Boolean> ioClassMap = new HashMap<String, Boolean>();
	
	public static Logger logger = Logger.getLogger(findAllIOClass.class.getName());
	
	public static void main(String[] args){
		args = new String[] {"-Classpath", 
				             "/home/ting/DataLoopBugDetection/ResultIOClasses/cassandra.io.func/classes",
				             "-AbstractClassPath",
				             "/home/ting/DataLoopBugDetection/ResultIOClasses/cassandra.io.func/abstractClasses",
				             "-InterfacePath",
				             "/home/ting/DataLoopBugDetection/ResultIOClasses/cassandra.io.func/interfaces",
				             "-output", 
				             "/home/ting/DataLoopBugDetection/ResultIOClasses/cassandra.io.func/cassandra.io.class.log"
				            };
		handleArgs(args);
		
		File outfile = new File(outputFile);
	    if (outfile.exists()) {
	    	outfile.delete();     
	    }
		readAbstractClasses();
		readInterfaces();
		readClasses();
		propogateIO();
		write2File();
	}

	
	private static void readAbstractClasses(){
		logger.info("starting reading abstract class files...");
		readAbstractClassesInterfaces(abstractClassPath);
		logger.info("finish reading abstract class files...");
	}
	
	private static void readInterfaces(){
		logger.info("starting reading interface files...");
		readAbstractClassesInterfaces(interfacePath);
		logger.info("finish reading interface files...");
	}
	
	private static void readClasses(){
		logger.info("starting reading class files...");
		readAbstractClassesInterfaces(analysisClassPath);
		logger.info("finish reading class files...");
	}
	
	private static void readAbstractClassesInterfaces(String pathName){
		if(pathName != null && pathName != ""){
			List<String> files = new ArrayList<String>();
			File folder = new File(pathName);
			File[] listofFiles = folder.listFiles();
			for(File file : listofFiles){
			    if (file.isFile()) {
			        files.add(file.getName());
			    }
			}
			for(String file : files){
				String className = file.replace(".txt", "");
				ioClassMap.put(className, false);
				InputStream instream = null;
				BufferedReader reader = null;
				String line = "";
				try {
					instream = new FileInputStream(pathName+"/"+file);
					reader = new BufferedReader(new InputStreamReader(instream));
					while ((line = reader.readLine()) != null) {
						if(line.contains("extends=")){
							String superClass = line.replace("extends=","");
							if(!superClass.equals("java.lang.Object")){ //we do not consider java.lang.Object, cause its the root of every class.
								                                        //every class has java.lang.Object as the super class.
								if(classDependMapR.containsKey(superClass)){ // key is the interface/superclass, value is the implementations/subclass
									Set<String> subclasses = classDependMapR.get(superClass);
									subclasses.add(className);
									classDependMapR.put(superClass, subclasses);
								} else {
									Set<String> subclasses = new HashSet<String>();
									subclasses.add(className);
									classDependMapR.put(superClass, subclasses);
								}
								if(classDependMap.containsKey(className)){ // key is the implementations/subclass, value is the interface/superclass
									Set<String> superclasses = classDependMap.get(className);
									superclasses.add(superClass);
									classDependMap.put(className, superclasses);
								} else {
									Set<String> superclasses = new HashSet<String>();
									superclasses.add(superClass);
									classDependMap.put(className, superclasses);
								}
							}
						} else if(line.contains("implements=")){
							String[] allInterfaceSplit = line.split("implements=")[1].split(",");
							Set<String> allimplements = new HashSet<String>();
							for(int i = 0; i < allInterfaceSplit.length; i++){
								String interfaceKlass = allInterfaceSplit[i];
								allimplements.add(interfaceKlass);
								if(classDependMapR.containsKey(interfaceKlass)){// key is the interface/superclass, value is the implementations/subclass
									Set<String> allimplementations = classDependMapR.get(interfaceKlass);
									allimplementations.add(className);
									classDependMapR.put(interfaceKlass, allimplementations);
								} else {
									Set<String> allimplementations = new HashSet<String>();
									allimplementations.add(className);
									classDependMapR.put(interfaceKlass, allimplementations);
								}
								
							}
							if(classDependMap.containsKey(className)){// key is the implementations/subclass, value is the interface/superclass
								Set<String> implementS = classDependMap.get(className);
								implementS.addAll(allimplements);
								classDependMap.put(className, implementS);
								
							} else {
								Set<String> implementS = new HashSet<String>();
								implementS.addAll(allimplements);
								classDependMap.put(className, implementS);
							}
						}						
					}
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					try {
						reader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
	
	private static void propogateIO(){
		Iterator<Entry<String, Boolean>> ioClassIt = ioClassMap.entrySet().iterator();
		Entry<String, Boolean> ioClassEntry = null;
		while(ioClassIt.hasNext()){
			ioClassEntry = ioClassIt.next();
			String className = ioClassEntry.getKey();
			boolean isIO = ioClassEntry.getValue();
			if(!isIO){
				if(isIOClass(className)){
					ioClassMap.put(className, true);
				} else if(DFS(className)){
					ioClassMap.put(className, true);
				}
			}
		}
	}
	
	private static boolean DFS(String className){
		if(classDependMap.containsKey(className)){
			Set<String> depended = classDependMap.get(className);
			boolean isIO = false;
			for(String depend : depended){
				if(isIOClass(depend)){
					return true;
				} else {
					isIO = (isIO || DFS(depend));
					if(isIO)
						return true;
				}
			}
		}
		return false;
	}
	
	private static boolean isIOClass(String className){
		if(className.startsWith("java.io.")){
			return true;
		} else{
			return false;
		}
	}
	
	private static void write2File(){
		Iterator<Entry<String, Boolean>> ioClassIt = ioClassMap.entrySet().iterator();
		Entry<String, Boolean> ioClassEntry = null;
		String outputStr="";
		while(ioClassIt.hasNext()){
			ioClassEntry = ioClassIt.next();
			String className = ioClassEntry.getKey();
			boolean isIO = ioClassEntry.getValue();
			if(isIO){
				outputStr += className + "\n";
			}
		}
		write2File(outputFile, outputStr);
	}
	
	
	private static void write2File(String filename, String content){
		File fout = new File(filename);
		FileOutputStream fos = null;
		BufferedWriter bw = null;
		try {
			fos = new FileOutputStream(fout, true);
			bw = new BufferedWriter(new OutputStreamWriter(fos));
			bw.write(content);
			bw.flush();
			fos.close();
			bw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void handleArgs(String []args)
    {
        int argIndex = 0;
        while(argIndex < args.length)
        {
            String current = args[argIndex];
            if(current.compareTo("-h") == 0)
            {
                printUsage();
                System.exit(-1);
            } else if(current.compareTo("-Classpath") == 0){
            	argIndex++;
            	analysisClassPath = args[argIndex];
            } else if(current.compareTo("-AbstractClassPath") == 0){
            	argIndex++;
            	abstractClassPath = args[argIndex];
            } else if(current.compareTo("-InterfacePath") == 0){
            	argIndex++;
            	interfacePath = args[argIndex];
            } else if(current.compareTo("-output") == 0){
            	argIndex++;
            	outputFile = args[argIndex];
            } else {
                System.out.println("current arg:" + current);
                System.out.println("Invalid configuration params, use -h for usage");
                System.exit(-1);
            }
            argIndex++;
        }
    }
	
    public static void printUsage()
    {
        System.out.println("java findAllJavaFuncReturn [options] "
        		+ "-Classpath analysisClassPath "
        		+ "-AbstractClassPath abstractClassPath "
        		+ "-InterfacePath interfacePath "
        		+ "-output outputFile");
        System.out.println("Valid options are:");
        System.out.println("-h print help and exit");
    }
    
}

