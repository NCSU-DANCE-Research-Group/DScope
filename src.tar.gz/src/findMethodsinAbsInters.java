

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import findAllJavaAppIOClass.handleJavaCollections;
import soot.ArrayType;
import soot.Body;
import soot.MethodOrMethodContext;
import soot.PackManager;
import soot.RefType;
import soot.Scene;
import soot.SceneTransformer;
import soot.SootClass;
import soot.SootField;
import soot.SootMethod;
import soot.Transform;
import soot.Type;
import soot.Unit;
import soot.UnitBox;
import soot.Value;
import soot.ValueBox;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.InvokeExpr;
import soot.jimple.Stmt;
import soot.jimple.internal.JAssignStmt;
import soot.jimple.internal.JInvokeStmt;
import soot.jimple.spark.SparkTransformer;
import soot.jimple.toolkits.callgraph.CHATransformer;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.ContextSensitiveCallGraph;
import soot.jimple.toolkits.callgraph.ContextSensitiveEdge;
import soot.jimple.toolkits.callgraph.Edge;
import soot.jimple.toolkits.callgraph.ReachableMethods;
import soot.jimple.toolkits.callgraph.Sources;
import soot.jimple.toolkits.callgraph.Targets;
import soot.jimple.toolkits.callgraph.ObjSensContextManager;
import soot.options.Options;
import soot.util.Chain;
import soot.util.queue.QueueReader;
import utilities.LoopUtils;
import utilities.MethodUtils;

/* This class is used to find all the methods in interfaces and abstract classes. 
 * It needs to be done using whole program analysis (slow) in soot.
 * This is because the methods in interfaces and abstract methods in abstract classes have no body statements,
 * thus, they can not be analyzed using BodyTransform (fast) in functionInvokeIOMain class.
 * */
public class findMethodsinAbsInters { 
	public static void main(final String[] args) {
		
		PackManager.v().getPack("wjtp").add(new Transform("wjtp.myTransform", new SceneTransformer() {
			protected void internalTransform(String phaseName, Map options) {
				  //CHATransformer.v().transform(); //cha
				  setSparkAnalysis();               //spark
				  //setSparkAnalysisPTA(); //it can cause "OutOfMemoryError: GC overhead limit exceeded"
				  Scene.v().loadNecessaryClasses();
				  //Scene.v().setEntryPoints(getAllMethods(args));
				  
//		          CallGraph cg = Scene.v().getCallGraph();
//		          ContextSensitiveCallGraph cscg = Scene.v().getContextSensitiveCallGraph();
		          
		          Map<SootClass, List<SootMethod>> class2MethodMap = getAllMethods(args);
		          Iterator<Entry<SootClass, List<SootMethod>>> it = class2MethodMap.entrySet().iterator();
		          Entry<SootClass, List<SootMethod>> entry = it.next();
		          List<SootMethod> methods = entry.getValue();
		          SootClass klass = entry.getKey();
//		          for(SootMethod entryPoint : methods){
//		        	  System.out.println("entryPoint: " + entryPoint);
//		          }
		          
//		          if(klass.isAbstract()){
//		        	  System.out.println("isAbstractClass=true");
//		          }
//		          if(klass.isInterface()){
//		        	  System.out.println("isInterface=true");
//		          }
		          
		          	if(klass.getInterfaceCount()>0){
						Chain<SootClass> interfaces = klass.getInterfaces();
						String interfaceKlasses = "";
						for(SootClass interfaceKlass : interfaces){
							interfaceKlasses += interfaceKlass.getName() + ",";
						}
						//if(interfaceKlasses.length()>0)
						interfaceKlasses = interfaceKlasses.substring(0, interfaceKlasses.length() - 1);//delete last ,
						System.out.println("implements="+interfaceKlasses);
					}
					if(klass.hasSuperclass()){//interface's super class is java.lang.Object, hasSuperclass()==false
						// Class java.lang.Object is the root of the class hierarchy.
						// Every class has java.lang.Object as a superclass.
						SootClass superClass = klass.getSuperclass();
						System.out.println("extends="+superClass.getName());
					}
		          
		          for(SootMethod method : methods){
		        	  if(method.isAbstract()){
		        		  System.out.println("abstractMethod="+method.getSubSignature());
		        	  } else {
		        		  System.out.println("notAbsMethod=" + method.getSubSignature());
		        	  }
		          }
		          
			} 
		}));
		soot.Main.main(args); 
				
	} 
	
	

	
	
	public static String getMethodFullName(SootMethod method){
		String classname = method.getDeclaringClass().getName();
		// use signature instead to avoid same-name functions
		String methodname = method.getSubSignature(); 
		return classname + ":" + methodname;
	}
	
    public static String getPrex(String[] args) {
    	String klassName = args[args.length-1];
    	String[] splitK = klassName.split(".");
    	String prefix = "";
    	prefix = splitK[0] + "." + splitK[1] + "." + splitK[2]; //hard-coded, only choose the first 3 substring
        return prefix;
    }
    
    
    public static Map<SootClass, List<SootMethod>> getAllMethods(String[] args) {
    	String klassName = args[args.length-1];
        ArrayList<SootMethod> entrypoints = new ArrayList<SootMethod>();
        //for (String klassName : allClasses) {
            // klassName such as org.abc.MyClass
            Scene.v().forceResolve(klassName, SootClass.SIGNATURES);
            //Scene.v().forceResolve(klassName, SootClass.HIERARCHY);
            //Scene.v().forceResolve(klassName, SootClass.BODIES | SootClass.HIERARCHY | SootClass.SIGNATURES);
            SootClass klass = Scene.v().getSootClass(klassName);
            // adding all non-abstract method as entrypoint
            for (SootMethod m : klass.getMethods()) {
//              if (!m.isAbstract()) {
                entrypoints.add(m);
//              }
            }
         // }
        Map<SootClass, List<SootMethod>> class2MethodMap = new HashMap<SootClass, List<SootMethod>>();
        class2MethodMap.put(klass, entrypoints);
        return class2MethodMap;
    }
    
    private static void setSparkAnalysis() {
        HashMap<String,String> opt = new HashMap<String,String>();
        opt.put("enabled","true");
        opt.put("verbose","false");
        opt.put("vta","true");
        opt.put("on-fly-cg","true");
        opt.put("set-impl","double");
        opt.put("double-set-old","hybrid");
        opt.put("propagator", "iter");
        opt.put("double-set-new","hybrid");

        SparkTransformer.v().transform("",opt);
    }
} 
