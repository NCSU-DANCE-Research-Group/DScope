package truePositivePatterns;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import falsePositivePatterns.FPPattern3;
import soot.Body;
import soot.Local;
import soot.SootMethod;
import soot.UnitBox;
import soot.Value;
import soot.ValueBox;
import soot.jimple.AddExpr;
import soot.jimple.CmpExpr;
import soot.jimple.Constant;
import soot.jimple.DivExpr;
import soot.jimple.DoubleConstant;
import soot.jimple.Expr;
import soot.jimple.FieldRef;
import soot.jimple.IfStmt;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.IntConstant;
import soot.jimple.InvokeExpr;
import soot.jimple.JimpleBody;
import soot.jimple.LongConstant;
import soot.jimple.MulExpr;
import soot.jimple.Stmt;
import soot.jimple.SubExpr;
import soot.jimple.internal.JAssignStmt;
import soot.jimple.internal.JGotoStmt;
import soot.jimple.internal.JIfStmt;
import utilities.Condition;
import utilities.IOFunctionUtils;
import utilities.LoopPath;
import utilities.MethodUtils;


/* This is a very simple pattern.
 * 1. The condition is about a variable compare to 
 *    a constant value OR another variable whose range is determined. e.g., i < num
 * 2. upperBound/lower bound is unchanged.
 * 3. The stride is an I/O function's return---including Java I/O function and App I/O function. 
 * 4. This I/O function can return 0.
 * */
public class TPPattern1 {
//	private int ArrayUpBound = Integer.MAX_VALUE - 5;//http://stackoverflow.com/questions/3038392/do-java-arrays-have-a-maximum-size
	
	public boolean compareIOasStridePattern(Body body, LoopPath path1, List<LoopPath> paths, List<Stmt> methodAllStmts, PrintStream out){
		Map<Value, List<Stmt>> conVarMap = new HashMap<Value, List<Stmt>>();
		List<Condition> path1conds = path1.getconditions(); //all the condition in path1
		if(path1conds == null || path1conds.size() <= 0){
			return false;
		}
		//in the condition pair, the first one value is loop counter, the third one is the upper/lower bound
		List<ConditionPair<Value, String, Value>> conditionPairList = convertConds(path1conds, path1, out);
		
		//1. find the path statement triggers the I/O function, and those I/O function can return 0. 
//		List<Value> ioFunRetVals = new ArrayList<Value>();
		List<Stmt> path1stmts = path1.getpathStmt();
		Map<Value, List<String>> ioFunVar2RetMap = new HashMap<Value, List<String>>();
		for(Stmt path1stmt : path1stmts){
			if(path1stmt.containsInvokeExpr()){
				InvokeExpr expression = path1stmt.getInvokeExpr();
				String funcSig = expression.getMethodRef().toString();
				if(funcSig.startsWith("<") && funcSig.endsWith(">")){
					funcSig = funcSig.substring(1, funcSig.length()-1);
				}
				String className = funcSig.split(": ")[0];
				String methodName = funcSig.split(": ")[1].split(" ")[1];
				List<String> returns = getIOFuncRet(className, methodName);
				if(returns == null){
//					out.println("returns = null");
					continue;
				}
				for(ValueBox vb : path1stmt.getDefBoxes()){
					Value val = vb.getValue();
//					ioFunRetVals.add(val);
					ioFunVar2RetMap.put(val, returns);
				}
//				if(isIOfunRetzero(className, methodName)){
//					for(ValueBox vb : path1stmt.getDefBoxes()){
//						Value val = vb.getValue();
//						ioFunRetVals.add(val);
//					}
//				}
			}
		}
		if(ioFunVar2RetMap.size() == 0){
//			out.println("ioFunVar2RetMap.size() == 0");
			return false; //not invoke any IO function.
		}
		//2. find the variable matches the pattern 1 : var = var +/- IOfunRetZero
//		List<Value> matchedVars = new ArrayList<Value>();
		Map<Value, Value> lCAddIOFuncMap = new HashMap<Value, Value>();//key is the loopcounter variable, value is the io func ret var
		Map<Value, Value> lCSubIOFuncMap = new HashMap<Value, Value>();//key is the loopcounter variable, value is the io func ret var

		for(ConditionPair<Value, String, Value> condPair : conditionPairList){
			Value conVar1 = condPair.getFirst();
			for(Stmt path1stmt : path1stmts){
				List<ValueBox> defs = path1stmt.getDefBoxes();
				for(ValueBox def : defs){
					if(def.getValue().equals(conVar1)){
						List<ValueBox> uses = path1stmt.getUseBoxes();
//						boolean useIOfun = false;
						boolean containOthers = false;
						Value ioFunVar = null;
						for(ValueBox ub : uses){
							Value use = ub.getValue();
							if(use instanceof AddExpr){ // var = var + CONSTANT
								AddExpr ae = (AddExpr)use;
								Value lo = ae.getOp1();
								Value ro = ae.getOp2();
								if(lo.equals(conVar1) && ioFunVar2RetMap.containsKey(ro)){
									lCAddIOFuncMap.put(lo, ro);
								} else if(ro.equals(conVar1) && ioFunVar2RetMap.containsKey(lo)){
									lCAddIOFuncMap.put(ro, lo);
								}
							} else if(use instanceof SubExpr){
								SubExpr se = (SubExpr) use;
								Value lo = se.getOp1();
								Value ro = se.getOp2();
								if(lo.equals(conVar1) && ioFunVar2RetMap.containsKey(ro)){
									lCSubIOFuncMap.put(lo, ro);
								} else if(ro.equals(conVar1) && ioFunVar2RetMap.containsKey(lo)){
									lCSubIOFuncMap.put(ro, lo);
								}
							}
//							
//							if (use.equals(conVar1)){
//								continue;
//							} else if (ioFunVar2RetMap.containsKey(use)){
//								ioFunVar = use;
//							} else {
//								containOthers = true;
//							}
						}
//						if(ioFunVar != null && !containOthers){ //the RHS only contains itself, and IOfunRetZero
////							matchedVars.add(conVar1);
//							loopCounterIOFuncMap.put(conVar1, ioFunVar);
//						}
					}
				}
			}
		}
		if(lCAddIOFuncMap.size()==0 && lCSubIOFuncMap.size() == 0){
//			out.println("lCAddIOFuncMap.size()==0 && lCSubIOFuncMap.size() == 0");
			return false; //there is no var uses the IO function's return as the stride
		}
		
		//3. extract the values for the var +/- iofunction, this io function's range
		Map<Value, List<String>> satIOFunVar2RetMap = new HashMap<Value, List<String>>();
		for(ConditionPair<Value, String, Value> condPair : conditionPairList){
			Value conVar1 = condPair.getFirst();
			Value conVar3 = condPair.getThird();
			if(lCAddIOFuncMap.containsKey(conVar1)){ //if the condition variable is var = var + IOfunction
				if(isUnchanged(methodAllStmts, conVar3, paths, out)){//do we really need all paths, or just current path?
					String operator = condPair.getSecond().replaceAll("\\s+","");
					Value ioFunVar = lCAddIOFuncMap.get(conVar1);
					List<String> returns = ioFunVar2RetMap.get(ioFunVar);
//					out.println(ioFunVar.toString()+"'s operator is " + operator);
//					for(String returnVal : returns){
//						out.println(ioFunVar.toString()+"'s returnVal = " + returnVal);
//					}
					
					List<String> satReturns = new ArrayList<String>();
					if(operator.equals("<=") || operator.equals("<")){//var + returns <=/< condPair.getThird
						for(String ret : returns){
							if(ret.equals("0") || ret.equals("0L") || ret.matches("^(-)([0-9]*(\\.[0-9]+)?)(L)?$")){//non-positive
								satReturns.add(ret);
							}
						}
						satIOFunVar2RetMap.put(ioFunVar, satReturns);
					} else if(operator.equals(">=") || operator.equals(">")){//var + returns >=/> condPair.getThird
						for(String ret : returns){
							if(ret.equals("0") || ret.equals("0L") || ret.matches("^(\\+)?([0-9]*(\\.[0-9]+)?)(L)?$")){ //non-negative
								satReturns.add(ret);
							}
						}
						satIOFunVar2RetMap.put(ioFunVar, satReturns);
					}
				} else {
					return false;
				}
//			} else if(lCAddIOFuncMap.containsKey(conVar3)){
//				if(isUnchanged(methodAllStmts, conVar1, paths, out)){//do we really need all paths, or just current path?
//					String operator = condPair.getSecond();
//					Value ioFunVar = lCAddIOFuncMap.get(conVar3);
//					List<String> returns = ioFunVar2RetMap.get(ioFunVar);
//					List<String> satReturns = new ArrayList<String>();
//					if(operator.equals("<=") || operator.equals("<")){//returns + var <=/< condPair.getThird
//						for(String ret : returns){
//							if(ret.equals("0") || ret.equals("0L") || ret.matches("^(-)([0-9]*(\\.[0-9]+)?)(L)?$")){//non-positive
//								satReturns.add(ret);
//							}
//						}
//						satIOFunVar2RetMap.put(ioFunVar, satReturns);
//					} else if(operator.equals(">=") || operator.equals(">")){//var + returns >=/> condPair.getThird
//						for(String ret : returns){
//							if(ret.equals("0") || ret.equals("0L") || ret.matches("^(\\+)?([0-9]*(\\.[0-9]+)?)(L)?$")){ //non-negative
//								satReturns.add(ret);
//							}
//						}
//						satIOFunVar2RetMap.put(ioFunVar, satReturns);
//					}
//				} else {
//					return false;
//				}
			} else if(lCSubIOFuncMap.containsKey(conVar1)){ //if the condition variable is var = var - IOfunction
				if(isUnchanged(methodAllStmts, conVar3, paths, out)){//do we really need all paths, or just current path?
					String operator = condPair.getSecond().replaceAll("\\s+","");
					Value ioFunVar = lCSubIOFuncMap.get(conVar1);
					List<String> returns = ioFunVar2RetMap.get(ioFunVar);
					List<String> satReturns = new ArrayList<String>();
					
//					out.println(ioFunVar.toString()+"'s operator is " + operator);
//					for(String returnVal : returns){
//						out.println(ioFunVar.toString()+"'s returnVal = " + returnVal);
//					}
					
					if(operator.equals("<=") || operator.equals("<")){//var - returns <=/< condPair.getThird
						for(String ret : returns){
							if(ret.equals("0") || ret.equals("0L") || ret.matches("^(\\+)?([0-9]*(\\.[0-9]+)?)(L)?$")){//non-negative
								satReturns.add(ret);
							}
						}
						satIOFunVar2RetMap.put(ioFunVar, satReturns);
					} else if(operator.equals(">=") || operator.equals(">")){//var - returns >=/> condPair.getThird
						for(String ret : returns){
							if(ret.equals("0") || ret.equals("0L") || ret.matches("^(-)([0-9]*(\\.[0-9]+)?)(L)?$")){ //non-positive
								satReturns.add(ret);
							}
						}
						satIOFunVar2RetMap.put(ioFunVar, satReturns);
					}
				} else {
					return false;
				}
//			} else if(lCSubIOFuncMap.containsKey(conVar3)){//var = returns - var >=/>/<=/< condPair.getThird
//					return false; //this condition cannot always be true, it rotates between true, false, true, false...
			}
		}
		
		if(satIOFunVar2RetMap.size()==0){
//			out.println("satIOFunVar2RetMap.size()==0");
			return false;
		}
		
		//4. check whether all condition can satisfy.
		for(ConditionPair<Value, String, Value> condPair : conditionPairList){
			Value conVar1 = condPair.getFirst();
			if(!lCAddIOFuncMap.containsKey(conVar1) && !lCSubIOFuncMap.containsKey(conVar1)){
//				out.println("conVar1 = " + conVar1);
				if(ioFunVar2RetMap.containsKey(conVar1)){
					Value conVar3 = condPair.getThird();
					String operator = condPair.getSecond().replaceAll("\\s+","");
					List<String> satRets = new ArrayList<String>();
					if(satIOFunVar2RetMap.containsKey(conVar1)){
						satRets = satIOFunVar2RetMap.get(conVar1);
					} else if(ioFunVar2RetMap.containsKey(conVar1)){
						satRets = ioFunVar2RetMap.get(conVar1);
					}
					
//					for(String retVal : satRets){
//						out.println(conVar1 + "'s return = " + retVal);
//					}
//					out.println("symbol is " + operator);
//					out.println("bound is " + conVar3.toString());
					
					if(satisfyCondition(conVar3, operator, satRets, out)){
//						out.println("satisfyCondition is true");
						continue;
					} else {
						return false;//two types of conditions cannot satify at the same time.
					}
				} else {
					return false; //we didn't consider other condition types: except var = var + IOfun, IOfun >/>=/</<=/==/!= constant
				}
			}
			
		}
		return true;
	
	}
	
	
	private List<String> getIOFuncRet(String className, String methodName) {
		Map<String, Map<String, List<String>>> class2FunMap =  IOFunctionUtils.retriveIOfunMap();
		if(class2FunMap.containsKey(className)){
			Map<String, List<String>> func2Rets = class2FunMap.get(className);
			if(func2Rets.containsKey(methodName)){
				return func2Rets.get(methodName);
			}
		}
		return null;
	}


	private boolean satisfyCondition(Value var, String operator, List<String> values, PrintStream out){//values operator var
		if(var instanceof IntConstant){
			int varInt = ((IntConstant) var).value;
			if(operator.equals("<=") || operator.equals("<")){//values <=/< var
				for(String value : values){
					if(value.matches("^(\\+|-)?([0-9]+)(L)?$")){
						value = value.replace("L", "").replace("+", "");
						int valueInt = Integer.parseInt(value);
						if(valueInt <= varInt){
							return true;
						}
					}
				}
				return false;
			} else if(operator.equals(">=") || operator.equals(">")){//values >=/> var
				for(String value : values){
					if(value.matches("^(\\+|-)?([0-9]+)(L)?$")){
						value = value.replace("L", "").replace("+", "");
						int valueInt = Integer.parseInt(value);
						if(valueInt >= varInt){
							return true;
						}
					}
				}
				return false;
			} else if(operator.equals("==")){//values == var
				for(String value : values){
					if(value.matches("^(\\+|-)?([0-9]+)(L)?$")){
						value = value.replace("L", "").replace("+", "");
						int valueInt = Integer.parseInt(value);
						if(valueInt == varInt){
							return true;
						}
					}
				}
				return false;
			} else if(operator.equals("!=")){//values != var
				for(String value : values){
					if(value.matches("^(\\+|-)?([0-9]+)(L)?$")){
						value = value.replace("L", "").replace("+", "");
						int valueInt = Integer.parseInt(value);
						if(valueInt != varInt){
							return true;
						}
					}
				}
				return false;
			}
		} else if (var instanceof LongConstant){
			long varLong = ((LongConstant) var).value;
			if(operator.equals("<=") || operator.equals("<")){//values <=/< var
				for(String value : values){
					if(value.matches("^(\\+|-)?([0-9]+)(L)?$")){
						value = value.replace("L", "").replace("+", "");
						long valueLong = Long.parseLong(value);
						if(valueLong <= varLong){
							return true;
						}
					}
				}
				return false;
			} else if(operator.equals(">=") || operator.equals(">")){//values >=/> var
				for(String value : values){
					if(value.matches("^(\\+|-)?([0-9]+)(L)?$")){
						value = value.replace("L", "").replace("+", "");
						long valueLong = Long.parseLong(value);
//						out.println("valueLong = " + valueLong);
//						out.println("varLong = " + varLong);
						if(valueLong >= varLong){
							return true;
						}
					}
				}
				return false;
			} else if(operator.equals("==")){//values == var
				for(String value : values){
					if(value.matches("^(\\+|-)?([0-9]+)(L)?$")){
						value = value.replace("L", "").replace("+", "");
						long valueLong = Long.parseLong(value);
						if(valueLong == varLong){
							return true;
						}
					}
				}
				return false;
			} else if(operator.equals("!=")){//values != var
				for(String value : values){
					if(value.matches("^(\\+|-)?([0-9]+)(L)?$")){
						value = value.replace("L", "").replace("+", "");
						long valueLong = Long.parseLong(value);
						if(valueLong != varLong){
							return true;
						}
					}
				}
				return false;
			}
		} else if (var instanceof DoubleConstant){
			double varDouble = ((DoubleConstant) var).value;
			if(operator.equals("<=") || operator.equals("<")){//values <=/< var
				for(String value : values){
					if(value.matches("^(\\+|-)?([0-9]*(\\.[0-9]+)?)(L)?$")){
						value = value.replace("L", "").replace("+", "");
						double valueDouble = Double.parseDouble(value);
						if(valueDouble <= varDouble){
							return true;
						}
					}
				}
				return false;
			} else if(operator.equals(">=") || operator.equals(">")){//values >=/> var
				for(String value : values){
					if(value.matches("^(\\+|-)?([0-9]*(\\.[0-9]+)?)(L)?$")){
						value = value.replace("L", "").replace("+", "");
						double valueDouble = Double.parseDouble(value);
						if(valueDouble >= varDouble){
							return true;
						}
					}
				}
				return false;
			} else if(operator.equals("==")){//values == var
				for(String value : values){
					if(value.matches("^(\\+|-)?([0-9]*(\\.[0-9]+)?)(L)?$")){
						value = value.replace("L", "").replace("+", "");
						double valueDouble = Double.parseDouble(value);
						if(valueDouble == varDouble){
							return true;
						}
					}
				}
				return false;
			} else if(operator.equals("!=")){//values != var
				for(String value : values){
					if(value.matches("^(\\+|-)?([0-9]+)(L)?$")){
						value = value.replace("L", "").replace("+", "");
						double valueDouble = Double.parseDouble(value);
						if(valueDouble != varDouble){
							return true;
						}
					}
				}
				return false;
			}
		}
		return false;
	}
	
	
	/*
	 * check the upperbound/lowerbound is unchanged in the loop paths
	 * */
	private boolean isUnchanged(List<Stmt> methodAllStmts, Value var, List<LoopPath> paths, PrintStream out){
		List<ValueBox> assignVar = null;
		for(LoopPath path : paths){
			List<Stmt> pathStmts = path.getpathStmt();
			int varAssignedNum = 0;
			for(int i = 0; i < pathStmts.size()-1; i++){ //the head and tail statements are the same in the loop path.
				Stmt stmt = pathStmts.get(i);
				if(stmt instanceof JAssignStmt){
					//out.println(stmt.toString());
					List<ValueBox> defs = stmt.getDefBoxes();
					for(ValueBox def : defs){
						if(def.getValue().equals(var)){
							assignVar = ((JAssignStmt)stmt).getUseBoxes();
							varAssignedNum++;
						}
					}
				}
			}
			if(varAssignedNum > 1) //assigned more than once.
				return false;
		}
//		if(assignVar != null){
//			out.println("assginVar = " + assignVar);
//			for(ValueBox valuebox : assignVar){
//				if(valuebox.getValue() instanceof InvokeExpr){
//					InvokeExpr expression = (InvokeExpr) valuebox.getValue();
//					if(expression instanceof InstanceInvokeExpr){
//						//Value refVar = ((InstanceInvokeExpr) expression).getBase();
//						if(expression.getMethodRef().toString().contains("java.nio.ByteBuffer")){
//							FPPattern3 checkFPpattern3 = new FPPattern3();
//							if(checkFPpattern3.isUnchangedLimit(paths, methodAllStmts, out) == false)
//								return false;
//						}
//					}
//				}
//			}
//		}
		return true;
	}
	
	
	
	
	/*currently, we only consider this following case:
	 * input : $b6 = l1 cmp l0
	 *         if $b6 > 0, goto ...
	 * output: if l1 > l0, goto ...
	 */
	private List<ConditionPair<Value, String, Value>> convertConds(List<Condition> conList, LoopPath path, PrintStream out){
		List<ConditionPair<Value, String, Value>> condPairList = new ArrayList<ConditionPair<Value, String, Value>>();
		for(Condition cond : conList){
			//out.println(cond.cond.getOp1() + ":" + cond.cond.getSymbol() + ":" + cond.cond.getOp2());
			ConditionPair<Value, String, Value> condPair = 
					new ConditionPair<Value, String, Value>(cond.cond.getOp1(), cond.cond.getSymbol(), cond.cond.getOp2());
			Value conVar1 = cond.cond.getOp1();
			List<Stmt> pathStmts = path.getpathStmt();
			if(conVar1.toString().contains("$")){//$b
				for(int i = 1; i < pathStmts.size(); i++){
					if(pathStmts.get(i) instanceof JIfStmt && pathStmts.get(i-1) instanceof JAssignStmt){
						JIfStmt ifstmt = (JIfStmt) pathStmts.get(i);
						JAssignStmt assignstmt = (JAssignStmt) pathStmts.get(i-1);
						boolean foundVar1 = false;
						boolean foundcmp = false;
						List<ValueBox> uses = ifstmt.getCondition().getUseBoxes();
						for(ValueBox use : uses){
							if(use.getValue().equals(conVar1)){ //$b > 0
								foundVar1 = true;
								break;
							}
						}
						if(foundVar1 == true){
							List<ValueBox> defs = assignstmt.getDefBoxes();
							for(ValueBox def : defs){
								if(def.getValue().equals(conVar1)){//$b6
									for(ValueBox use : assignstmt.getUseBoxes()){
										if(use.getValue().toString().contains("cmp")){//$b6 = l1 cmp l0
											foundcmp = true;
											break;
										}
									}
								}
							}
							if(foundcmp == true  //if it contains l1 cmp l0, then the 1st usebox is l1 cmp l0, the 2nd is l1, the 3rd is l0
									&& assignstmt.getUseBoxes().size() == 3 
									&& assignstmt.getUseBoxes().get(0).getValue().toString().contains("cmp")){
								condPair.setFirst(assignstmt.getUseBoxes().get(1).getValue());
								condPair.setThird(assignstmt.getUseBoxes().get(2).getValue());
								break;
							}
						}
					}
				}
			}
			condPairList.add(condPair);
		}
		return condPairList;
	}
	


}

class RangePair<F, S> {
    private F first; //first member of pair
    private S second; //second member of pair

    public RangePair(F first, S second) {
        this.first = first;
        this.second = second;
    }

    public RangePair() {
		// TODO Auto-generated constructor stub
	}

	public void setFirst(F first) {
        this.first = first;
    }

    public void setSecond(S second) {
        this.second = second;
    }

    public F getFirst() {
        return first;
    }

    public S getSecond() {
        return second;
    }
}


class ConditionPair<F,S,T>{
    private F first; // a
    private S second;// >
    private T third; // b

    public ConditionPair(F first, S second, T third) {
        this.first = first;
        this.second = second;
        this.third = third;
    }

    public ConditionPair() {

    }
    
    public void setFirst(F first) {
    	this.first = first;    
    }

    public void setSecond(S second) {
    	this.second = second;
    }
    
    public void setThird(T third){
    	this.third = third;
    }

    public F getFirst() {
        return first;
    }

    public S getSecond() {
        return second;
    }
    
    public T getThird(){
    	return third;
    }
}