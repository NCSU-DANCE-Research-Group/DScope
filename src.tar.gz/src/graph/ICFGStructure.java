package graph;

import java.util.ArrayList;
import java.util.List;

public class ICFGStructure {
	public List<VFMethod> listMethods = new ArrayList<VFMethod>();
	public List<VFMethodEdge> listEdges = new ArrayList<VFMethodEdge>();
}
