package graph;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import soot.Body;
import soot.G;
import soot.Main;
import soot.PackManager;
import soot.Scene;
import soot.SceneTransformer;
import soot.SootClass;
import soot.SootMethod;
import soot.Transform;
import soot.Unit;
import soot.jimple.InvokeExpr;
import soot.jimple.Stmt;
import soot.jimple.spark.SparkTransformer;
import soot.jimple.toolkits.callgraph.CHATransformer;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Targets;
import soot.options.Options;
import soot.tagkit.AttributeValueException;
import soot.tagkit.Tag;
import soot.util.Chain;


public class JimpleModelAnalysis {

	private int methodcount = 0;
	private int edgeCount = 0;

	private Map<SootMethod, VFMethod> methodMap = new HashMap<>();

	private String[] sootString;

	public void setSootString(String[] s) {
		this.sootString = s;
	}

	/**
	 * This method generates the ICFG (Inter-procedural Control Flow Graph) of the target code. Call graph option(CHA/Spark)
	 * can be set here. It also creates the Jimple model.
	 * @param methodGraph
	 * @param vfClasses
	 **/
	public void createICFG(final ICFGStructure methodGraph, final List<VFClass> vfClasses) {
		G.reset();
		Transform transform = new Transform("wjap.myTransform", new SceneTransformer() {
			@Override
			protected void internalTransform(String phase, Map<String, String> arg1) {

				//String callGraphPref = GlobalSettings.get("CallGraphOption");
				String callGraphPref = "CHA";
				if("CHA".equalsIgnoreCase(callGraphPref))
				{
					Options.v().setPhaseOption("cg.cha", "on");
					CHATransformer.v().transform();
				}
				else
				{
					HashMap<String, String> opt = new HashMap<>();
					opt.put("verbose", "true");
					opt.put("propagator", "worklist");
					opt.put("simple-edges-bidirectional", "false");
					opt.put("on-fly-cg", "false");
					opt.put("set-impl", "double");
					opt.put("double-set-old", "hybrid");
					opt.put("double-set-new", "hybrid");
					opt.put("enabled", "true");
					SparkTransformer.v().transform("",opt);
				}
				Scene.v().loadNecessaryClasses();
				createJimpleHierarchyWithCfgs(vfClasses);
				createICFG();
			}
			
			private List<SootMethod> getAllMethods(SootClass klass) {
		        ArrayList<SootMethod> entrypoints = new ArrayList<SootMethod>();
//		        Scene.v().forceResolve(klassName, SootClass.SIGNATURES);
//		        //Scene.v().forceResolve(klassName, SootClass.HIERARCHY);
//		        //Scene.v().forceResolve(klassName, SootClass.BODIES | SootClass.HIERARCHY | SootClass.SIGNATURES);
//		        SootClass klass = Scene.v().getSootClass(klassName);
		        // adding all non-abstract method as entrypoint
		        for (SootMethod m : klass.getMethods()) {
		        	if (!m.isAbstract()) {
		        		entrypoints.add(m);
		            }
		        }
		        return entrypoints;
		    }

			/**
			 * This method iterates over all the called methods, starting from main(). It recursively calls the outgoing
			 * edges of a method and generate structure (ICFG Structure) having nodes as methods and call to methods as edges.
			 **/
			private void createICFG() {
				CallGraph cg = Scene.v().getCallGraph();
				for(VFClass vfclass : vfClasses){
					List<SootMethod> listMethod = getAllMethods(vfclass.getSootClass());
					for(SootMethod entryMethod : listMethod){
						System.out.println("methodSig = " + entryMethod.getSignature());
						//System.out.println("methodName = " + entryMethod.getName());	
						methodcount++;
						VFMethod vfmethod;
						if (methodMap.containsKey(entryMethod)) {
							vfmethod = methodMap.get(entryMethod);
						} else {
							vfmethod = new VFMethod(entryMethod);
							methodMap.put(entryMethod, vfmethod);
						}
						methodGraph.listMethods.add(vfmethod);
						traverseMethods(entryMethod, cg);
					}
				}
				
//				SootMethod entryMethod = null;
//				List<SootMethod> listMethod = Scene.v().getEntryPoints();
//				Iterator<SootMethod> iterEntryMethod = listMethod.iterator();
//				while (iterEntryMethod.hasNext()) {
//					entryMethod = iterEntryMethod.next();
//					//if (entryMethod.isMain()) {////////////////////////////it checks for main function. But actually we don't really care about main function
//					System.out.println("methodSig = " + entryMethod.getSignature());
//					//System.out.println("methodName = " + entryMethod.getName());
//					//if(entryMethod.getName().contains("read")){	
//						methodcount++;
//						VFMethod vfmethod;
//						if (methodMap.containsKey(entryMethod)) {
//							vfmethod = methodMap.get(entryMethod);
//						} else {
//							vfmethod = new VFMethod(entryMethod);
//							methodMap.put(entryMethod, vfmethod);
//						}
//						methodGraph.listMethods.add(vfmethod);
//					//	break;
//					//}
//				}

				
				System.out.println("methodcount = " + methodcount);
			}
			
			private List<String> getAnalysisClasses(){
				List<String> klassNames = new ArrayList<String>();
				for(int i = sootString.length-1; i >= 0; i--){
					if(sootString[i].equals("enabled:true")){
						break;
					}
					klassNames.add(sootString[i]);
				}
				return klassNames;
			}

			/**
			 * This method creates a Jimple model consisting of (VFClass, VFMEthod and VFUnit). It creates a Scene() object
			 * and iteratively finds all the classes, methods and units and creates a structure.
			 * @param vfClasses
			 * @return void
			 */
			private void createJimpleHierarchyWithCfgs(List<VFClass> vfClasses) {
				//TODO cuncurrent modification exception comes from here.
				//Chain<SootClass> classes = Scene.v().getClasses();
				//String klassName = sootString[sootString.length-1];
				for(String klassName : getAnalysisClasses()){
					Scene.v().forceResolve(klassName, SootClass.SIGNATURES);
					SootClass sootClass = Scene.v().getSootClass(klassName);
				//for (SootClass sootClass : classes) {
					if (sootClass.isJavaLibraryClass() || sootClass.isLibraryClass()) {
						//continue;
						return;
					}

					VFClass currentClass = new VFClass(sootClass);
					vfClasses.add(currentClass);

					for (SootMethod sootMethod : sootClass.getMethods()) {
						VFMethod currentMethod;
						if (methodMap.containsKey(sootMethod)) {
							currentMethod = methodMap.get(sootMethod);
						} else {
							currentMethod = new VFMethod(sootMethod);
							methodMap.put(sootMethod, currentMethod);
						}
						currentMethod.setVfClass(currentClass);
						Body body;
						try {
							body = sootMethod.retrieveActiveBody();
							for (Unit unit : body.getUnits()) {
								addFullyQualifiedName(unit, sootClass, sootMethod);
								VFUnit currentUnit = new VFUnit(unit);
								currentUnit.setVfMethod(currentMethod);
								currentMethod.getUnits().add(currentUnit);
							}
							currentMethod.setBody(body);
							currentMethod.setControlFlowGraph(new ControlFlowGraphGenerator().generateControlFlowGraph(currentMethod));
							currentClass.getMethods().add(currentMethod);
						} catch (RuntimeException e) {
							System.err.println("No body for " + sootMethod.getName() + " available");
						}
					}
				}
			}

			/**
			 * This methods accepts the unit details and adds the fully qualified name as a unit tag in the
			 * Jimple model
			 * @param unit
			 * @param sootClass
			 * @param sootMethod
			 */
			private void addFullyQualifiedName(final Unit unit, final SootClass sootClass, final SootMethod sootMethod) {
				unit.addTag(new Tag() {
					@Override
					public byte[] getValue() throws AttributeValueException {
						String fqn = sootClass.getName() + "." + sootMethod.getName() + "." + unit.toString();
						try {
							return fqn.getBytes("utf-8");
						} catch (UnsupportedEncodingException e) {
							AttributeValueException ave = new AttributeValueException();
							ave.initCause(e);
							throw ave;
						}
					}

					@Override
					public String getName() {
						return "Fully Qualified Name";
					}
				});
			}

			private void addReturnPoint(VFMethodEdge edge){
				List<VFUnit> unitList = edge.getSourceMethod().getUnits();
				for (VFUnit unit : unitList){
					if(((Stmt)unit.getUnit()).containsInvokeExpr()){
						InvokeExpr ivE = ((Stmt)unit.getUnit()).getInvokeExpr();
						if(ivE.getMethod().equals(edge.getDestMethod().getSootMethod())){
							edge.getDestMethod().addIncomingEdge(unit);
						}
					}
				}
			}

			private void addCallPoint(VFMethodEdge edge){
				List<VFUnit> unitList = edge.getSourceMethod().getUnits();
				for (VFUnit unit : unitList){
					if(((Stmt)unit.getUnit()).containsInvokeExpr()){
						InvokeExpr ivE = ((Stmt)unit.getUnit()).getInvokeExpr();
						if(ivE.getMethod().equals(edge.getDestMethod().getSootMethod())){
							unit.addOutgoingEdge(edge.getDestMethod().getUnits().get(0));
						}
					}
				}
			}

			/**
			 * This method recursively iterates over method calls to generate ICFG structure
			 * @param SootMethod
			 * @param CallGraph
			 */
			private void traverseMethods(SootMethod source, CallGraph cg) {
				Targets tc = new Targets(cg.edgesOutOf(source));
				while (tc.hasNext()) {
					//System.out.println(source.getSignature() + " has next");
					SootMethod destination = (SootMethod) tc.next();
					// System.out.println(destination+" is java library "+destination.isJavaLibraryMethod());
					if (!destination.isJavaLibraryMethod()) {
						boolean edgeConnection = false;
						Iterator<VFMethodEdge> edgeIterator = methodGraph.listEdges.iterator();
						while(edgeIterator.hasNext())
						{
							VFMethodEdge vfMethodEdge = edgeIterator.next();
							if(vfMethodEdge.getSourceMethod().getSootMethod().equals(source) && vfMethodEdge.getDestMethod().getSootMethod().equals(destination))
							{
								edgeConnection = true;
								break;
							}
						}

						if(edgeConnection)
							continue;
						boolean methodPresent = false;
						Iterator<VFMethod> iteratorMethod = methodGraph.listMethods.iterator();
						while (iteratorMethod.hasNext()) {
							if (iteratorMethod.next().getSootMethod().equals(destination)) {
								methodPresent = true;
								break;
							}
						}

						if (!methodPresent) {
							methodcount++;
							VFMethod method;
							if (methodMap.containsKey(destination)) {
								method = methodMap.get(destination);
								method.setId(methodcount);
							} else {
								method = new VFMethod(methodcount, destination);
								methodMap.put(destination, method);
							}
							methodGraph.listMethods.add(method);
						}
						VFMethod sourceMethod = null;
						VFMethod destinationMethod = null;
						Iterator<VFMethod> iteratorMethods = methodGraph.listMethods.iterator();
						while (iteratorMethods.hasNext()) {
							VFMethod method = iteratorMethods.next();
							if (method.getSootMethod().equals(source)) {
								sourceMethod = method;
							}
							if (method.getSootMethod().equals(destination)) {
								destinationMethod = method;
							}
						}
						edgeCount++;
						VFMethodEdge edge = new VFMethodEdge(edgeCount, sourceMethod, destinationMethod);
						addReturnPoint(edge);
						addCallPoint(edge);
						methodGraph.listEdges.add(edge);
						traverseMethods(destination, cg);
					}
				}
			}
		});

		PackManager.v().getPack("wjap").add(transform);
		// Run Soot
		Main.main(sootString);
	}
}
