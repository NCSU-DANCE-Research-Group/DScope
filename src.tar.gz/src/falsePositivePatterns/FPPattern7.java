package falsePositivePatterns;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import soot.IntType;
import soot.Value;
import soot.ValueBox;
import soot.jimple.AddExpr;
import soot.jimple.Constant;
import soot.jimple.DivExpr;
import soot.jimple.FieldRef;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.IntConstant;
import soot.jimple.InvokeExpr;
import soot.jimple.JimpleBody;
import soot.jimple.LongConstant;
import soot.jimple.MulExpr;
import soot.jimple.StaticInvokeExpr;
import soot.jimple.Stmt;
import soot.jimple.SubExpr;
import soot.jimple.internal.JAssignStmt;
import soot.jimple.internal.JGotoStmt;
import soot.jimple.internal.JInvokeStmt;
import utilities.Condition;
import utilities.ExtraCondition;
import utilities.LoopPath;
import utilities.SameInstanceVars;


/* This is a customized pattern for List class.
 * */
public class FPPattern7 {	
	/* Pattern 4: check List related patterns. 
	 * there are a set of FP patterns.
	 **/
	//Currently, this pattern only focuses on small set of List APIs.
	//For example, 	isEmpty, remove
	public boolean checkListPattern(List<LoopPath> paths, List<Stmt> methodAllStmts, PrintStream out){
		//1. extract all the Iterator ref var in all stmts.
		List<Stmt> iterotorStmts = new ArrayList<Stmt>();
		List<Value> itInstVar = new ArrayList<Value>();
		Map<Value, Value> it2ownerMap = new HashMap<Value, Value>();
		for(Stmt stmt : methodAllStmts){
			if(stmt instanceof JAssignStmt && stmt.containsInvokeExpr()){
				InvokeExpr expression = stmt.getInvokeExpr();
				JAssignStmt jassgnStmt = (JAssignStmt) stmt;
				Value iteratorVar = jassgnStmt.leftBox.getValue();
//				out.println(expression.getMethod().getSignature());
				if(expression.getMethodRef().toString().contains("java.util.List")){ 
					//e.g.,$z0 = interfaceinvoke r4.<java.util.Iterator: boolean hasNext()>()
					//e.g.,r4 = interfaceinvoke $r8.<java.util.List: java.util.Iterator iterator()>()
					iterotorStmts.add(stmt);
					//Value refVar = ((InstanceInvokeExpr) expression).getBase();
					//if(refVar.getType().toString().contains("java.util.Iterator")){
					if(expression.getType().toString().contains("java.util.List")){
						if(!itInstVar.contains(iteratorVar)){
							itInstVar.add(iteratorVar);
						}
						if(expression instanceof InstanceInvokeExpr){
							Value refVar = ((InstanceInvokeExpr) expression).getBase();
							if(!it2ownerMap.containsKey(iteratorVar)){
								it2ownerMap.put(iteratorVar, refVar);
							}
						}
					}
				}
				/*if(expression instanceof InstanceInvokeExpr){
					if(expression.getMethodRef().toString().contains("java.util.Iterator")){ 
						//e.g.,$z0 = interfaceinvoke r4.<java.util.Iterator: boolean hasNext()>()
						//e.g.,r4 = interfaceinvoke $r8.<java.util.List: java.util.Iterator iterator()>()
						iterotorStmts.add(stmt);
						Value refVar = ((InstanceInvokeExpr) expression).getBase();
						//if(refVar.getType().toString().contains("java.util.Iterator")){
						if(expression.getType().toString().contains("java.util.Iterator")){
							if(!itInstVar.contains(iteratorVar)){
								itInstVar.add(iteratorVar);
							}
							if(!it2ownerMap.containsKey(iteratorVar)){
								it2ownerMap.put(iteratorVar, refVar);
							}
						}
					}
				}*/
			} else if(stmt instanceof JInvokeStmt){
				InvokeExpr expression = stmt.getInvokeExpr();
				if(expression instanceof InstanceInvokeExpr){
					if(expression.getMethodRef().toString().contains("java.util.List")){
						iterotorStmts.add(stmt);
						/*out.println("getBase = "+ ((InstanceInvokeExpr) expression).getBase());//ByteBuffer instance
						out.println("expression = " + expression);
						out.println("getType = " + expression.getType());//return type
						out.println("getMethodRef = " + expression.getMethodRef());
						out.println("signature = " + expression.getMethodRef().getSignature());
						out.println("subsignature = " + expression.getMethodRef().getSubSignature());
						out.println("MethodName = " + expression.getMethod().getName());//function name
						out.println("getMethod = " + expression.getMethod());
						out.println("getBaseType = " +((InstanceInvokeExpr) expression).getBase().getType());*/
					}
				}
			}
		}
		out.println("itInstVar = " + itInstVar);
		out.println("it2ownerMap = " + it2ownerMap);
		Map<Value, List<Value>> sameVarMap = SameInstanceVars.extractEqualConditions(methodAllStmts, out);
		List<Map<Value, List<String>>> funcsinAllPathsOfallVars = new ArrayList<Map<Value, List<String>>>();
		for(LoopPath path1 : paths){
			Map<Value, List<String>> funcMap = getAllIteratorFuncs(path1, iterotorStmts, out);
			funcsinAllPathsOfallVars.add(funcMap);
		}
		out.println("funcsinAllPathsOfallVars = " + funcsinAllPathsOfallVars);
		for(Value iteratorVar : itInstVar){
			List<List<String>> funcsinAllPaths = new ArrayList<List<String>>();
			for(Map<Value, List<String>> funcMap : funcsinAllPathsOfallVars){
				List<String> allFuncs = new ArrayList<String>();
				if(funcMap.containsKey(iteratorVar)){
//					funcsinAllPaths.add(funcMap.get(iteratorVar));
					allFuncs.addAll(funcMap.get(iteratorVar));
				}
				//we not only consider the current instance var, we also consider the equally same instance vars.
				if(sameVarMap.containsKey(iteratorVar)){
					List<Value> sameVars = sameVarMap.get(iteratorVar);
					for(Value sameVar : sameVars){
						if(funcMap.containsKey(sameVar)){
							allFuncs.addAll(funcMap.get(sameVar));
						}
					}
				}
				funcsinAllPaths.add(allFuncs);
			}
			out.println("funcsinAllPaths = " + funcsinAllPaths);
			if(isUnchanged(it2ownerMap.get(iteratorVar), paths, out)){// Comment this one to loose the checking constraints
				//check the index in all path moving forward, but the limit is not changed.
				if(checkIteratorindex(funcsinAllPaths, out) == true)
					return true;
			}
		}
		

		return false;
	}
	

	/*
	 * check the upperbound is unchanged in the loop paths
	 * */
	public boolean isUnchanged(Value var, List<LoopPath> paths, PrintStream out){
		for(LoopPath path : paths){
			List<Stmt> pathStmts = path.getpathStmt();
			int varAssignedNum = 0;
			for(Stmt stmt: pathStmts){
				if(!(stmt instanceof JGotoStmt)){
					//out.println(stmt.toString());
					List<ValueBox> defs = stmt.getDefBoxes();
					for(ValueBox def : defs){
						if(def.getValue().equals(var)){
							varAssignedNum++;
						}
					}
				}
			}
			if(varAssignedNum > 2) //loop header and loop tail
				return false;
		}
		return true;
	}


	/* check whether the index of List is moving forward
	 * i.e. remove() func now.
	 */
	private boolean checkIteratorindex(List<List<String>> newFuncLists, PrintStream out) {
		if(newFuncLists == null || (newFuncLists != null && newFuncLists.size() == 0))
			return false;
		for(List<String> funcs : newFuncLists){
			boolean isLowerBoundCheck = false;
			boolean isMovingForward = false;
//			int calledNextRemovePair = 0;
			boolean containOtherFunc = false;
			for(String funcName : funcs){
				if(funcName.equals("isEmpty")){ //this remaining here means that it is in Condition
					isLowerBoundCheck = true;
				} else if(funcName.equals("remove")){
					isMovingForward = true;
//					calledNextRemovePair++;
				} else {
					containOtherFunc = true;
				}
			}
			if(containOtherFunc == true)
				return false; //Iterator has remove() fun
			if(isLowerBoundCheck == false)
				return false; // there is no upper bound check
			//if((calledNextRemovePair % 2) != 0)
			//	return false;  //remove() can be called only once per call to next(). 
			if(isMovingForward == false)
				return false;  //there is no moving index forward
		}
		return true;
	}



	//get the map of ByteBuffer instance and List<ByteBuffer functions in the loop path>.
	private Map<Value, List<String>> getAllIteratorFuncs(LoopPath path1, List<Stmt> iterotorStmts, PrintStream out) {
		List<Stmt> pathStmts = path1.getpathStmt();
		List<Stmt> trimedPathStmts = new ArrayList<Stmt>();
		List<Condition> pathConds = new ArrayList<Condition>();
//		pathConds = path1.getconditions();
		pathConds = ExtraCondition.extractEqualConditions(path1, out);
		Map<Value, List<String>> varFuncMap = new HashMap<Value, List<String>>();
		for(Stmt stmt : pathStmts){
			boolean found = false;
			for(Stmt itstmt : iterotorStmts){
				if(stmt.equals(itstmt)){
					found = true;
					break;
				}
			}
			if(found == true)
				trimedPathStmts.add(stmt);
		}
		Set<Value> refVars = new HashSet<Value>();
		if(pathConds != null && pathConds.size() > 0){
			for(Condition cond : pathConds){
				Value var1 = cond.cond.getOp1();
				refVars.add(var1);
			}
		}
		
		//out.println("refVars = " + refVars);
		for(Stmt stmt : trimedPathStmts){
			//out.println(LoopUtils.stmt_toString(stmt));
			InvokeExpr expression = stmt.getInvokeExpr();
			if(expression instanceof InstanceInvokeExpr 
					&& expression.getMethodRef().toString().contains("java.util.List")){
			//if(((InstanceInvokeExpr) expression).getBase().getType().toString().contains("java.nio.ByteBuffer")){
				Value insVar = ((InstanceInvokeExpr) expression).getBase();
				//out.println("insVar = " + insVar);
				String funcName = expression.getMethod().getName();
				//out.println("funcName = " + funcName);
				if(varFuncMap.containsKey(insVar)){
					List<String> funcs = varFuncMap.get(insVar);
					funcs.add(funcName);
					varFuncMap.put(insVar, funcs);
				} else {
					List<String> funcs = new ArrayList<String>();
					funcs.add(funcName);
					varFuncMap.put(insVar, funcs);
				}
			}
		}
		return varFuncMap;
	}

}
