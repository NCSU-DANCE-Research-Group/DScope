package falsePositivePatterns;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import soot.IntType;
import soot.Value;
import soot.ValueBox;
import soot.jimple.AddExpr;
import soot.jimple.Constant;
import soot.jimple.DivExpr;
import soot.jimple.FieldRef;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.IntConstant;
import soot.jimple.InvokeExpr;
import soot.jimple.JimpleBody;
import soot.jimple.LongConstant;
import soot.jimple.MulExpr;
import soot.jimple.StaticInvokeExpr;
import soot.jimple.Stmt;
import soot.jimple.SubExpr;
import soot.jimple.internal.JAssignStmt;
import soot.jimple.internal.JGotoStmt;
import soot.jimple.internal.JIdentityStmt;
import soot.jimple.internal.JInvokeStmt;
import soot.jimple.internal.JNewExpr;
import utilities.Condition;
import utilities.ExtraCondition;
import utilities.LoopPath;


/* This is a customized pattern for Queue class.
 * */
public class FPPattern12Extend {	
	/* Currently, this pattern only focuses on small set of Queue APIs.
	 * For example, 	poll, 
	 **/
	public boolean containIPSstr(String str){
		if(str.contains("java.util.Stack"))
			return true;
		return false;
	}
	
	public boolean checkQueuePattern(List<LoopPath> paths, List<Stmt> methodAllStmts, PrintStream out){
		//1. extract all the Iterator ref var in all stmts.
		List<Stmt> bffReaderStmts = new ArrayList<Stmt>();
		List<Value> brInstVar = new ArrayList<Value>();
		Map<Value, Value> it2ownerMap = new HashMap<Value, Value>();
		for(Stmt stmt : methodAllStmts){
			if(stmt instanceof JAssignStmt){
				if(stmt.containsInvokeExpr()){
					//out.println("stmt = " + stmt);
					InvokeExpr expression = stmt.getInvokeExpr();
					//out.println("expression = " + expression);
					JAssignStmt jassgnStmt = (JAssignStmt) stmt;
					Value bufferedReaderVar = jassgnStmt.leftBox.getValue();
					if(containIPSstr(expression.getMethodRef().toString())){ 
						//e.g.,$z0 = interfaceinvoke r4.<java.util.Iterator: boolean hasNext()>()
						//e.g.,r4 = interfaceinvoke $r8.<java.util.List: java.util.Iterator iterator()>()
						bffReaderStmts.add(stmt);
						//Value refVar = ((InstanceInvokeExpr) expression).getBase();
						//if(refVar.getType().toString().contains("java.util.Iterator")){
						
//						if(expression.getType().toString().contains("java.io.BufferedReader")){
//							if(!brInstVar.contains(bufferedReaderVar)){
//								brInstVar.add(bufferedReaderVar);
//							}
							if(expression instanceof InstanceInvokeExpr){
								Value refVar = ((InstanceInvokeExpr) expression).getBase();
								if(!brInstVar.contains(refVar)){
									brInstVar.add(refVar);
								}
							}
							
//							if(expression instanceof InstanceInvokeExpr){
//								Value refVar = ((InstanceInvokeExpr) expression).getBase();
//								if(!it2ownerMap.containsKey(bufferedReaderVar)){
//									it2ownerMap.put(bufferedReaderVar, refVar);
//								}
//								/*out.println("getBase = "+ ((InstanceInvokeExpr) expression).getBase());//ByteBuffer instance
//								out.println("expression = " + expression);
//								out.println("getType = " + expression.getType());//return type
//								out.println("getMethodRef = " + expression.getMethodRef());
//								out.println("signature = " + expression.getMethodRef().getSignature());
//								out.println("subsignature = " + expression.getMethodRef().getSubSignature());
//								out.println("MethodName = " + expression.getMethod().getName());//function name
//								out.println("getMethod = " + expression.getMethod());
//								out.println("getBaseType = " +((InstanceInvokeExpr) expression).getBase().getType());*/
//							}
						}
//					}
				} else {
					//to handle this case:
					//BufferedReader lines = new BufferedReader(new InputStreamReader(in));
					//17: $r12 = new java.io.BufferedReader	class soot.jimple.internal.JAssignStmt
					//18: $r13 = new java.io.InputStreamReader	class soot.jimple.internal.JAssignStmt
					//19: specialinvoke $r13.<java.io.InputStreamReader: void <init>(java.io.InputStream)>($r10)	class soot.jimple.internal.JInvokeStmt
					//20: specialinvoke $r12.<java.io.BufferedReader: void <init>(java.io.Reader)>($r13)	class soot.jimple.internal.JInvokeStmt
					JAssignStmt jassgnStmt = (JAssignStmt) stmt;
					Value bufferedReaderVar = jassgnStmt.leftBox.getValue();
					for(ValueBox vb : stmt.getUseBoxes()){
						Value value = vb.getValue();
						if(value instanceof JNewExpr){
							JNewExpr newExpr = (JNewExpr)value;
							if(containIPSstr(newExpr.getType().toString())){
								if(!brInstVar.contains(bufferedReaderVar)){
									brInstVar.add(bufferedReaderVar);
								}
								break;
							}
						}
					}
				}
			} else if(stmt instanceof JIdentityStmt){
				//to handle this case:
				//private String readLine(BufferedReader reader)
				//r1 := @parameter0: java.io.BufferedReader	Type: class soot.jimple.internal.JIdentityStmt
				JIdentityStmt jidStmt = (JIdentityStmt)stmt;
				Value bufferedReaderVar = jidStmt.leftBox.getValue();
				for(ValueBox vb : stmt.getUseBoxes()){
					Value value = vb.getValue();
					if(containIPSstr(value.toString())){
						if(!brInstVar.contains(bufferedReaderVar)){
							brInstVar.add(bufferedReaderVar);
						}
						break;
					}
				}
			} else if(stmt instanceof JInvokeStmt){
				InvokeExpr expression = stmt.getInvokeExpr();
				if(expression instanceof InstanceInvokeExpr){
					if(containIPSstr(expression.getMethodRef().toString())){
						bffReaderStmts.add(stmt);
						/*out.println("getBase = "+ ((InstanceInvokeExpr) expression).getBase());//ByteBuffer instance
						out.println("expression = " + expression);
						out.println("getType = " + expression.getType());//return type
						out.println("getMethodRef = " + expression.getMethodRef());
						out.println("signature = " + expression.getMethodRef().getSignature());
						out.println("subsignature = " + expression.getMethodRef().getSubSignature());
						out.println("MethodName = " + expression.getMethod().getName());//function name
						out.println("getMethod = " + expression.getMethod());
						out.println("getBaseType = " +((InstanceInvokeExpr) expression).getBase().getType());*/
					}
				}
			}
		}
		out.println("brInstVar = " + brInstVar);
		out.println("it2ownerMap = " + it2ownerMap);
		List<Map<Value, List<String>>> funcsinAllPathsOfallVars = new ArrayList<Map<Value, List<String>>>();
		for(LoopPath path1 : paths){
			Map<Value, List<String>> funcMap = getAllBufferedReaderFuncs(path1, bffReaderStmts, out);
			funcsinAllPathsOfallVars.add(funcMap);
		}
		out.println("funcsinAllPathsOfallVars = " + funcsinAllPathsOfallVars);
		List<Map<Value, Boolean>> funcsinAllCondsOfallVars = new ArrayList<Map<Value, Boolean>>();
		for(LoopPath path1 : paths){
			Map<Value, Boolean> funcMap = checkHasEmptyFunc(path1, bffReaderStmts, out);
			funcsinAllCondsOfallVars.add(funcMap);
		}
		out.println("funcsinAllCondsOfallVars = " + funcsinAllCondsOfallVars);
		
		for(Value bufferedReaderVar : brInstVar){
			boolean readLineInCond = false;
			for(Map<Value, Boolean> funcMap : funcsinAllCondsOfallVars){
				if(funcMap.containsKey(bufferedReaderVar) && 
						funcMap.get(bufferedReaderVar) == true){
					readLineInCond = true;
					break;
				}
			}
			if(readLineInCond){
				List<List<String>> funcsinAllPaths = new ArrayList<List<String>>();
				for(Map<Value, List<String>> funcMap : funcsinAllPathsOfallVars){
					if(funcMap.containsKey(bufferedReaderVar)){
						funcsinAllPaths.add(funcMap.get(bufferedReaderVar));
					}
				}
				out.println("funcsinAllPaths = " + funcsinAllPaths);
				
				//if(isUnchanged(it2ownerMap.get(brInstVar), paths, out)){//The File instance is not new File(...) in the loop path
				//	return true;
				//}
				if(checkQueueChanged(funcsinAllPaths, out) == true)
					return true;
			}
		}

		return false;
	}
	

	/*
	 * 1) for exists(), then the file instance should change in every iteration, i.e., called <init>
	 * 2) for getParent() and getParentFile(), then the file instance should not changed, i.e., not call <init>
	 * */
	private boolean checkQueueChanged(List<List<String>> newFuncLists, PrintStream out) {
		if(newFuncLists == null || (newFuncLists != null && newFuncLists.size() == 0))
			return false;
		for(List<String> funcs : newFuncLists){
			boolean isLowerBoundCheck = false;
			boolean isMovingForward = false;
			boolean isMovingBackward = false;
			boolean containOtherFunc = false;
			for(String funcName : funcs){
				if(funcName.equals("pop")){ //this remaining here means that it is in Condition
					isMovingForward = true; 
				} else if(funcName.equals("empty")){
					isLowerBoundCheck = true;//we already called checkHasEmptyFunc(), thus it already checked empty() == 0 pattern.
				} else if(funcName.equals("search") || funcName.equals("peek")){
					continue;
				} else if(funcName.equals("push")){
					isMovingBackward = true; 
				} else {
					containOtherFunc = true;
				}
			}
			//if(containOtherFunc == true)
			//	return false; //we don't care about countTokens func, so even it appears, it doesn't matter
			
			if(isLowerBoundCheck && isMovingForward 
					&& !isMovingBackward
					&& !containOtherFunc)
				return true;
			else 
				return false;
		}
		return true;
	}
	
	
	
	/*
	 * check the upperbound is unchanged in the loop paths
	 * */
	public boolean isUnchanged(Value var, List<LoopPath> paths, PrintStream out){
		for(LoopPath path : paths){
			List<Stmt> pathStmts = path.getpathStmt();
			int varAssignedNum = 0;
			for(Stmt stmt: pathStmts){
				if(!(stmt instanceof JGotoStmt)){
					//out.println(stmt.toString());
					List<ValueBox> defs = stmt.getDefBoxes();
					for(ValueBox def : defs){
						if(def.getValue().equals(var)){
							varAssignedNum++;
						}
					}
				}
			}
			if(varAssignedNum > 2) //loop header and loop tail
				return false;
		}
		return true;
	}


	/* check whether the it contains other BufferedReader functions.
	 * Currently, the only functions that potentially make the stride/loop counter move backwords is 
	 * mark and reset pair.
	 * If it only contains mark, it doesn't matter.
	 */
	private boolean notContainOtherBRfuncs(List<List<String>> newFuncLists, PrintStream out) {
		if(newFuncLists == null || (newFuncLists != null && newFuncLists.size() == 0))
			return false;
		for(List<String> funcs : newFuncLists){
			for(String funcName : funcs){
				if(funcName.equals("reset")){
					return false;
				}
			}
		}
		return true;
	}



	//get the map of BufferedReader instance and List<BufferedReader functions in the loop path>.
	private Map<Value, List<String>> getAllBufferedReaderFuncs(LoopPath path1, List<Stmt> bffReaderStmts, PrintStream out) {
		List<Stmt> pathStmts = path1.getpathStmt();
		List<Stmt> trimedPathStmts = new ArrayList<Stmt>();
		List<Condition> pathConds = new ArrayList<Condition>();
//		pathConds = path1.getconditions();
		pathConds = ExtraCondition.extractEqualConditions(path1, out);
		Map<Value, List<String>> varFuncMap = new HashMap<Value, List<String>>();
		for(Stmt stmt : pathStmts){
			boolean found = false;
			for(Stmt itstmt : bffReaderStmts){
				if(stmt.equals(itstmt)){
					found = true;
					break;
				}
			}
			if(found == true)
				trimedPathStmts.add(stmt);
		}
		Set<Value> refVars = new HashSet<Value>();
		if(pathConds != null && pathConds.size() > 0){
			for(Condition cond : pathConds){
				Value var1 = cond.cond.getOp1();
				refVars.add(var1);
			}
		}
		
		//out.println("refVars = " + refVars);
		for(Stmt stmt : trimedPathStmts){
			//out.println(LoopUtils.stmt_toString(stmt));
			InvokeExpr expression = stmt.getInvokeExpr();
			if(expression instanceof InstanceInvokeExpr 
					&& containIPSstr(expression.getMethodRef().toString())){
			//if(((InstanceInvokeExpr) expression).getBase().getType().toString().contains("java.nio.ByteBuffer")){
				Value insVar = ((InstanceInvokeExpr) expression).getBase();
				//out.println("insVar = " + insVar);
				String funcName = expression.getMethod().getName();
				//out.println("funcName = " + funcName);
				if(varFuncMap.containsKey(insVar)){
					List<String> funcs = varFuncMap.get(insVar);
					funcs.add(funcName);
					varFuncMap.put(insVar, funcs);
				} else {
					List<String> funcs = new ArrayList<String>();
					funcs.add(funcName);
					varFuncMap.put(insVar, funcs);
				}
			}
		}
		return varFuncMap;
	}
	
	/* check whether the Stack instance invokes 
	 * empty() == 0 means the stack is not empty, or
	 * in the exit condition.
	 * */
	private Map<Value, Boolean> checkHasEmptyFunc(LoopPath path1, List<Stmt> bffReaderStmts, PrintStream out) {
		List<Stmt> pathStmts = path1.getpathStmt();
		List<Stmt> trimedPathStmts = new ArrayList<Stmt>();
		List<Condition> pathConds = new ArrayList<Condition>();
//		pathConds = path1.getconditions();
		pathConds = ExtraCondition.extractEqualConditions(path1, out);
		for(Condition cond : pathConds){
			out.println(cond.cond.getOp1().toString() + cond.cond.getSymbol() + cond.cond.getOp2().toString());
		}
		//Map<Value, List<String>> varFuncMap = new HashMap<Value, List<String>>();
		Map<Value, Boolean> varHasBRfunMap = new HashMap<Value, Boolean>();
		for(Stmt stmt : pathStmts){
			boolean found = false;
			for(Stmt itstmt : bffReaderStmts){
				if(stmt.equals(itstmt)){
					found = true;
					break;
				}
			}
			if(found == true)
				trimedPathStmts.add(stmt);
		}
		
		Set<Value> refVars = new HashSet<Value>();// ==0
		if(pathConds != null && pathConds.size() > 0){
			for(Condition cond : pathConds){
				Value var1 = cond.cond.getOp1();
				Value var2 = cond.cond.getOp2();
				String op = cond.cond.getSymbol().trim();
				if(var2.toString().equals("0") && op.equals("==")){
					refVars.add(var1);
				}
			}
		}
		for(Value val : refVars){
			out.println("val = " + val.toString());
		}
		for(Stmt stmt : trimedPathStmts){
			out.println(stmt.toString());
			boolean found = false;
			for(ValueBox vb : stmt.getDefBoxes()){
				Value value = vb.getValue();
				if(refVars.contains(value)){
					out.println("found " + value.toString());
					found = true;
					//break;
				}
			}
			if(found){
				InvokeExpr expression = stmt.getInvokeExpr();
				if(expression instanceof InstanceInvokeExpr 
						&& containIPSstr(expression.getMethodRef().toString())){
				//if(((InstanceInvokeExpr) expression).getBase().getType().toString().contains("java.nio.ByteBuffer")){
					Value insVar = ((InstanceInvokeExpr) expression).getBase();
					//out.println("insVar = " + insVar);
					String funcName = expression.getMethod().getName();
					if(funcName.equals("empty")){
						varHasBRfunMap.put(insVar, true);
						break;
					}
				}
			}
		}
		return varHasBRfunMap;
	}

}
