package falsePositivePatterns;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import soot.Body;
import soot.Local;
import soot.SootMethod;
import soot.UnitBox;
import soot.Value;
import soot.ValueBox;
import soot.jimple.AddExpr;
import soot.jimple.CmpExpr;
import soot.jimple.Constant;
import soot.jimple.DivExpr;
import soot.jimple.FieldRef;
import soot.jimple.IfStmt;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.IntConstant;
import soot.jimple.InvokeExpr;
import soot.jimple.JimpleBody;
import soot.jimple.LongConstant;
import soot.jimple.MulExpr;
import soot.jimple.Stmt;
import soot.jimple.SubExpr;
import soot.jimple.internal.JAssignStmt;
import soot.jimple.internal.JGotoStmt;
import soot.jimple.internal.JIfStmt;
import utilities.Condition;
import utilities.LoopPath;
import utilities.MethodUtils;


/* This is a very simple pattern.
 * 1. The variable in the condition has a constant initial value. e.g., i = 0
 * 2. The condition is about a variable compare to 
 *    a constant value OR another variable whose range is determined. e.g., i < num
 * 3. The change of the variable is consistent in all non-exit paths, 
 *    and can only has some basic operations with itself, other constants or other variables in the class initializer.
 * */
public class FPPattern2 {
	private int ArrayUpBound = Integer.MAX_VALUE - 5;//http://stackoverflow.com/questions/3038392/do-java-arrays-have-a-maximum-size
	
	private int canReach_Max = 30;
	/* Pattern 2: like "i = 0; i < num; i++"; 
	 * num is a variable but the range is determined
	 * Usage: only for non-exit loop paths
	 * Constraint: paths must contain path1
	 **/
	/* We also consider "i = num; i > 0; i--" case. 
	 * */
	public boolean compareConstantPattern(Body body, LoopPath path1, List<LoopPath> paths, List<Stmt> methodAllStmts, PrintStream out){
		boolean useOldTerminateFuc = false;
		Map<Value, List<Stmt>> conVarMap = new HashMap<Value, List<Stmt>>();//key:condition var, value:the stmts define/assign this condition var
		List<Condition> path1conds = path1.getconditions(); //all the condition in path1
		if(path1conds == null || path1conds.size() <= 0){
			return false;
		}
		List<ConditionPair<Value, String, Value>> conditionPairList = convertConds(path1conds, path1, out);
		//out.println("The conditionpairs are:");
		//for(ConditionPair<Value, String, Value> condPair : conditionPairList){
		//	out.println(condPair.getFirst() + " : " + condPair.getSecond() + " : " + condPair.getThird());
		//}
//		Set<Stmt> allStmtsb2ThisLoop = new HashSet<Stmt>();
		for(LoopPath path2: paths){
			List<Stmt> path2stmts = path2.getpathStmt();
//			for(Stmt path2stmt : path2stmts){
//				allStmtsb2ThisLoop.add(path2stmt);
//			}
			for(ConditionPair<Value, String, Value> condPair : conditionPairList){
				Value conVar1 = condPair.getFirst();
				//put the other "i > var" conditions in the conVarMap
				//var can be a constant or 
				for(Stmt path2stmt : path2stmts){
					List<ValueBox> defs = path2stmt.getDefBoxes();
					for(ValueBox def : defs){
						if(def.getValue().equals(conVar1)){
							if(conVarMap.containsKey(conVar1)){
								List<Stmt> conVarStmts = conVarMap.get(conVar1);
								conVarStmts.add(path2stmt);
								conVarMap.put(conVar1, conVarStmts);
							} else {
								List<Stmt> conVarStmts = new ArrayList<Stmt>();
								conVarStmts.add(path2stmt);
								conVarMap.put(conVar1, conVarStmts);
							}
						}
					}
				}
			}
		}
		//call compareStmts function.
		Map<List<Value>, Boolean> sameOrNotMap = compareStmts(conVarMap, out);
		
		out.println("sameOrNotMap =" + sameOrNotMap.toString());
		Iterator<Entry<List<Value>, Boolean>> sameOrNotIt = sameOrNotMap.entrySet().iterator();
		Entry<List<Value>, Boolean> sameOrNotEntry = null;
		while(sameOrNotIt.hasNext()){
			sameOrNotEntry = sameOrNotIt.next();
			if(sameOrNotEntry.getValue() == true){ //the condition variable has the same change in all non-exit loop paths
				List<Value> vars = sameOrNotEntry.getKey();
				for(int index = 0; index < vars.size(); index++){
					Value var = vars.get(index);
					out.println("var = " + var);
					if(index != 0){//why do we need index !=0????????????????????
						//add stmts into conVarMap
						for(LoopPath path2: paths){
							List<Stmt> path2stmts = path2.getpathStmt();			
							Value conVar1 = var;
							//put the other "i > var" conditions in the conVarMap
							//var can be a constant or 
							for(Stmt path2stmt : path2stmts){
								List<ValueBox> defs = path2stmt.getDefBoxes();
								for(ValueBox def : defs){
									if(def.getValue().equals(conVar1)){
										if(conVarMap.containsKey(conVar1)){
											List<Stmt> conVarStmts = conVarMap.get(conVar1);
											conVarStmts.add(path2stmt);
											conVarMap.put(conVar1, conVarStmts);
										} else {
											List<Stmt> conVarStmts = new ArrayList<Stmt>();
											conVarStmts.add(path2stmt);
											conVarMap.put(conVar1, conVarStmts);
										}
									}
								}
							}
						}
						
					}
					//0. get the conditions //get from above code
					Condition nonExitCond = null;
					for(Condition condi : path1conds){
						if(condi.cond.getOp1().equals(var)){
							nonExitCond = condi;
						}
					}
					Stmt conVarStmt = null;
					if(conVarMap.containsKey(var)){
						conVarStmt = conVarMap.get(var).get(0); //because all stmts in conVarMap are the same, so just choose the first one is OK
					} else {
						continue;
					}
					ConditionPair<Value, String, Value> nonExitCondPair = null;
					for(ConditionPair<Value, String, Value> condPair : conditionPairList){
						
						if(condPair.getFirst().equals(vars.get(0))){
							if(index == 0){
								nonExitCondPair = condPair;
							} else {
								//add condPair
								ConditionPair<Value, String, Value> newcondPair = new ConditionPair<Value, String, Value>();
								newcondPair.setFirst(var);
								newcondPair.setSecond(condPair.getSecond());
								newcondPair.setThird(condPair.getThird());
								nonExitCondPair = newcondPair;
							}
							out.println("var = " + var.toString() 
								+ ", nonExitCond = " + nonExitCondPair.getFirst() + nonExitCondPair.getSecond() + nonExitCondPair.getThird()
								+ ", conVarStmt = " + conVarStmt.toString());
							//4. check whether can terminate
							if(simpleCheckTerminationNew(body, var, nonExitCondPair, conVarStmt, path1, paths, methodAllStmts, out) == true){					
								return true;
							}
						}
					}
				}
			}
		}
		return false;
	}
	
	/*currently, we only consider this following case:
	 * input : $b6 = l1 cmp l0
	 *         if $b > 0, goto ...
	 * output: if l1 > l0, goto ...
	 */
	public List<ConditionPair<Value, String, Value>> convertConds(List<Condition> conList, LoopPath path, PrintStream out){
		List<ConditionPair<Value, String, Value>> condPairList = new ArrayList<ConditionPair<Value, String, Value>>();
		for(Condition cond : conList){
			//out.println(cond.cond.getOp1() + ":" + cond.cond.getSymbol() + ":" + cond.cond.getOp2());
			ConditionPair<Value, String, Value> condPair = 
					new ConditionPair<Value, String, Value>(cond.cond.getOp1(), cond.cond.getSymbol(), cond.cond.getOp2());
			Value conVar1 = cond.cond.getOp1();
			List<Stmt> pathStmts = path.getpathStmt();
			if(conVar1.toString().contains("$")){//$b
				for(int i = 1; i < pathStmts.size(); i++){
					if(pathStmts.get(i) instanceof JIfStmt && pathStmts.get(i-1) instanceof JAssignStmt){
						JIfStmt ifstmt = (JIfStmt) pathStmts.get(i);
						JAssignStmt assignstmt = (JAssignStmt) pathStmts.get(i-1);
						boolean foundVar1 = false;
						boolean foundcmp = false;
						List<ValueBox> uses = ifstmt.getCondition().getUseBoxes();
						for(ValueBox use : uses){
							if(use.getValue().equals(conVar1)){ //$b > 0
								foundVar1 = true;
								break;
							}
						}
						if(foundVar1 == true){
							List<ValueBox> defs = assignstmt.getDefBoxes();
							for(ValueBox def : defs){
								if(def.getValue().equals(conVar1)){//$b6
									for(ValueBox use : assignstmt.getUseBoxes()){
										if(use.getValue().toString().contains("cmp")){//$b6 = l1 cmp l0
											foundcmp = true;
											break;
										}
									}
								}
							}
							if(foundcmp == true  //if it contains l1 cmp l0, then the 1st usebox is l1 cmp l0, the 2nd is l1, the 3rd is l0
									&& assignstmt.getUseBoxes().size() == 3 
									&& assignstmt.getUseBoxes().get(0).getValue().toString().contains("cmp")){
								condPair.setFirst(assignstmt.getUseBoxes().get(1).getValue());
								condPair.setThird(assignstmt.getUseBoxes().get(2).getValue());
								break;
							}
						}
					}
				}
			}
			condPairList.add(condPair);
		}
		return condPairList;
	}
	
	/* Compare the statements in all paths
	 * These statements are all define/assign the value of conVar.
	 * */
	public Map<List<Value>, Boolean> compareStmts(Map<Value, List<Stmt>> conVarMap, PrintStream out){
		Map<List<Value>, Boolean> sameStmts = new HashMap<List<Value>,Boolean>();
		Iterator<Entry<Value, List<Stmt>>> conVarIt = conVarMap.entrySet().iterator();
		while(conVarIt.hasNext()){
			Entry<Value, List<Stmt>> conVarEntry = conVarIt.next();
			Value conVar = conVarEntry.getKey();
			List<Stmt> conVarStmts = conVarEntry.getValue();
			//out.println(conVar);
			//for(Stmt stmt : conVarStmts){
			//	out.println(stmt.toString());
			//}
			if(conVarStmts != null && conVarStmts.size() > 0){
				Stmt stmt0 = conVarStmts.get(0);
				Value equalVar = null;
				boolean alwaysequal = true;
				if(stmt0.getUseBoxes().size() == 1){
					equalVar = stmt0.getUseBoxes().get(0).getValue();
				}
				for(Stmt stmt : conVarStmts){
					if(!(stmt0.equals(stmt))){ //all statements about conVar are the same
						List<Value> varList = new ArrayList<Value>();
						varList.add(conVar);
						sameStmts.put(varList, false);
						break;
					}
				}
				for(Stmt stmt : conVarStmts){
					if(stmt.getUseBoxes().size() == 1){ //i0=i1
						Value useVar = stmt.getUseBoxes().get(0).getValue();
						if(!useVar.equals(equalVar)){
							alwaysequal = false;
							break;
						}
					}
				}
				if(!sameStmts.containsKey(conVar)){
					List<Value> varList = new ArrayList<Value>();
					varList.add(conVar);
					if(alwaysequal && equalVar != null){
						//sameStmts.put(equalVar, true); ////e.g., i0=i1; i1=i1+(-1), the real condition var is actually i1, not i0
						varList.add(equalVar);
					}
					sameStmts.put(varList, true);
				}
			}
		}
		return sameStmts;
	}

	
	
	/*
	 * get initial value of a variable.
	 * If the initial value is a constant, return this stmt.
	 * otherwise return null
	 * */
	public Stmt getIntialValue(List<Stmt> methodAllStmts, Value var, LoopPath path1){
		Stmt rtnStmt = null;
		Stmt firstStmt = path1.getpathStmt().get(0); //get the first stmt of path1;
		for(Stmt stmt : methodAllStmts){
			for (Iterator boxes = stmt.getDefBoxes().iterator(); boxes.hasNext();) {
				ValueBox box = (ValueBox)boxes.next();
				Value value = box.getValue();
				if(value.equals(var)){
					for(Iterator boxes2 = stmt.getUseBoxes().iterator(); boxes2.hasNext();){
						ValueBox box2 = (ValueBox)boxes2.next();
						Value value2 = box2.getValue();
						if(value2 instanceof Constant){
							rtnStmt = stmt;
						} else {
							rtnStmt = null;
						}
					}
				}
			}
			if(stmt.equals(firstStmt)) //we only explore the definition statement about var, which is before and closest to the loop path.
				break;
		}
		return rtnStmt;
	}
	
	/*
	 * get range of a variable.
	 * 
	 * */
	public RangePair<Integer, Integer> getVarRange(List<Stmt> methodAllStmts, Value var, LoopPath path1, PrintStream out){
		RangePair<Integer, Integer> rtnRange = null;
		Stmt firstStmt = path1.getpathStmt().get(0); //get the first stmt of path1;
		for(Stmt stmt : methodAllStmts){
			for (Iterator boxes = stmt.getDefBoxes().iterator(); boxes.hasNext();) {
				ValueBox box = (ValueBox)boxes.next();
				Value value = box.getValue();
				if(value.equals(var)){
					for(Iterator boxes2 = stmt.getUseBoxes().iterator(); boxes2.hasNext();){
						ValueBox box2 = (ValueBox)boxes2.next();
						Value value2 = box2.getValue();
						if(value2 instanceof IntConstant){
							int firstInt = ((IntConstant) value2).value;
							rtnRange = new RangePair<Integer, Integer>(firstInt, firstInt);
						}/*else if(value2 instanceof LongConstant){
							long firstLong = ((LongConstant) value2).value;
							rtnRange = new RangePair<Object, Object>(firstLong, firstLong);
						}*/
					}
				}
			}
			if(stmt.equals(firstStmt)) //we only explore the definition statement about var, which is before and closest to the loop path.
				break;
		}
		if(rtnRange == null){
			for(Stmt stmt : methodAllStmts){
				for (Iterator boxes = stmt.getUseBoxes().iterator(); boxes.hasNext();) {
					ValueBox box = (ValueBox)boxes.next();
					Value value = box.getValue();
					if(value.getUseBoxes().size() > 0){
						//for(Iterator boxes2 = value.getUseBoxes().iterator(); boxes2.hasNext();){
							//ValueBox box2 = (ValueBox)boxes2.next();
							//Value value2 = box2.getValue();
							//out.println("Value in ValueBox is: " + value);
							if(value.toString().contains(var.toString()) && value.toString().contains("newarray")){
								rtnRange = new RangePair<Integer, Integer>(0, ArrayUpBound);
							}
						//}
					}
				}
			}
		}
		return rtnRange;
	}
	
	/*
	 * This func only simply check whether pattern2 can terminate.
	 * e.g., "var = CONSTANT0; var >/</>=/<=/=/!= CONSTANT1/VARIABLE(with Range); var = (var +/- )CONSTANT2"
	 * true: match FP pattern 2 --- not a infinite loop
	 * false: don't match FP pattern 2 --- still might be an infinite loop
	 * Currently, we only implemented the AddExpr and SubExpr cases. We probably still need to implement the other BiExpr cases
	 * */
	public boolean simpleCheckTermination(Value var, Value initialValue, Condition nonExitCond, 
			RangePair<Integer, Integer> rangePair, Stmt conVarStmt, PrintStream out){
		boolean containVar = false;
		for (Iterator boxes = conVarStmt.getUseBoxes().iterator(); boxes.hasNext();) {
			ValueBox box = (ValueBox)boxes.next();
			Value value = box.getValue();
			if (value.getUseBoxes().size() == 0 && value == var) {
				containVar = true;
			}
		}
		if(containVar){ // var = CONSTANT0; var >/</>=/<=/=/!= CONSTANT1; var = var + CONSTANT2
			if(!(initialValue instanceof IntConstant)){
				//out.println("initialValue is not a IntConstant");
				return false;  // we assume that all the variables are Integer
			}
			IntConstant ini = (IntConstant) initialValue;
			int initialInt = ini.value;
			//out.print("nonExitCond.cond.getOp2() is ");
			//out.println(nonExitCond.cond.getOp2());
			int endLowerBound = rangePair.getFirst();
			int endUpperBound = rangePair.getSecond();
			//IntConstant endi = (IntConstant) nonExitCond.cond.getOp2();
			//int endInt = endi.value;
			for(Iterator boxes = conVarStmt.getUseBoxes().iterator(); boxes.hasNext();){
				ValueBox box = (ValueBox)boxes.next();
				Value value = box.getValue();
				if(value instanceof AddExpr){ // var = var + CONSTANT
					//out.println(value + " is an AddExpr");
					AddExpr ae = (AddExpr) value;
					Value lo = ae.getOp1();
					Value ro = ae.getOp2();
					int strideInt = 0;
					if(lo instanceof IntConstant){
						IntConstant loi = (IntConstant) lo;
						strideInt = loi.value;
					} else if (ro instanceof IntConstant){
						IntConstant roi = (IntConstant) ro;
						strideInt = roi.value;
					}
					if(strideInt == 0)
						return false; //don't match
					String symbol = nonExitCond.cond.getSymbol().trim();
					if(endLowerBound == endUpperBound){
						int times = (endLowerBound-initialInt)/strideInt;
						if (times > 0){
							if(symbol.equals("<") || symbol.equals("<=")) //loop can terminate
								return true; //e.g., i = 0; i < 2; i++
							else 
								return false; // not sure. e.g., i = 0; i != 3; i = i+2
						} else if (times == 0){
							if(symbol.equals(">=")) // e.g., i = 2; i >= 2; i++
								return false;
							else 
								return true; //loop can terminate
						} else {
							if(symbol.equals(">=") || symbol.equals(">") || symbol.equals("!=")) //e.g., i = 3; i >=/> 2; i++
								return false;
							else 
								return true;//loop can terminate
						}
					} else if (endLowerBound < endUpperBound) { //endLowerBound should be smaller than endUpperBound
						if(initialInt <= endLowerBound){
							if(!symbol.equals("!=")){ // as long as it is not "!=", it can always terminate.
								return true;
							} else 
								return false;         // e.g., e.g., i = 0; i != 3; i = i+2
						} else if (initialInt >= endLowerBound && initialInt <= endUpperBound){
							if(symbol.equals("<=") || symbol.equals("<") || symbol.equals("==")){
								return true; //e.g., i = 2; i < num; i++; range=[1,3]
							} else if (symbol.equals(">=") || symbol.equals(">") || symbol.equals("!=")){
								return false;//e.g., i = 2; i > num; i++; range=[1,3], num=1
							}
						} else if (initialInt >= endUpperBound){
							if(symbol.equals("<=") || symbol.equals("<") || symbol.equals("==")){
								return true; //e.g., i = 5; i < num; i++; range=[1,3]
							} else if (symbol.equals(">=") || symbol.equals(">") || symbol.equals("!=")){
								return false;//e.g., i = 5; i > num; i++; range=[1,3]
							}
						}                                             
					}
				} else if (value instanceof SubExpr){ //var = var - CONSTANT
					SubExpr se = (SubExpr) value;
					Value lo = se.getOp1();
					Value ro = se.getOp2();
					int strideInt = 0;
					if(lo instanceof IntConstant){
						IntConstant loi = (IntConstant) lo;
						return false; //e.g., i = 3; i < 2; i = 2-i; for this case, it's hard to get the stride. We simply trim this case. 
					} else if (ro instanceof IntConstant){
						IntConstant roi = (IntConstant) ro;
						strideInt = 0 - roi.value;// stride is negative
					}
					if(strideInt == 0)
						return false; //don't match
					String symbol = nonExitCond.cond.getSymbol().trim();
					
					if(endLowerBound == endUpperBound){
						int times = (endLowerBound-initialInt)/strideInt;
						if (times > 0){
							if(symbol.equals(">") || symbol.equals(">=")) //e.g., i = 2; i > 0; i--
								return true; // loop can terminate
							else 
								return false; // e.g., i = 2; i != 1; i = i-2
						} else if (times == 0){
							if(symbol.equals("<=")) // e.g., i = 2; i <= 2; i--
								return false;
							else 
								return true; // loop can terminate
						} else {
							if(symbol.equals("<=") || symbol.equals("<") || symbol.equals("!=")) //e.g., i = 2; i <=/< 3; i--
								return false;
							else 
								return true; // loop can terminate
						}
					} else if (endLowerBound < endUpperBound){
						if(initialInt <= endLowerBound){
							if(symbol.equals("<=") || symbol.equals("<") || symbol.equals("!=")){
								return false; //e.g., i = 0; i < num; i--; range=[1,3]
							} else if (symbol.equals(">=") || symbol.equals(">") || symbol.equals("==")){
								return true;//e.g., i = 0; i > num; i--; range=[1,3]
							}
						} else if (initialInt >= endLowerBound && initialInt <= endUpperBound){
							if(symbol.equals("<=") || symbol.equals("<") || symbol.equals("!=")){
								return false; //e.g., i = 2; i < num; i--; range=[1,3], num=3
							} else if (symbol.equals(">=") || symbol.equals(">") || symbol.equals("==")){
								return true;//e.g., i = 2; i > num; i--; range=[1,3]
							}
						} else if (initialInt >= endUpperBound){
							if(!symbol.equals("!=")){ // as long as it is not "!=", it can always terminate.
								return true;
							} else 
								return false;         // e.g., e.g., i = 4; i != 3; i = i-2
						} 
					}
				}
			}
			return false;
		} else { // var = CONSTANT0; var >/</>=/<=/=/!= CONSTANT1; var = CONSTANT2
			     // and it is a non-exit loop condition, which means this loop cannot terminate.
			return false;
		}
	}
	
	/*
	 * This func only simply check whether pattern2 can terminate.
	 * e.g., "var = VARIABLE0/CONSTANT0; var < VARIABLE1/CONSTANT1; var = var + CONSTANT2"
	 * true: match FP pattern 2 --- not a infinite loop
	 * false: don't match FP pattern 2 --- still might be an infinite loop
	 * Currently, we only implemented the AddExpr case. We probably still need to implement the other BiExpr cases
	 * Another cases is:
	 * e.g, "var = VARIABLE0/CONSTANT0; var > VARIABLE1/CONSTANT1; var = var - CONSTANT2"
	 * */
	public boolean simpleCheckTerminationNew(Body body, Value var, ConditionPair<Value,String,Value> nonExitCondPair, 
			Stmt conVarStmt, LoopPath path1, List<LoopPath> paths, List<Stmt> methodAllStmts, PrintStream out){
		boolean usecontainVar = false;
		for (Iterator<ValueBox> boxes = conVarStmt.getUseBoxes().iterator(); boxes.hasNext();) {
			ValueBox box = (ValueBox)boxes.next();
			Value value = box.getValue();
			//out.println("useValue = " + value);
			if (value.getUseBoxes().size() == 0 && value == var) {
				usecontainVar = true;
				break;
			}
		}
		if(usecontainVar){  
			for(Iterator<ValueBox> boxes = conVarStmt.getUseBoxes().iterator(); boxes.hasNext();){
				ValueBox box = boxes.next();
				Value value = box.getValue();
				// var = i0, nonExitCond = i0 < $i4, conVarStmt = i0 = i0 + 1
				// var = CONSTANT0/VARIABLE0; var < CONSTANT1; var = var + CONSTANT2/VARIABLE2
				if(value instanceof AddExpr){
					AddExpr ae = (AddExpr) value;
					Value lo = ae.getOp1();
					Value ro = ae.getOp2();
					boolean isStridePos = false;
					if(lo.equals(var)){
						isStridePos = isStridePositive(body, methodAllStmts, ro, path1, out);
					} else if(ro.equals(var)){
						isStridePos = isStridePositive(body, methodAllStmts, lo, path1, out);
					}
					out.println("isStridePos = " + isStridePos);					
					if(isStridePos == true){
						String symbol = nonExitCondPair.getSecond().trim();
						if(nonExitCondPair.getFirst() == var){//var < VARIABLE(upperbound)
							if(isUnchanged(methodAllStmts, nonExitCondPair.getThird(), paths, out)){
								out.println(nonExitCondPair.getThird() + " is unchanged.");
								if(symbol.equals("<") || symbol.equals("<=")){
									return true;
								}
							}
						} else if(nonExitCondPair.getThird() == var){// VARIABLE(upperbound) > var
							if(isUnchanged(methodAllStmts, nonExitCondPair.getFirst(), paths, out)){
								if(symbol.equals(">") || symbol.equals(">=")){
									return true;
								}
							}
						}
					} else {//there is some case that: var = i5, nonExitCond = i5 >= 0, conVarStmt = i5 = i5 + -8
						String symbol = nonExitCondPair.getSecond().trim();
						if(nonExitCondPair.getFirst() == var){//var > VARIABLE(lowerbound)
							if(isUnchanged(methodAllStmts, nonExitCondPair.getThird(), paths, out)){
								out.println(nonExitCondPair.getThird() + " is unchanged.");
								if(symbol.equals(">") || symbol.equals(">=")){
									return true;
								}
							}
						} else if(nonExitCondPair.getThird() == var){// VARIABLE(lowerbound) < var
							if(isUnchanged(methodAllStmts, nonExitCondPair.getFirst(), paths, out)){
								if(symbol.equals("<") || symbol.equals("<=")){
									return true;
								}
							}
						}
					}
				}
				// var = i0, nonExitCond = i0 > $i4, conVarStmt = i0 = i0 - 1
				// var = CONSTANT0/VARIABLE0; var > CONSTANT1; var = var - CONSTANT2/VARIABLE2
				else if(value instanceof SubExpr){
					SubExpr se = (SubExpr) value;
					Value lo = se.getOp1();
					Value ro = se.getOp2();
					boolean isStridePos = false;
					if(lo.equals(var)){
						isStridePos = isStridePositive(body, methodAllStmts, ro, path1, out);
					} 
					out.println("isStridePos = " + isStridePos);
					if(isStridePos == true){
						String symbol = nonExitCondPair.getSecond().trim();
						if(nonExitCondPair.getFirst() == var){//var > VARIABLE(lowerbound)
							if(isUnchanged(methodAllStmts, nonExitCondPair.getThird(), paths, out)){
								out.println(nonExitCondPair.getThird() + " is unchanged.");
								if(symbol.equals(">") || symbol.equals(">=")){
									return true;
								}
							}
						} else if(nonExitCondPair.getThird() == var){// VARIABLE(lowerbound) < var
							if(isUnchanged(methodAllStmts, nonExitCondPair.getFirst(), paths, out)){
								if(symbol.equals("<") || symbol.equals("<=")){
									return true;
								}
							}
						}
					}
				}
			}
			return false;
		} else {
			List<Stmt> commonStmtsinAllPaths = extractSameStmtFromAllPath(paths);
			List<Value> commonDefVarsinAllPaths = extractDefVarFromAllPath(commonStmtsinAllPaths);
			List<Stmt> diffStmtsinAllPaths = extractDiffStmtFromAllPath(paths);
			List<Value> diffDefVarsinAllPaths = extractDefVarFromAllPath(diffStmtsinAllPaths);
			for(Iterator<ValueBox> boxes = conVarStmt.getUseBoxes().iterator(); boxes.hasNext();){
				ValueBox box = boxes.next();
				Value value = box.getValue();
				// var = l1, nonExitCond = l1 < l0, conVarStmt = l1 = l37 + 1L
				// var = CONSTANT0/VARIABLE0; var < CONSTANT1; var = var3 + CONSTANT2/VARIABLE2
			    // var3 = var2 + CONSTANT, var2 = var1 + CONSTANT, var1 = var + CONSTANT
				if(value instanceof AddExpr){
					AddExpr ae = (AddExpr) value;
					Value lo = ae.getOp1();
					Value ro = ae.getOp2();
					boolean isStridePos = false;
					if (canRearchVar(var, lo, commonStmtsinAllPaths, commonDefVarsinAllPaths, diffDefVarsinAllPaths, 0, out)
							&& canRearchVar(var, ro, commonStmtsinAllPaths, commonDefVarsinAllPaths, diffDefVarsinAllPaths, 0, out)){
						isStridePos = true;
					}
					out.println("isStridePos = " + isStridePos);	
					if(isStridePos == true){
						String symbol = nonExitCondPair.getSecond().trim();
						if(nonExitCondPair.getFirst() == var){//var < VARIABLE(upperbound)
							if(isUnchanged(methodAllStmts, nonExitCondPair.getThird(), paths, out)){
								if(symbol.equals("<") || symbol.equals("<=")){
									return true;
								}
							}
						} else if(nonExitCondPair.getThird() == var){// VARIABLE(upperbound) > var
							if(isUnchanged(methodAllStmts, nonExitCondPair.getFirst(), paths, out)){
								if(symbol.equals(">") || symbol.equals(">=")){
									return true;
								}
							}
						}
					}
				}
				// var = l1, nonExitCond = l1 > l0, conVarStmt = l1 = l37 - 1L
				// var = CONSTANT0/VARIABLE0; var > CONSTANT1; var = var3 - CONSTANT2/VARIABLE2
			    // var3 = var2 - CONSTANT, var2 = var1 - CONSTANT, var1 = var - CONSTANT
				else if(value instanceof SubExpr){
					SubExpr se = (SubExpr) value;
					Value lo = se.getOp1();
					Value ro = se.getOp2();
					boolean isStridePos = false;
					if (canRearchVar(var, lo, commonStmtsinAllPaths, commonDefVarsinAllPaths, diffDefVarsinAllPaths, 0, out)
							&& canRearchVar(var, ro, commonStmtsinAllPaths, commonDefVarsinAllPaths, diffDefVarsinAllPaths,0, out)){
						isStridePos = true;
					}
					out.println("isStridePos = " + isStridePos);
					if(isStridePos == true){
						String symbol = nonExitCondPair.getSecond().trim();
						if(nonExitCondPair.getFirst() == var){//var > VARIABLE(lowerbound)
							if(isUnchanged(methodAllStmts, nonExitCondPair.getThird(), paths, out)){
								out.println(nonExitCondPair.getThird() + " is unchanged.");
								if(symbol.equals(">") || symbol.equals(">=")){
									return true;
								}
							}
						} else if(nonExitCondPair.getThird() == var){// VARIABLE(lowerbound) < var
							if(isUnchanged(methodAllStmts, nonExitCondPair.getFirst(), paths, out)){
								if(symbol.equals("<") || symbol.equals("<=")){
									return true;
								}
							}
						}
					}
				}
			}
			
		}
		return false;
	}
	
	public List<Stmt> extractSameStmtFromAllPath(List<LoopPath> paths){
		if(paths == null || paths.size() == 0)
			return null;
		LoopPath path1 = paths.get(0);
		List<Stmt> path1stmts = path1.getpathStmt();
		List<Stmt> commonStmts = new ArrayList<Stmt>();
		for(Stmt path1stmt : path1stmts){
			boolean iscommons = false;
			for(LoopPath path2 : paths){
				boolean iscommon = false;
				for(Stmt path2stmt : path2.getpathStmt()){
					if(path1stmt.equals(path2stmt)){
						iscommon = true;
						break;
					}
				}
				if(iscommon == false){
					iscommons = false;
					break;
				} else {
					iscommons = true;
				}
			}
			if(iscommons == true)
				commonStmts.add(path1stmt);
		}
		return commonStmts;
	}
	
	public List<Value> extractDefVarFromAllPath(List<Stmt> stmts){
		if(stmts == null || stmts.size() == 0)
			return null;
		List<Value> allVars = new ArrayList<Value>();
		for(Stmt stmt : stmts){
			List<ValueBox> defs = stmt.getDefBoxes();
			for(ValueBox def : defs){
				allVars.add(def.getValue());
			}
		}
		return allVars;
	}
	
	
	public List<Stmt> extractDiffStmtFromAllPath(List<LoopPath> paths){
		if(paths == null || paths.size() == 0)
			return null;
		LoopPath path1 = paths.get(0);
		List<Stmt> path1stmts = path1.getpathStmt();
		List<Stmt> diffStmts = new ArrayList<Stmt>();
		for(Stmt path1stmt : path1stmts){
			boolean iscommons = false;
			for(LoopPath path2 : paths){
				boolean iscommon = false;
				for(Stmt path2stmt : path2.getpathStmt()){
					if(path1stmt.equals(path2stmt)){
						iscommon = true;
						break;
					}
				}
				if(iscommon == false){
					iscommons = false;
					break;
				} else {
					iscommons = true;
				}
			}
			if(iscommons == false)
				diffStmts.add(path1stmt);
		}
		return diffStmts;
	}
	
	/*
	 * Input: var, lo
	 * Output: lo is indirectly defined by the var or constant => true
	 *         otherwise => false
	 * */
	private boolean canRearchVar(Value var, Value lo, 
			List<Stmt> commonStmtsinAllPaths, 
			List<Value> commonDefVarsinAllPaths, List<Value> diffDefVarsinAllPaths, int i,
			PrintStream out) {
		if(i > canReach_Max){
			return false;
		}
		if(lo instanceof Constant || lo == var)
			return true;
		else if(diffDefVarsinAllPaths != null && diffDefVarsinAllPaths.contains(lo))
			return false;
		else if(commonDefVarsinAllPaths != null && commonDefVarsinAllPaths.contains(lo)){
			for(Stmt stmt : commonStmtsinAllPaths){
				if(stmt instanceof JAssignStmt){
					boolean containlo = false;
					List<ValueBox> defs = stmt.getDefBoxes();
					for(ValueBox def : defs){
						if(def.getValue() == lo){
							containlo = true;
							break;
						}						
					}
					if(containlo == true){
						List<ValueBox> uses = stmt.getUseBoxes();
						for(ValueBox use : uses){
							if(use.getValue() instanceof AddExpr){
								AddExpr ae = (AddExpr) use.getValue();
								Value l = ae.getOp1();
								Value r = ae.getOp2();
								return canRearchVar(var, l, commonStmtsinAllPaths, commonDefVarsinAllPaths, diffDefVarsinAllPaths, i+1, out)&
									canRearchVar(var, r, commonStmtsinAllPaths, commonDefVarsinAllPaths, diffDefVarsinAllPaths, i+1, out);
							}
						}
					}
				}
			}
		}
		return false; //it is defined outside the loop. We assume it is not reachable
	}

	/* Check whether the stride is positive.
	 * there are 3 cases: the stride is a constant; the stride is not  
	 * */
	public boolean isStridePositive(Body body, List<Stmt> methodAllStmts, Value var, LoopPath path1, PrintStream out){
		//out.println("var is: " + var.toString());
		if(var instanceof IntConstant){
			int varInt = ((IntConstant) var).value;
			if(varInt > 0)
				return true;
		} else if (var instanceof LongConstant){
			long varLong = ((LongConstant) var).value;
			if(varLong > 0)
				return true;
		} else {
			List<Condition> conds = path1.conds;
			for(Condition cond : conds){ // if the stride is a variable, and the value can be determined from the path condition
				Value conVar1 = cond.cond.getOp1();
				Value conVar2 = cond.cond.getOp2();
				String symbol = cond.cond.getSymbol().trim();
				//out.println("conVar1 = " + conVar1 + ", conVar2 = " + conVar2 + ", symbol = " + symbol);
				if(conVar1.equals(var)) { 
					if(conVar2 instanceof IntConstant){
						int conVar2Int = ((IntConstant) conVar2).value;
						if(conVar2Int == 0 && symbol.equals(">"))
							return true;
						else if(conVar2Int > 0 && (symbol.equals(">=") || symbol.equals(">")))
							return true;
					}
				}
			}
			//inter-flow analysis
			// the stride is a variable, it is assgined in the other function.
//			body.getMethod().isConstructor();
			for(SootMethod method : body.getMethod().getDeclaringClass().getMethods()){
				//out.println("methoname = " + method.getName());
				if(method.getName().contains("clinit")){ // currently, we only focus on construction function. Because those variables in the 
					//out.println("methodname = " + method.getName());
					//out.println("hasActiveBody =" + method.hasActiveBody());
					List<Stmt> constucStmts = MethodUtils.getMethodAllStmts(method.getActiveBody());
					Value transVar = getVaribleName(var, methodAllStmts);
					return isStridePositiveinConstructor(transVar, constucStmts, out);
				} 
			}
		}
		return false;
	}
	
	/*Get the assignment value.
	* This is because the same variable have different reference name in different methods
	*/
	public Value getVaribleName(Value var, List<Stmt> stmts){
		for(Stmt stmt :  stmts){
			if(stmt instanceof JAssignStmt){
				if(var.equals(((JAssignStmt) stmt).leftBox.getValue())){
					return ((JAssignStmt) stmt).rightBox.getValue();
				}
			}
		}
		return null;
	}
	
	//
	public boolean isStridePositiveinConstructor(Value transvar, List<Stmt> stmts, PrintStream out){
		if(transvar == null || stmts == null || (stmts!= null && stmts.size() == 0)){
			return false;
		} else {
			out.println("transVar = " + transvar);
			Value var = null;
			for(int i = stmts.size()-1; i >= 0; i--){
				Stmt stmt = stmts.get(i);
				if(stmt instanceof JAssignStmt){
					out.println("leftbox = " + ((JAssignStmt) stmt).leftBox.getValue());
					if (((JAssignStmt) stmt).leftBox.getValue().toString().equals(transvar.toString())){ //seems like the two Values are not the same,
						var = ((JAssignStmt) stmt).rightBox.getValue();                                  //but the strings are the same.
						break;
						//return isStridePositiveinConstructorDFS(var, stmts, i-1);
					}
				}
			}
			if(var != null &&
					retrivePositiveVars(stmts, out).contains(var)){
				return true;
			}
		}
		return false;
	}
	
	private List<Value> retrivePositiveVars(List<Stmt> stmts, PrintStream out){
		List<Value> posVars = new ArrayList<Value>();
		List<String> posStrs = new ArrayList<String>(); //Sometimes, two Values are not equal, even though their strings are the same.
		for(Stmt stmt : stmts){
			if(stmt instanceof JAssignStmt){
				Value leftvar = ((JAssignStmt) stmt).leftBox.getValue();
				Value rightvar = ((JAssignStmt) stmt).rightBox.getValue();
				if(posVars.contains(rightvar) || posStrs.contains(rightvar.toString())){
					posVars.add(leftvar);
					posStrs.add(leftvar.toString());
				}
				else if(isPosConstant(rightvar)){
					posVars.add(leftvar);
					posStrs.add(leftvar.toString());
				}
				else if(isPosFunction(rightvar)){
					posVars.add(leftvar);
					posStrs.add(leftvar.toString());
				}
				else if(rightvar instanceof AddExpr){
					AddExpr ae = (AddExpr) rightvar;
					Value lo = ae.getOp1();
					Value ro = ae.getOp2();
					if(isPosConstant(lo) && posVars.contains(ro)
							|| posVars.contains(lo) && isPosConstant(ro)
							|| posVars.contains(lo) && posVars.contains(ro)
							|| isPosConstant(lo) && isPosConstant(ro)){
						posVars.add(leftvar);
						posStrs.add(leftvar.toString());
					}
				}
				//out.println("positive vars = " + posStrs);
			}
		}
		
		return posVars;
	}
	
	private boolean isPosFunction(Value var){
		String str = var.toString();
		if(str.contains("virtualinvoke") || str.contains("staticinvoke")){
			if(str.contains("sizeof"))
				return true;
		}
		return false;
	}
	
	private boolean isPosConstant(Value var){
		if(var instanceof IntConstant){
			int varInt = ((IntConstant) var).value;
			if(varInt > 0)
				return true;
		}
		else if(var instanceof LongConstant){
			long varLong = ((LongConstant) var).value;
			if(varLong > 0)
				return true;
		}
		return false;
	}
	
	/*private boolean isStridePositiveinConstructorDFS(Value var, List<Stmt> stmts, int pos) {
		if(pos < 0)
			return false;
		Stmt stmt = stmts.get(pos);
		if(stmt instanceof JAssignStmt){
			if(((JAssignStmt) stmt).leftBox.getValue().equals(var)){
				Value rightVar = ((JAssignStmt) stmt).rightBox.getValue();
				if(rightVar instanceof IntConstant){
					int varInt = ((IntConstant) rightVar).value;
					if(varInt > 0)
						return true;
				} else if (rightVar instanceof LongConstant){
					long varLong = ((LongConstant) rightVar).value;
					if(varLong > 0)
						return true;
				} else if (rightVar instanceof AddExpr){
					AddExpr ae = (AddExpr) rightVar;
					Value lo = ae.getOp1();
					Value ro = ae.getOp2();
					return isStridePositiveinConstructorDFS(lo, stmts, pos-1) && isStridePositiveinConstructorDFS(ro, stmts, pos-1);
				} else if (rightVar instanceof ){
					
				}
			}
		}
		return isStridePositiveinConstructorDFS(var, stmts, pos-1);
		
		if(var instanceof IntConstant){
			int varInt = ((IntConstant) var).value;
			if(varInt > 0)
				return true;
		} else if (var instanceof LongConstant){
			long varLong = ((LongConstant) var).value;
			if(varLong > 0)
				return true;
		} else if (var instanceof AddExpr){
			AddExpr ae = (AddExpr) var;
			Value lo = ae.getOp1();
			Value ro = ae.getOp2();
			return isStridePositiveinConstructorDFS(lo, stmts, pos-1) && isStridePositiveinConstructorDFS(ro, stmts, pos-1);
		} else if (var instanceof Local){ //it is a local variable.
			for(int i = pos; i >= 0; i--){
				Stmt stmt = stmts.get(i);
				
			}
		}
		return false;
	}*/

	
	/*
	 * check the upperbound is unchanged in the loop paths
	 * If the upperbound is an instance invoke expression, we need to check whether the return value of this expression is change.
	 * Currently, we only consider the ByteBuffer instance case.
	 * And in FP Pattern3 class, we have the isUnchangedLimit function to check whether the limit of this BB instance is changed.
	 * To support other class is TBD...
	 * */
	public boolean isUnchanged(List<Stmt> methodAllStmts, Value var, List<LoopPath> paths, PrintStream out){
		List<ValueBox> assignVar = null;
		for(LoopPath path : paths){
			List<Stmt> pathStmts = path.getpathStmt();
			int varAssignedNum = 0;
			for(int i = 0; i < pathStmts.size()-1; i++){ //the head and tail statements are the same in the loop path.
				Stmt stmt = pathStmts.get(i);
				if(stmt instanceof JAssignStmt){
					//out.println(stmt.toString());
					List<ValueBox> defs = stmt.getDefBoxes();
					for(ValueBox def : defs){
						if(def.getValue().equals(var)){
							assignVar = ((JAssignStmt)stmt).getUseBoxes();
							varAssignedNum++;
						}
					}
				}
			}
			if(varAssignedNum > 1) //assigned more than once.
				return false;
		}
		if(assignVar != null){
			out.println("assginVar = " + assignVar);
			for(ValueBox valuebox : assignVar){
				if(valuebox.getValue() instanceof InvokeExpr){
					InvokeExpr expression = (InvokeExpr) valuebox.getValue();
					if(expression instanceof InstanceInvokeExpr){
						//Value refVar = ((InstanceInvokeExpr) expression).getBase();
						if(expression.getMethodRef().toString().contains("java.nio.ByteBuffer")){
							FPPattern3 checkFPpattern3 = new FPPattern3();
							if(checkFPpattern3.isUnchangedLimit(paths, methodAllStmts, out) == false)
								return false;
						}
					}
				}
			}
		}
		return true;
	}

}

class RangePair<F, S> {
    private F first; //first member of pair
    private S second; //second member of pair

    public RangePair(F first, S second) {
        this.first = first;
        this.second = second;
    }

    public RangePair() {
		// TODO Auto-generated constructor stub
	}

	public void setFirst(F first) {
        this.first = first;
    }

    public void setSecond(S second) {
        this.second = second;
    }

    public F getFirst() {
        return first;
    }

    public S getSecond() {
        return second;
    }
}


class ConditionPair<F,S,T>{
    private F first; // a
    private S second;// >
    private T third; // b

    public ConditionPair(F first, S second, T third) {
        this.first = first;
        this.second = second;
        this.third = third;
    }

    public ConditionPair() {

    }
    
    public void setFirst(F first) {
    	this.first = first;    
    }

    public void setSecond(S second) {
    	this.second = second;
    }
    
    public void setThird(T third){
    	this.third = third;
    }

    public F getFirst() {
        return first;
    }

    public S getSecond() {
        return second;
    }
    
    public T getThird(){
    	return third;
    }
}