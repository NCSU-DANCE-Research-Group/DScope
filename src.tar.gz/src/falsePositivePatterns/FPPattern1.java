package falsePositivePatterns;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import soot.Value;
import soot.ValueBox;
import soot.jimple.AddExpr;
import soot.jimple.Constant;
import soot.jimple.DivExpr;
import soot.jimple.FieldRef;
import soot.jimple.IntConstant;
import soot.jimple.JimpleBody;
import soot.jimple.MulExpr;
import soot.jimple.Stmt;
import soot.jimple.SubExpr;
import utilities.Condition;
import utilities.LoopPath;


/* This is a very simple pattern.
 * 1. The variable in the condition has a constant initial value. e.g., i = 0
 * 2. The condition is about a variable and a constant value. e.g., i > 3
 * 3. The change of the variable is consistent in all non-exit paths, 
 *    and can only has some basic operations with itself and other constants.
 * */
public class FPPattern1 {
	
	/* Pattern 1: like "i = 0; i > 3; i++"
	 * Usage: only for non-exit loop paths
	 * Constraint: paths must contain path1
	 **/
	public boolean compareConstantPattern(LoopPath path1, List<LoopPath> paths, List<Stmt> methodAllStmts, PrintStream out){ 
		//List<Stmt> path1stmts = path1.getpathStmt();
		Map<Value, List<Stmt>> conVarMap = new HashMap<Value, List<Stmt>>();
		List<Condition> path1conds = path1.getconditions(); //all the condition in path1
		if(path1conds == null || path1conds.size() <= 0){
			//out.println("path1conds size is 0");
			return false;
		}
		for(LoopPath path2: paths){
			List<Stmt> path2stmts = path2.getpathStmt();			
			//List<Value> path1conVars = new ArrayList<Value>();
			for(Condition cond : path1conds){
				Value conVar1 = cond.cond.getOp1();
				Value conVar2 = cond.cond.getOp2();
				if(!(conVar2 instanceof Constant)){
					continue; //not match pattern "var cmp Constant", e.g., "i > 3"
				}
				//put the other "i > 3" conditions in the conVarMap
				for(Stmt path2stmt : path2stmts){
					List<ValueBox> defs = path2stmt.getDefBoxes();
					for(ValueBox def : defs){
						if(def.getValue().equals(conVar1)){
							if(conVarMap.containsKey(conVar1)){
								List<Stmt> conVarStmts = conVarMap.get(conVar1);
								conVarStmts.add(path2stmt);
								conVarMap.put(conVar1, conVarStmts);
							} else {
								List<Stmt> conVarStmts = new ArrayList<Stmt>();
								conVarStmts.add(path2stmt);
								conVarMap.put(conVar1, conVarStmts);
							}
						}
					}
				}
			}
		}
		//out.print("conVarMap is: ");
		//out.println(conVarMap);
		//call compareStmts function.
		Map<Value, Boolean> sameOrNotMap = compareStmts(conVarMap);
		//out.print("sameOrNotMap is: ");
		//out.println(sameOrNotMap);
		Iterator<Entry<Value, Boolean>> sameOrNotIt = sameOrNotMap.entrySet().iterator();
		while(sameOrNotIt.hasNext()){
			Entry<Value, Boolean> sameOrNotEntry = sameOrNotIt.next();
			Value var = sameOrNotEntry.getKey();
			if(sameOrNotEntry.getValue() == true){ //the condition variable has the same change in all non-exit loop paths
				//1. get the consistent definition statements from all paths  //get from the above Map
				Stmt conVarStmt = conVarMap.get(var).get(0); //because all stmts in conVarMap are the same, so just choose the first one is OK
				boolean containOtherPara = false;
				//out.println("var = " + var.toString());
				for (Iterator boxes = conVarStmt.getUseBoxes().iterator(); boxes.hasNext();) {
					ValueBox box = (ValueBox)boxes.next();
					Value value = box.getValue();
					//out.println("value = " + value.toString());
					if (value.getUseBoxes().size() == 0 //to avoid "i25 + 1"
							&& !(value instanceof Constant || value == var)) {
						containOtherPara = true;
					}
				}
				//out.println("containOtherPara == " + containOtherPara);
				if(containOtherPara == true) //var = otherVar + ....
					continue; //not match pattern "var = var + CONSTANT or var = CONSTANT"
				
				//2. get the initial value //search the statement not in loop
				Stmt initialStmt = getIntialValue(methodAllStmts, var, path1);
				if(initialStmt == null){
					continue; //not match pattern "var = Constant", e.g.,"i = 0";
				}
				if(initialStmt.getUnitBoxes().size() > 1){ 
					continue; //we now only care about "var = Constant1", not "var = Constant1 +/-/*... Constant2"
				}
				Value initialValue = initialStmt.getUseBoxes().get(0).getValue(); //because the initialStmt is just define the var with a Constant
				//3. get the conditions //get from above code
				Condition nonExitCond = null;
				for(Condition condi : path1conds){
					if(condi.cond.getOp1().equals(var)){
						nonExitCond = condi;
					}
				}
				/*out.println("var = " + var.toString() 
						+ ", initialValue = " + initialValue.toString() 
						+ ", nonExitCond = " + nonExitCond.toString() 
						+ ", conVarStmt = " + conVarStmt.toString());*/
				//4. check whether can terminate
				if(simpleCheckTermination(var, initialValue, nonExitCond, conVarStmt, out) == true){
					//as long as there is a non-exit condition can terminate in the non-exit loop path/conditions,
					//this loop is a false positive, can return immediately.
					return true;
				}
			}
		}
		return false;
	}
	
	
	/* Compare the statements in all paths
	 * These statements are all define/assign the value of conVar.
	 * */
	public Map<Value, Boolean> compareStmts(Map<Value, List<Stmt>> conVarMap){
		Map<Value, Boolean> sameStmts = new HashMap<Value,Boolean>();
		Iterator<Entry<Value, List<Stmt>>> conVarIt = conVarMap.entrySet().iterator();
		while(conVarIt.hasNext()){
			Entry<Value, List<Stmt>> conVarEntry = conVarIt.next();
			Value conVar = conVarEntry.getKey();
			List<Stmt> conVarStmts = conVarEntry.getValue();
			if(conVarStmts != null && conVarStmts.size() > 0){
				Stmt stmt0 = conVarStmts.get(0);
				for(Stmt stmt : conVarStmts){
					if(!(stmt0.equals(stmt))){ //all statements about conVar are the same
						sameStmts.put(conVar, false);
						break;
					}
				}
				if(!sameStmts.containsKey(conVar)){
					sameStmts.put(conVar, true);
				}
			}
		}
		return sameStmts;
	}
	
	
	/* Two condition has the same variables but opposite operators.
	 * e.g., a > b and a <= b
	 * */
	public boolean oppositeCondition(Condition cond1, Condition cond2){
		if(cond1.equals(cond2))
			return false;
		else if(cond1.cond.getOp1().equals(cond2.cond.getOp1())
				&& cond1.cond.getOp2().equals(cond2.cond.getOp2())){
			String symbol1 = cond1.cond.getSymbol().trim();
			String symbol2 = cond2.cond.getSymbol().trim();
			if(symbol1.equals(">=") && symbol2.equals("<"))
				return true;
			if(symbol1.equals("<=") && symbol2.equals(">"))
				return true;
			if(symbol1.equals("=") && (symbol2.equals(">") || symbol2.equals("<")))
				return true;
			if(symbol1.equals(">") && (symbol2.equals("<") || symbol2.equals("<=") || symbol2.equals("=")))
				return true;
			if(symbol1.equals("<") && (symbol2.equals(">") || symbol2.equals(">=") || symbol2.equals("=")))
				return true;
		}
		return false;
	}
	
	/*
	 * get initial value of a variable.
	 * If the initial value is a constant, return this stmt.
	 * otherwise return null
	 * */
	public Stmt getIntialValue(List<Stmt> methodAllStmts, Value var, LoopPath path1){
		Stmt rtnStmt = null;
		Stmt firstStmt = path1.getpathStmt().get(0); //get the first stmt of path1;
		for(Stmt stmt : methodAllStmts){
			for (Iterator boxes = stmt.getDefBoxes().iterator(); boxes.hasNext();) {
				ValueBox box = (ValueBox)boxes.next();
				Value value = box.getValue();
				if(value.equals(var)){
					for(Iterator boxes2 = stmt.getUseBoxes().iterator(); boxes2.hasNext();){
						ValueBox box2 = (ValueBox)boxes2.next();
						Value value2 = box2.getValue();
						if(value2 instanceof Constant){
							rtnStmt = stmt;
						} else {
							rtnStmt = null;
						}
					}
				}
			}
			if(stmt.equals(firstStmt)) //we only explore the definition statement about var, which is before and closest to the loop path.
				break;
		}
		return rtnStmt;
	}
	
	/*
	 * This func only simply check whether pattern1 can terminate.
	 * e.g., "var = CONSTANT0; var >/</>=/<=/=/!= CONSTANT1; var = (var +/- )CONSTANT2"
	 * true: match FP pattern 1 --- not a infinite loop
	 * false: don't match FP pattern 1 --- still might be an infinite loop
	 * Currently, we only implemented the AddExpr and SubExpr cases. We probably still need to implement the other BiExpr cases
	 * */
	public boolean simpleCheckTermination(Value var, Value initialValue, Condition nonExitCond, Stmt conVarStmt, PrintStream out){
		boolean containVar = false;
		for (Iterator boxes = conVarStmt.getUseBoxes().iterator(); boxes.hasNext();) {
			ValueBox box = (ValueBox)boxes.next();
			Value value = box.getValue();
			if (value.getUseBoxes().size() == 0 && value == var) {
				containVar = true;
			}
		}
		if(containVar){ // var = CONSTANT0; var >/</>=/<=/=/!= CONSTANT1; var = var + CONSTANT2
			if(!(initialValue instanceof IntConstant)){
				//out.println("initialValue is not a IntConstant");
				return false;  // we assume that all the variables are Integer
			}
			IntConstant ini = (IntConstant) initialValue;
			int initialInt = ini.value;
			//out.print("nonExitCond.cond.getOp2() is ");
			//out.println(nonExitCond.cond.getOp2());
			if(!(nonExitCond.cond.getOp2() instanceof IntConstant)){
				//out.println("nonExitCond.cond.getOp2() is not a IntConstant");
				return false; // we assume that all the variables are Integer
			}
			IntConstant endi = (IntConstant) nonExitCond.cond.getOp2();
			int endInt = endi.value;
			for(Iterator boxes = conVarStmt.getUseBoxes().iterator(); boxes.hasNext();){
				ValueBox box = (ValueBox)boxes.next();
				Value value = box.getValue();
				if(value instanceof AddExpr){ // var = var + CONSTANT
					//out.println(value + " is an AddExpr");
					AddExpr ae = (AddExpr) value;
					Value lo = ae.getOp1();
					Value ro = ae.getOp2();
					int strideInt = 0;
					if(lo instanceof IntConstant){
						IntConstant loi = (IntConstant) lo;
						strideInt = loi.value;
					} else if (ro instanceof IntConstant){
						IntConstant roi = (IntConstant) ro;
						strideInt = roi.value;
					}
					if(strideInt == 0)
						return false; //don't match
					String symbol = nonExitCond.cond.getSymbol().trim();
					//out.println("symbol = " + symbol);
					int times = (endInt-initialInt)/strideInt;
					//out.println("times = "+times);
					if (times > 0){
						if(symbol.equals("<") || symbol.equals("<=")) //loop can terminate
							return true; //e.g., i = 0; i < 2; i++
						else 
							return false; // not sure. e.g., i = 0; i != 3; i = i+2
					} else if (times == 0){
						if(symbol.equals(">=")) // e.g., i = 2; i >= 2; i++
							return false;
						else 
							return true; //loop can terminate
					} else {
						if(symbol.equals(">=") || symbol.equals(">") || symbol.equals("!=")) //e.g., i = 3; i >=/> 2; i++
							return false;
						else 
							return true;//loop can terminate
					}
				} else if (value instanceof SubExpr){ //var = var - CONSTANT
					SubExpr se = (SubExpr) value;
					Value lo = se.getOp1();
					Value ro = se.getOp2();
					int strideInt = 0;
					if(lo instanceof IntConstant){
						IntConstant loi = (IntConstant) lo;
						return false; //e.g., i = 3; i < 2; i = 2-i; for this case, it's hard to get the stride. We simply trim this case. 
					} else if (ro instanceof IntConstant){
						IntConstant roi = (IntConstant) ro;
						strideInt = 0 - roi.value;// stride is negative
					}
					if(strideInt == 0)
						return false; //don't match
					String symbol = nonExitCond.cond.getSymbol().trim();
					int times = (endInt-initialInt)/strideInt;
					if (times > 0){
						if(symbol.equals(">") || symbol.equals(">=")) //e.g., i = 2; i > 0; i--
							return true; // loop can terminate
						else 
							return false; // e.g., i = 2; i != 1; i = i-2
					} else if (times == 0){
						if(symbol.equals("<=")) // e.g., i = 2; i <= 2; i--
							return false;
						else 
							return true; // loop can terminate
					} else {
						if(symbol.equals("<=") || symbol.equals("<") || symbol.equals("!=")) //e.g., i = 2; i <=/< 3; i--
							return false;
						else 
							return true; // loop can terminate
					}
				}
			}
			return false;
		} else { // var = CONSTANT0; var >/</>=/<=/=/!= CONSTANT1; var = CONSTANT2
			     // and it is a non-exit loop condition, which means this loop cannot terminate.
			return false;
		}
	}

}
