package falsePositivePatterns;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import soot.Body;
import soot.Local;
import soot.SootMethod;
import soot.UnitBox;
import soot.Value;
import soot.ValueBox;
import soot.jimple.AddExpr;
import soot.jimple.CmpExpr;
import soot.jimple.Constant;
import soot.jimple.DivExpr;
import soot.jimple.FieldRef;
import soot.jimple.IfStmt;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.IntConstant;
import soot.jimple.InvokeExpr;
import soot.jimple.JimpleBody;
import soot.jimple.LongConstant;
import soot.jimple.MulExpr;
import soot.jimple.Stmt;
import soot.jimple.SubExpr;
import soot.jimple.internal.JAssignStmt;
import soot.jimple.internal.JGotoStmt;
import soot.jimple.internal.JIfStmt;
import soot.jimple.internal.JNewExpr;
import soot.jimple.internal.JSpecialInvokeExpr;
import utilities.Condition;
import utilities.LoopPath;
import utilities.LoopUtils;
import utilities.MethodUtils;


/* This is a very simple pattern.
 * 1. if the loop stride or the loop exit condition is 
 * */
public class FPPatternNotConsiderInterProcTesting {
	
	
	public boolean containFPInstance(String str){
		if(str.contains("java.nio.ByteBuffer:")) return true;
		else if(str.contains("java.nio.IntBuffer:")) return true;
		else if(str.contains("java.util.Iterator:")) return true;
		else if(str.contains("java.util.Enumeration:")) return true;
		else if(str.contains("java.io.BufferedReader:")) return true;
		else if(LoopUtils.containAppIPSClass(str)) return true;
		else if(str.contains("java.util.List:")) return true;
		else if(str.contains("java.util.StringTokenizer:")) return true;
		else if(str.contains("java.io.File:")) return true;
		else if(str.contains("java.nio.channels.FileChannel:")) return true;
		else if(str.contains("java.nio.channels.ServerSocketChannel:")) return true;
		else if(str.contains("java.util.Queue:")) return true;
		else if(str.contains("java.util.regex.Matcher:")) return true;
		else if(str.contains("java.io.DataInput:")) return true;
		else return false;
	}
	
	public boolean checkBoundStrideisInterProc(Body body, LoopPath path1, List<Stmt> methodAllStmts, PrintStream out){
//		Map<Value, List<Stmt>> conVarMap = new HashMap<Value, List<Stmt>>();//key:condition var, value:the stmts define/assign this condition var
		List<Condition> path1conds = path1.getconditions(); //all the condition in path1
		if(path1conds == null || path1conds.size() <= 0){
			return false;
		}
		
		Set<String> invokeOtherFuncVars = new HashSet<String>();
		Map<String, HashSet<String>> dependencyMap = new HashMap<String, HashSet<String>>();
		Set<String> alreadyAnalyzedVars = new HashSet<String>();
		for(Stmt stmt : methodAllStmts){
			if(stmt instanceof JAssignStmt){
				if(stmt.containsInvokeExpr()){
					InvokeExpr expr = stmt.getInvokeExpr();
//					if(!(expr instanceof JSpecialInvokeExpr)){//we do not consider the special invoke expression
						String exprClassName = expr.getMethod().getDeclaringClass().toString();
						if(!exprClassName.startsWith("java")){
							JAssignStmt jstmt = (JAssignStmt)stmt;
							Value var = jstmt.leftBox.getValue();
							invokeOtherFuncVars.add(var.toString());
						} 
						if(exprClassName.equals("java.util.zip.GZIPInputStream")){//for HD023: WritableUtils_readCompressedByteArray
							JAssignStmt jstmt = (JAssignStmt)stmt;
							Value var = jstmt.leftBox.getValue();
							invokeOtherFuncVars.add(var.toString());
						}
						if(exprClassName.equals("java.lang.Long")){//for HD023: TupleWritable_readBitSet
							JAssignStmt jstmt = (JAssignStmt)stmt;
							Value var = jstmt.leftBox.getValue();
							invokeOtherFuncVars.add(var.toString());
						}
						if(exprClassName.equals("java.lang.System")){//for HD023: SocketIOWithTimeout$SelectorPool_select
							JAssignStmt jstmt = (JAssignStmt)stmt;   //this one calls java.lang.System: long currentTimeMillis
							Value var = jstmt.leftBox.getValue();    //it apparently considers the timeout mechanism in the loop
							invokeOtherFuncVars.add(var.toString());
						}
//						if(exprClassName.equals("java.nio.channels.FileChannel")){//for HD023: SocketOutputStream_transferToFully
//							JAssignStmt jstmt = (JAssignStmt)stmt;   //this one calls java.nio.channels.FileChannel: long transferTo
//							Value var = jstmt.leftBox.getValue();    //the FPPattern10 only consider the read function, but not transferTo func 
//							invokeOtherFuncVars.add(var.toString()); //to save time, we just prune all the FileChannel cases
//						}
//					}
				} else {
					JAssignStmt jassgnStmt = (JAssignStmt) stmt;
					Value var = jassgnStmt.leftBox.getValue();
					for(ValueBox vb : stmt.getUseBoxes()){
						Value value = vb.getValue();
						if(value instanceof JNewExpr){
							JNewExpr newExpr = (JNewExpr)value;
							String exprClassName = newExpr.getType().toString();
							if(!exprClassName.startsWith("java")){
								invokeOtherFuncVars.add(var.toString());
							} 
							if(exprClassName.equals("java.util.zip.GZIPInputStream")){//for HD023: WritableUtils_readCompressedByteArray
								invokeOtherFuncVars.add(var.toString());
							}
							if(exprClassName.equals("java.lang.Long")){//for HD023: TupleWritable_readBitSet
								invokeOtherFuncVars.add(var.toString());
							}
							if(exprClassName.equals("java.lang.System")){//for HD023: SocketIOWithTimeout$SelectorPool_select
								invokeOtherFuncVars.add(var.toString());
							}
//							if(exprClassName.equals("java.nio.channels.FileChannel")){//for HD023: SocketOutputStream_transferToFully
//								invokeOtherFuncVars.add(var.toString()); //to save time, we just prune all the FileChannel cases
//							}
						}
					}
				}
			}
			if(stmt.containsInvokeExpr()){
				InvokeExpr expr = stmt.getInvokeExpr();
				if(expr instanceof InstanceInvokeExpr && containFPInstance(expr.getMethod().getSignature())){
					Value insVar = ((InstanceInvokeExpr) expr).getBase();
					out.println(expr.getMethod().getSignature());
					alreadyAnalyzedVars.add(insVar.toString());
				}
			}
		}
		
		for(Stmt stmt : path1.getpathStmt()){//dependency map is retrieved from the current path's statements
			if(stmt instanceof JAssignStmt){
				JAssignStmt jstmt = (JAssignStmt)stmt;
				Value var = jstmt.leftBox.getValue();
				if(dependencyMap.containsKey(var)){
					HashSet<String> uses = dependencyMap.get(var.toString());
					for(ValueBox vb : stmt.getUseBoxes()){
						if(!vb.getValue().equals(var))
							uses.add(vb.getValue().toString());
					}
					dependencyMap.put(var.toString(), uses);
				} else {
					HashSet<String> uses = new HashSet<String>();
					for(ValueBox vb : stmt.getUseBoxes()){
						if(!vb.getValue().equals(var))
							uses.add(vb.getValue().toString());
					}
					dependencyMap.put(var.toString(), uses);
				}
			}
		}
		out.println("alreadyAnalyzedVars:");
		for(String var : alreadyAnalyzedVars){
			out.print(var.toString() + " ");
		}
		out.println();
		out.println("invokeOtherFuncVars:");
		for(String var : invokeOtherFuncVars){
			out.print(var.toString() + " ");
		}
		out.println();
		out.println("dependencyMap:");
		Iterator<Entry<String, HashSet<String>>> it = dependencyMap.entrySet().iterator();
		Entry<String, HashSet<String>> entry = null;
		while(it.hasNext()){
			entry = it.next();
			out.print(entry.getKey().toString() + " : ");
			for(String var : entry.getValue()){
				out.print(var.toString() + " ");
			}
			out.println();
		}
		
		//if a loop has multiple paths, then it will be checked multiple times,
		//each time, the class fileds need to be re-initialized.
		visited = new HashSet<String>();
		shouldStop = false;
		
		
		//if all the conditions reply on the app functions' return,
		// then this is a false positives-----we don't analyze this case
		boolean shouldPrune = false;
		for(Condition condition : path1conds){
			Value condVar1 = condition.cond.getOp1();
			Value condVar2 = condition.cond.getOp2();
			out.println("condVar1 = " + condVar1.toString() + ", condVar2 = " + condVar2.toString());
			if(canReach(condVar1.toString(), dependencyMap, alreadyAnalyzedVars, invokeOtherFuncVars, out) ||
					canReach(condVar2.toString(), dependencyMap, alreadyAnalyzedVars, invokeOtherFuncVars, out)){//this condition depends on the app functions' return
				shouldPrune = true;
			}
		}
		if(shouldStop) { //if one condition contains the analyzed app instance, then, we don't need to consider the other condition
			return false;//it has higher priority than the shouldPrune, which means when an app instance is already analyzed,
		}                //we don't prune it aggressively, we inherit the fine-designed FPPatterns before.
		else {
			return shouldPrune;
		}
	}
	
	private Set<String> visited = new HashSet<String>();
	private boolean shouldStop = false;
	private boolean canReach(String val, Map<String, HashSet<String>> dependencyMap, 
			Set<String> alreadyAnalyzedVars, Set<String> invokeOtherFuncVars, PrintStream out){
		if(invokeOtherFuncVars.contains(val)){
			return true;
		}
		if(dependencyMap.containsKey(val)){
			for(String depVal : dependencyMap.get(val)){
				out.println("depVal = " + depVal);
//				if(depVal.toString().equals("r0.<org.apache.hadoop.hdfs.server.datanode.BlockSender: long offset>")){
//					if(dependencyMap.containsKey(depVal)){
//						out.println("contains....");
//					} else {
//						out.println("does not contain ...");
//					}
//				}
				if(visited.contains(depVal)){
					out.println("already visited");
					continue;
				} else if(alreadyAnalyzedVars.contains(depVal)){
					shouldStop = true;
					return false;
				} else if(invokeOtherFuncVars.contains(depVal)){//invokeOtherFuncVars has lower priority than alreadyAnalyzedVars
					return true;                                //it means when an app instance appear in both set, we do not prune this loop.
				} else {
					visited.add(depVal);
					if (!shouldStop && canReach(depVal, dependencyMap, alreadyAnalyzedVars, invokeOtherFuncVars, out))
						return true;
				}
			}
		}
		visited.add(val.toString());
		return false;
	}


}



