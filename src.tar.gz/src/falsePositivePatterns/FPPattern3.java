package falsePositivePatterns;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import soot.IntType;
import soot.Value;
import soot.ValueBox;
import soot.jimple.AddExpr;
import soot.jimple.Constant;
import soot.jimple.DivExpr;
import soot.jimple.FieldRef;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.IntConstant;
import soot.jimple.InterfaceInvokeExpr;
import soot.jimple.InvokeExpr;
import soot.jimple.JimpleBody;
import soot.jimple.LongConstant;
import soot.jimple.MulExpr;
import soot.jimple.StaticInvokeExpr;
import soot.jimple.Stmt;
import soot.jimple.SubExpr;
import soot.jimple.internal.JAssignStmt;
import soot.jimple.internal.JGotoStmt;
import soot.jimple.internal.JInvokeStmt;
import utilities.Condition;
import utilities.ExtraCondition;
import utilities.LoopPath;


/* This is a customized pattern for ByteBuffer class.
 * Specifically, checking the hasRemaining(), get() pattern.
 * Anything b/w mark(),...,reset() is trimmed.
 * */
public class FPPattern3 {	
	/* Pattern 3: check ByteBuffer related patterns. 
	 * there are a set of FP patterns.
	 * 1st: hasRemaing(), get()
	 **/
	public boolean checkByteBufferPattern(List<LoopPath> paths, List<Stmt> methodAllStmts, PrintStream out){
		//1. extract all the ByteBuffer ref var in all stmts.
		List<Stmt> byteBufferStmts = new ArrayList<Stmt>();
		List<Value> bbInstVar = new ArrayList<Value>();
		for(Stmt stmt : methodAllStmts){
			//out.println(LoopUtils.stmt_toString(stmt));
			if(stmt instanceof JInvokeStmt 
					|| (stmt instanceof JAssignStmt && stmt.containsInvokeExpr())){
				InvokeExpr expression = stmt.getInvokeExpr();
				/*out.println("expression = " + expression);
				out.println("getType = " + expression.getType());//return type
				out.println("getMethodRef = " + expression.getMethodRef());
				out.println("signature = " + expression.getMethodRef().getSignature());
				out.println("subsignature = " + expression.getMethodRef().getSubSignature());
				out.println("MethodName = " + expression.getMethod().getName());//function name
				out.println("getMethod = " + expression.getMethod());
				out.println("declaingClass = " + expression.getMethod().getDeclaringClass());*/
				if(expression.getMethodRef().toString().contains("java.nio.ByteBuffer")){
					byteBufferStmts.add(stmt);
					if(expression instanceof InstanceInvokeExpr){
						//out.println("getBase = "+ ((InstanceInvokeExpr) expression).getBase());//ByteBuffer instance
						//out.println("getBaseType = " +((InstanceInvokeExpr) expression).getBase().getType());
						Value refVar = ((InstanceInvokeExpr) expression).getBase();
						if(!bbInstVar.contains(refVar) 
								&& refVar.getType().toString().contains("java.nio.ByteBuffer")){
							//add BB instance, so just consider those vars invoking funcs in ByteBuffer class
							bbInstVar.add(refVar);
						}
					}
				}
				//StaticInvokeExpr is used for define/assign a new ByteBuffer, e.g., wrap(), encode()
				//InstanceInvokeExpr is used for call a func in ByteBuffer's instance.
				/*if(expression instanceof InstanceInvokeExpr){
					out.println("getBase = "+ ((InstanceInvokeExpr) expression).getBase());//ByteBuffer instance
					out.println("expression = " + expression);
					out.println("getType = " + expression.getType());//return type
					out.println("getMethodRef = " + expression.getMethodRef());
					out.println("signature = " + expression.getMethodRef().getSignature());
					out.println("subsignature = " + expression.getMethodRef().getSubSignature());
					out.println("MethodName = " + expression.getMethod().getName());//function name
					out.println("getMethod = " + expression.getMethod());
					out.println("getBaseType = " +((InstanceInvokeExpr) expression).getBase().getType());
					//Considering two type of funcs:
					//1. invoking funcs in ByteBuffer class
					//2. invoking funcs with argument, this argument is a func in ByteBuffer class
					if(expression.getMethodRef().toString().contains("java.nio.ByteBuffer")){//b/c BB implement Buffer
						byteBufferStmts.add(stmt);
						Value refVar = ((InstanceInvokeExpr) expression).getBase();
						if(!bbInstVar.contains(refVar) 
								&& refVar.getType().toString().contains("java.nio.ByteBuffer")){
							//add BB instance, so just consider those vars invoking funcs in ByteBuffer class
							bbInstVar.add(refVar);
						}
					}
				}*/
			}
		}
		out.println("bbInstVar = "+bbInstVar);
		//2.for each ByteBuffer instance, get all functions in all non-exit paths. 
		//  for each loop path, get a Map<instance, List<functions>>
		/*for(Value refVar : bbInstVar){
			List<List<Map<String, Boolean>>> funcsinAllPaths = new ArrayList<List<Map<String, Boolean>>>();
			for(LoopPath path1 : paths){
				//contains ByteBuffer.hasRemaing() as one of the condition
				//..........
				//
				Map<Value, List<Map<String, Boolean>>> funcMap = getAllByteBufferFuncs(path1, byteBufferStmts, out);
				//out.println("funcMap = " + funcMap);
				if(funcMap.containsKey(refVar)){
					funcsinAllPaths.add(funcMap.get(refVar));
				}
			}
			out.println("funcsinAllPaths = " + funcsinAllPaths);
			if(limitIsUnchanged(funcsinAllPaths, out)){
				//simplify the functions pairs in function list
				List<List<Map<String, Boolean>>> newFuncLists = simplifyBBFuncPairs(funcsinAllPaths, out);
				out.println("newFuncLists = " + newFuncLists);
				//check the index in all path moving forward, but the limit is not changed.
				if(checkByteBufferindex(newFuncLists, out) == true)
					return true;
			} else{//upper-bound is changed, but match another pattern.
				//List<List<Map<String, Boolean>>> newFuncLists = simplifyBBFuncPairs(funcsinAllPaths, out);
				//out.println("newFuncLists = " + newFuncLists);
			}
		}*/
		List<Map<Value, List<Map<String, Boolean>>>> funcsinAllPathsOfallVars = new ArrayList<Map<Value, List<Map<String, Boolean>>>>();
		for(LoopPath path1 : paths){
			Map<Value, List<Map<String, Boolean>>> funcMap = getAllByteBufferFuncs(path1, byteBufferStmts, out);
			funcsinAllPathsOfallVars.add(funcMap);
		}
		out.println("funcsinAllPathsOfallVars = " + funcsinAllPathsOfallVars);
		for(Value refVar : bbInstVar){
			List<List<Map<String, Boolean>>> funcsinAllPaths = new ArrayList<List<Map<String, Boolean>>>();
			for(Map<Value, List<Map<String, Boolean>>> funcMap : funcsinAllPathsOfallVars){
				if(funcMap.containsKey(refVar)){
					funcsinAllPaths.add(funcMap.get(refVar));
				}
			}
			out.println("funcsinAllPaths = " + funcsinAllPaths);
			if(limitIsUnchanged(funcsinAllPaths, out)){
				//simplify the functions pairs in function list
				List<List<Map<String, Boolean>>> newFuncLists = simplifyBBFuncPairs(funcsinAllPaths, out);
				out.println("newFuncLists = " + newFuncLists);
				//check the index in all path moving forward, but the limit is not changed.
				if(checkByteBufferindex(newFuncLists, out) == true) // as long as there is at least one matches this pattern.
					return true;
				//the second pattern is bb.compact and bb.position != 0
			} else{//upper-bound is changed, but match another pattern.
				//List<List<Map<String, Boolean>>> newFuncLists = simplifyBBFuncPairs(funcsinAllPaths, out);
				//out.println("newFuncLists = " + newFuncLists);
			}
		}
		

		return false;
	}
	

	/* 
	 * This function is used in FP Pattern2.
	 * */
	public boolean isUnchangedLimit(List<LoopPath> paths, List<Stmt> methodAllStmts, PrintStream out){
		//1. extract all the ByteBuffer ref var in all stmts.
		List<Stmt> byteBufferStmts = new ArrayList<Stmt>();
		List<Value> bbInstVar = new ArrayList<Value>();
		for(Stmt stmt : methodAllStmts){
			if(stmt instanceof JInvokeStmt 
					|| (stmt instanceof JAssignStmt && stmt.containsInvokeExpr())){
				InvokeExpr expression = stmt.getInvokeExpr();
				if(expression.getMethodRef().toString().contains("java.nio.ByteBuffer")){
					byteBufferStmts.add(stmt);
					if(expression instanceof InstanceInvokeExpr){
						Value refVar = ((InstanceInvokeExpr) expression).getBase();
						if(!bbInstVar.contains(refVar) 
								&& refVar.getType().toString().contains("java.nio.ByteBuffer")){
							//add BB instance, so just consider those vars invoking funcs in ByteBuffer class
							bbInstVar.add(refVar);
						}
					}
				}
			}
		}
		out.println("bbInstVar = "+bbInstVar);
		List<Map<Value, List<Map<String, Boolean>>>> funcsinAllPathsOfallVars = new ArrayList<Map<Value, List<Map<String, Boolean>>>>();
		for(LoopPath path1 : paths){
			Map<Value, List<Map<String, Boolean>>> funcMap = getAllByteBufferFuncs(path1, byteBufferStmts, out);
			funcsinAllPathsOfallVars.add(funcMap);
		}
		out.println("funcsinAllPathsOfallVars = " + funcsinAllPathsOfallVars);
		for(Value refVar : bbInstVar){
			List<List<Map<String, Boolean>>> funcsinAllPaths = new ArrayList<List<Map<String, Boolean>>>();
			for(Map<Value, List<Map<String, Boolean>>> funcMap : funcsinAllPathsOfallVars){
				if(funcMap.containsKey(refVar)){
					funcsinAllPaths.add(funcMap.get(refVar));
				}
			}
			out.println("funcsinAllPaths = " + funcsinAllPaths);
			if(limitIsUnchanged(funcsinAllPaths, out)){
				return true;
			}
		}
		return false;
	}

	//check whether the index of BufferBuffer is moving forward
	// currently, we only support <hasRemaining, get> pair.
	private boolean checkByteBufferindex(List<List<Map<String, Boolean>>> newFuncLists, PrintStream out) {
		if(newFuncLists == null || (newFuncLists != null && newFuncLists.size() == 0))
			return false;
		for(List<Map<String, Boolean>> funcs : newFuncLists){
			boolean isUpperBoundCheck = false;
			boolean isMovingForward = false;
			boolean containOtherFunc = false;
			for(Map<String, Boolean> func : funcs){
				Iterator<Entry<String, Boolean>> funcIt = func.entrySet().iterator();
				while(funcIt.hasNext()){
					Entry<String, Boolean> funcEntry = funcIt.next();
					String funcName = funcEntry.getKey();
					//the first one is not hasRemaining
					//if(indexStart == false && !funcName.equals("hasRemaining"))
					//	return false;
					if(funcName.equals("hasRemaining") || funcName.equals("remaining")){ //this remaining here means that it is in Condition
						isUpperBoundCheck = true;
					} else if(funcName.equals("get") 
							|| funcName.equals("getChar") 
							|| funcName.equals("getDouble")
							|| funcName.equals("getFloat")
							|| funcName.equals("getInt")
							|| funcName.equals("getLong")
							|| funcName.equals("getShort")
							|| funcName.equals("put") 
							|| funcName.equals("putChar") 
							|| funcName.equals("putDouble")
							|| funcName.equals("putFloat")
							|| funcName.equals("putInt")
							|| funcName.equals("putLong")
							|| funcName.equals("putShort")){ //absolute is already trimmed
						isMovingForward = true;
					} else {
						containOtherFunc = true;
					}
				}	
			}
			if(containOtherFunc == true)
				return false; //because we don't know what other BB func will influnce the index
			if(isUpperBoundCheck == false)
				return false; // there is no upper bound check
			if(isMovingForward == false)
				return false;  //there is no moving index forward
		}
		return true;
	}

	// trim all function between mark() and reset()
	// e.g., hasRemaining(), mark(), hasRemaining(), get(), reset(),... => hasRemaing()...
	// also trim get(index) funcs, because index doesn't change in those funcs
	private List<List<Map<String, Boolean>>> simplifyBBFuncPairs(
			List<List<Map<String, Boolean>>> funcsinAllPaths, PrintStream out) {
		List<List<Map<String, Boolean>>> newFuncLists = new ArrayList<List<Map<String, Boolean>>>();
		for(List<Map<String, Boolean>> funcs : funcsinAllPaths){
			List<Map<String, Boolean>> newFuncs = new ArrayList<Map<String, Boolean>>();
			boolean startTrim = false;
			for(Map<String, Boolean> func : funcs){
				Iterator<Entry<String, Boolean>> funcIt = func.entrySet().iterator();
				while(funcIt.hasNext()){
					Entry<String, Boolean> funcEntry = funcIt.next();
					String funcName = funcEntry.getKey();
					boolean relativeOrAbsolute = funcEntry.getValue();//relative is true, absolute is false
					if(funcName.equals("mark")){
						startTrim = true;
					} else if (funcName.equals("reset")){
						startTrim = false;
					} else{
						if((funcName.equals("get") 
								|| funcName.equals("getChar") 
								|| funcName.equals("getDouble")
								|| funcName.equals("getFloat")
								|| funcName.equals("getInt")
								|| funcName.equals("getLong") 
								|| funcName.equals("getShort")
								|| funcName.equals("put") 
								|| funcName.equals("putChar") 
								|| funcName.equals("putDouble")
								|| funcName.equals("putFloat")
								|| funcName.equals("putInt")
								|| funcName.equals("putLong") 
								|| funcName.equals("putShort")) 
								&& relativeOrAbsolute == false)//if it is absolute, position will not change
							continue;
						//else if(funcName.equals("remaining"))//position will not change
						//	continue;
						else if(startTrim == false){// other funcs
							newFuncs.add(func);
						}
					}
				}

			}
			newFuncLists.add(newFuncs);
		}
		return newFuncLists;
	}
	
	/*
	 * check the upperbound is unchanged in the loop paths
	 * In this case, just check whether ByteBuffer.limit() is called.
	 * */
	public boolean limitIsUnchanged(List<List<Map<String, Boolean>>> funcsinAllPaths, PrintStream out){
		for(List<Map<String, Boolean>> funcs : funcsinAllPaths){
			for(Map<String, Boolean> func : funcs){
				Iterator<Entry<String, Boolean>> funcIt = func.entrySet().iterator();
				while(funcIt.hasNext()){
					Entry<String, Boolean> funcEntry = funcIt.next();
					String funcName = funcEntry.getKey();
					boolean relativeOrAbsolute = funcEntry.getValue();//relative is true, absolute is false
					if(funcName.equals("limit") && relativeOrAbsolute == true)//if it is absolute, position will not change
						return false;
					else if(funcName.equals("clear") || funcName.equals("flip"))
						return false;
				}
			}
		}
		return true;
	}


	//get the map of ByteBuffer instance and List<ByteBuffer functions in the loop path>.
	private Map<Value, List<Map<String, Boolean>>> getAllByteBufferFuncs(LoopPath path1, List<Stmt> byteBufferStmts, PrintStream out) {
		List<Stmt> pathStmts = path1.getpathStmt();
		List<Stmt> trimedPathStmts = new ArrayList<Stmt>();
		List<Condition> pathConds = new ArrayList<Condition>();
//		pathConds = path1.getconditions();
		pathConds = ExtraCondition.extractEqualConditions(path1, out);
		Map<Value, List<Map<String, Boolean>>> varFuncMap = new HashMap<Value, List<Map<String, Boolean>>>();
		for(Stmt stmt : pathStmts){
			boolean found = false;
			for(Stmt bbstmt : byteBufferStmts){
				if(stmt.equals(bbstmt)){
					found = true;
					break;
				}
			}
			if(found == true)
				trimedPathStmts.add(stmt);
		}
		Set<Value> refVars = new HashSet<Value>();
		if(pathConds != null && pathConds.size() > 0){
			for(Condition cond : pathConds){
				Value var1 = cond.cond.getOp1();
				refVars.add(var1);
			}
		}
		//out.println("refVars = " + refVars);
		for(Stmt stmt : trimedPathStmts){
			//out.println(LoopUtils.stmt_toString(stmt));
			InvokeExpr expression = stmt.getInvokeExpr();
			//out.println(expression);
			if(expression instanceof InstanceInvokeExpr  
					&& ((InstanceInvokeExpr) expression).getBase().getType().toString().contains("java.nio.ByteBuffer")){
				//out.println("in if branch");
				Value insVar = ((InstanceInvokeExpr) expression).getBase();
				//out.println("insVar = " + insVar);
				String funcName = expression.getMethod().getName();
				//out.println("funcName = " + funcName);
				boolean remainingInCond = false;
				if(funcName.equals("remaining")){
					for(ValueBox defBox : stmt.getDefBoxes()){
						if(refVars.contains(defBox.getValue())){
							remainingInCond = true;
							break;
						}
					}
					if(remainingInCond == false) //if remaining is not used for condition, e.g., remaining() > 0
						continue;                //it get trimmed.
				}
				//out.println("remaining is in Condition.");
				boolean relativeOrAbsolute = false;//relative is true, absolute is false
				if(funcName.equals("get") 
						|| funcName.equals("getChar") 
						|| funcName.equals("getDouble")
						|| funcName.equals("getFloat")
						|| funcName.equals("getInt")
						|| funcName.equals("getLong") 
						|| funcName.equals("getShort")){
					if(expression.getArgCount() == 1 && expression.getArg(0).getType() instanceof IntType){
						relativeOrAbsolute = false;
					} else {
						relativeOrAbsolute = true;
					}
				} else if(funcName.equals("put")
						|| funcName.equals("putChar") 
						|| funcName.equals("putDouble")
						|| funcName.equals("putFloat")
						|| funcName.equals("putInt")
						|| funcName.equals("putLong") 
						|| funcName.equals("putShort")){
					if(expression.getArgCount() == 2){
						relativeOrAbsolute = false;//absolute
					} else {
						relativeOrAbsolute = true;
					}
				} else if(funcName.equals("limit")){
					if(expression.getArgCount() == 1)//relative
						relativeOrAbsolute = true;
				}
				Map<String, Boolean> newFunc = new HashMap<String, Boolean>();
				newFunc.put(funcName, relativeOrAbsolute);
				if(varFuncMap.containsKey(insVar)){
					List<Map<String, Boolean>> funcs = varFuncMap.get(insVar);
					funcs.add(newFunc);
					varFuncMap.put(insVar, funcs);
				} else {
					List<Map<String, Boolean>> funcs = new ArrayList<Map<String, Boolean>>();
					funcs.add(newFunc);
					varFuncMap.put(insVar, funcs);
				}
			} else {
				List<ExprPair<Value, String, List<String>>> bbExprs = convert2BBExpr(expression, out);
				for(ExprPair<Value, String, List<String>> bbExpr : bbExprs){
					Value insVar = bbExpr.getBBVar();
					String funcName = bbExpr.getFuncName();
					List<String> argList = bbExpr.getArgs();
					boolean relativeOrAbsolute = false;
					if(funcName.equals("get") 
							|| funcName.equals("getChar") 
							|| funcName.equals("getDouble")
							|| funcName.equals("getFloat")
							|| funcName.equals("getInt")
							|| funcName.equals("getLong") 
							|| funcName.equals("getShort")){
						if(argList != null && argList.size() == 1 && argList.get(0).equals("int")){
							relativeOrAbsolute = false; //absolute
						} else {
							relativeOrAbsolute = true;
						}
					} else if(funcName.equals("put")
							|| funcName.equals("putChar") 
							|| funcName.equals("putDouble")
							|| funcName.equals("putFloat")
							|| funcName.equals("putInt")
							|| funcName.equals("putLong") 
							|| funcName.equals("putShort")){
						if(argList != null && argList.size() == 2){
							relativeOrAbsolute = false;//absolute
						} else {
							relativeOrAbsolute = true;
						}
					} else if(funcName.equals("limit")){
						if(expression.getArgCount() == 1)//relative
							relativeOrAbsolute = true;
					}
					Map<String, Boolean> newFunc = new HashMap<String, Boolean>();
					newFunc.put(funcName, relativeOrAbsolute);
					if(varFuncMap.containsKey(insVar)){
						List<Map<String, Boolean>> funcs = varFuncMap.get(insVar);
						funcs.add(newFunc);
						varFuncMap.put(insVar, funcs);
					} else {
						List<Map<String, Boolean>> funcs = new ArrayList<Map<String, Boolean>>();
						funcs.add(newFunc);
						varFuncMap.put(insVar, funcs);
					}
				}
			}
			
		}
		return varFuncMap;
	}

	
	private List<ExprPair<Value, String, List<String>>> convert2BBExpr(InvokeExpr expression, PrintStream out) {
		List<ExprPair<Value, String, List<String>>> newExPair = new ArrayList<ExprPair<Value, String, List<String>>>();
//		if(expression instanceof InstanceInvokeExpr){
//			out.println(expression + " is InstanceInvokeExpr");
//		} else {
//			out.println(expression + " is not InstanceInvokeExpr");
//		}
//		out.println(expression.getMethodRef().toString());
//		out.println(((InstanceInvokeExpr) expression).getBase().getType().toString());
		if( expression instanceof InstanceInvokeExpr 
				&& expression.getMethodRef().toString().contains("write(java.nio.ByteBuffer)")){
			String classname = ((InstanceInvokeExpr) expression).getBase().getType().toString();
			if(classname.contains("java.nio.channels.WritableByteChannel")
					|| classname.contains("java.nio.channels.SocketChannel")){ //SocketChannel.write(ByteBuffer)	 
				Value bbVar = expression.getArg(0);
				//out.println(expression);
				ExprPair<Value, String, List<String>> newPair = 
					new ExprPair<Value, String, List<String>>(bbVar, "remaining", new ArrayList<String>());
				newExPair.add(newPair);
				ExprPair<Value, String, List<String>> newPair2 = 
					new ExprPair<Value, String, List<String>>(bbVar, "get", Arrays.asList("byte[]", "int", "int"));
				newExPair.add(newPair2);
			}
		} else if(expression instanceof InstanceInvokeExpr 
				&& expression.getMethodRef().toString().contains("read(java.nio.ByteBuffer)")) {
					//||((InstanceInvokeExpr) expression).getBase().getType().toString().contains("java.nio.channels.SocketChannel"))
			String klassname = ((InstanceInvokeExpr) expression).getBase().getType().toString();
			if(klassname.contains("java.nio.channels.ReadableByteChannel")
					|| klassname.contains("java.nio.channels.SocketChannel")){ //SocketChannel.read(ByteBuffer)
				//out.println(expression);
				Value bbVar = expression.getArg(0);
				ExprPair<Value, String, List<String>> newPair = 
					new ExprPair<Value, String, List<String>>(bbVar, "remaining", new ArrayList<String>());
				newExPair.add(newPair);
				ExprPair<Value, String, List<String>> newPair2 = 
					new ExprPair<Value, String, List<String>>(bbVar, "put", Arrays.asList("byte[]", "int", "int"));
				newExPair.add(newPair2);
			}
		} else if(expression instanceof InstanceInvokeExpr
				&& expression.getMethodRef().toString().contains("unwrap(java.nio.ByteBuffer,java.nio.ByteBuffer)")){
			String classname2 = ((InstanceInvokeExpr) expression).getBase().getType().toString();
			if(classname2.contains("javax.net.ssl.SSLEngine")){ //unwrap(BB, BB)
				Value bbVar = expression.getArg(0);
				ExprPair<Value, String, List<String>> newPair2 = 
					new ExprPair<Value, String, List<String>>(bbVar, "get", null);
				newExPair.add(newPair2);
			}
			
		}
		return newExPair;
	}

}

class ExprPair<F, S, T> {
    private F var1;
    private S var2;
    private T var3;

    public ExprPair(F var1, S var2, T var3) {
        this.var1 = var1;
        this.var2 = var2;
        this.var3 = var3;
    }

    public F getBBVar() {
        return var1;
    }
    
    public S getFuncName(){
    	return var2;
    }
    public T getArgs() {
        return var3;
    }
}
