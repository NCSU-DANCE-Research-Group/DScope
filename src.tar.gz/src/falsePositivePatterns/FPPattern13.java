package falsePositivePatterns;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import soot.ArrayType;
import soot.IntType;
import soot.Local;
import soot.Value;
import soot.ValueBox;
import soot.jimple.AddExpr;
import soot.jimple.Constant;
import soot.jimple.DivExpr;
import soot.jimple.Expr;
import soot.jimple.FieldRef;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.IntConstant;
import soot.jimple.InvokeExpr;
import soot.jimple.JimpleBody;
import soot.jimple.LongConstant;
import soot.jimple.MulExpr;
import soot.jimple.Ref;
import soot.jimple.StaticInvokeExpr;
import soot.jimple.Stmt;
import soot.jimple.SubExpr;
import soot.jimple.internal.JAssignStmt;
import soot.jimple.internal.JGotoStmt;
import soot.jimple.internal.JIdentityStmt;
import soot.jimple.internal.JInvokeStmt;
import soot.jimple.internal.JNewExpr;
import utilities.Condition;
import utilities.ExtraCondition;
import utilities.LoopPath;
import utilities.LoopUtils;


/* This is a customized pattern for Matcher class.
 * Especially using Matcher.find() function.
 * A lot of them checking whether find function reaches the end, returns false.
 * */
public class FPPattern13 {	
	/* Pattern 13: check Matcher related patterns. 
	 * there are a set of FP patterns.
	 **/
	
	public boolean containIPSstr(String str){
		if(str.contains("java.util.regex.Matcher"))
			return true;
		return false;
	}
	
	public boolean checkMatcherPattern(List<LoopPath> paths, List<Stmt> methodAllStmts, PrintStream out){
		//1. extract all the Iterator ref var in all stmts.
		List<Stmt> ipStreamStmts = new ArrayList<Stmt>();
		List<Value> ipsInstVar = new ArrayList<Value>();
//		Map<Value, Value> it2ownerMap = new HashMap<Value, Value>();
		for(Stmt stmt : methodAllStmts){
			if(stmt instanceof JAssignStmt){
				if(stmt.containsInvokeExpr()){
					//out.println("stmt = " + stmt);
					InvokeExpr expression = stmt.getInvokeExpr();
					//out.println("expression = " + expression);
					JAssignStmt jassgnStmt = (JAssignStmt) stmt;
					Value ipStreamVar = jassgnStmt.leftBox.getValue();
//					out.println("getMethodRef = " + expression.getMethodRef().toString());
					if(containIPSstr(expression.getMethodRef().toString())){ 
						ipStreamStmts.add(stmt);
						//out.println("expression.getType = "+expression.getType().toString());
						if(expression instanceof InstanceInvokeExpr){
							Value insVar = ((InstanceInvokeExpr) expression).getBase();
							if(!ipsInstVar.contains(insVar)){
								ipsInstVar.add(insVar);
							}
						}
//						if(containIPSstr(expression.getType().toString())){
//							if(!ipsInstVar.contains(ipStreamVar)){
//								ipsInstVar.add(ipStreamVar);
//							}
////							if(expression instanceof InstanceInvokeExpr){
////								Value refVar = ((InstanceInvokeExpr) expression).getBase();
////								/*out.println("getBase = "+ ((InstanceInvokeExpr) expression).getBase());//ByteBuffer instance
////								out.println("expression = " + expression);
////	Queue							out.println("getType = " + expression.getType());//return type
////								out.println("getMethodRef = " + expression.getMethodRef());
////								out.println("signature = " + expression.getMethodRef().getSignature());
////								out.println("subsignature = " + expression.getMethodRef().getSubSignature());
////								out.println("MethodName = " + expression.getMethod().getName());//function name
////								out.println("getMethod = " + expression.getMethod());
////								out.println("getBaseType = " +((InstanceInvokeExpr) expression).getBase().getType());*/
////							}
//						}
					}	
//				} else {
//					//to handle this case:
//					//BufferedReader lines = new BufferedReader(new InputStreamReader(in));
//					//17: $r12 = new java.io.BufferedReader	class soot.jimple.internal.JAssignStmt
//					//18: $r13 = new java.io.InputStreamReader	class soot.jimple.internal.JAssignStmt
//					//19: specialinvoke $r13.<java.io.InputStreamReader: void <init>(java.io.InputStream)>($r10)	class soot.jimple.internal.JInvokeStmt
//					//20: specialinvoke $r12.<java.io.BufferedReader: void <init>(java.io.Reader)>($r13)	class soot.jimple.internal.JInvokeStmt
//					JAssignStmt jassgnStmt = (JAssignStmt) stmt;
//					Value ipStreamVar = jassgnStmt.leftBox.getValue();
//					for(ValueBox vb : stmt.getUseBoxes()){
//						Value value = vb.getValue();
//						if(value instanceof JNewExpr){
//							JNewExpr newExpr = (JNewExpr)value;
//							if(newExpr.getType().toString().contains("java.io.InputStream")){
//								if(!ipsInstVar.contains(ipStreamVar)){
//									ipsInstVar.add(ipStreamVar);
//								}
//								break;
//							}
//						}
//					}
				}
			} else if(stmt instanceof JIdentityStmt){
				//to handle this case:
				//private String readLine(BufferedReader reader)
				//r1 := @parameter0: java.io.BufferedReader	Type: class soot.jimple.internal.JIdentityStmt
				JIdentityStmt jidStmt = (JIdentityStmt)stmt;
				Value ipStreamVar = jidStmt.leftBox.getValue();
				for(ValueBox vb : stmt.getUseBoxes()){
					Value value = vb.getValue();
					if(containIPSstr(value.toString())){
						if(!ipsInstVar.contains(ipStreamVar)){
							ipsInstVar.add(ipStreamVar);
						}
						break;
					}
				}
			} else if(stmt instanceof JInvokeStmt){
				InvokeExpr expression = stmt.getInvokeExpr();
				if(expression instanceof InstanceInvokeExpr){
					if(containIPSstr(expression.getMethodRef().toString())){
						ipStreamStmts.add(stmt);
						/*out.println("getBase = "+ ((InstanceInvokeExpr) expression).getBase());//ByteBuffer instance
						out.println("expression = " + expression);
						out.println("getType = " + expression.getType());//return type
						out.println("getMethodRef = " + expression.getMethodRef());
						out.println("signature = " + expression.getMethodRef().getSignature());
						out.println("subsignature = " + expression.getMethodRef().getSubSignature());
						out.println("MethodName = " + expression.getMethod().getName());//function name
						out.println("getMethod = " + expression.getMethod());
						out.println("getBaseType = " +((InstanceInvokeExpr) expression).getBase().getType());*/
					}
				}
			}
		}
		out.println("ipsInstVar = " + ipsInstVar);
//		out.println("ipStreamStmts= " + ipStreamStmts);
//		out.println("it2ownerMap = " + it2ownerMap);
		List<Map<Value, List<String>>> funcsinAllPathsOfallVars = new ArrayList<Map<Value, List<String>>>();
		for(LoopPath path1 : paths){
			Map<Value, List<String>> funcMap = getAllInputStreamFuncs(path1, ipStreamStmts, out);
			funcsinAllPathsOfallVars.add(funcMap);
		}
		out.println("funcsinAllPathsOfallVars = " + funcsinAllPathsOfallVars);
		List<Map<Value, Boolean>> funcsinAllCondsOfallVars = new ArrayList<Map<Value, Boolean>>();
		for(LoopPath path1 : paths){
			Map<Value, Boolean> funcMap = checkHasREADFunc(methodAllStmts, path1, ipStreamStmts, out);
			funcsinAllCondsOfallVars.add(funcMap);
		}
		out.println("funcsinAllCondsOfallVars = " + funcsinAllCondsOfallVars);
		
		for(Value ipStreamVar : ipsInstVar){
			boolean readInCond = false;
			for(Map<Value, Boolean> funcMap : funcsinAllCondsOfallVars){
				if(funcMap.containsKey(ipStreamVar) && 
						funcMap.get(ipStreamVar) == true){
					readInCond = true;
					break;
				}
			}
			out.println("readInCond = " + readInCond);
			if(readInCond){
				List<List<String>> funcsinAllPaths = new ArrayList<List<String>>();
				for(Map<Value, List<String>> funcMap : funcsinAllPathsOfallVars){
					if(funcMap.containsKey(ipStreamVar)){
						funcsinAllPaths.add(funcMap.get(ipStreamVar));
					}
				}
				out.println("funcsinAllPaths = " + funcsinAllPaths);
				//if(notContainOtherIPSfuncs(funcsinAllPaths, out) == true)
					return true;
			}
		}

		return false;
	}
	

	/*
	 * check the upperbound is unchanged in the loop paths
	 * */
	private boolean isUnchanged(Value var, List<LoopPath> paths, PrintStream out){
		for(LoopPath path : paths){
			List<Stmt> pathStmts = path.getpathStmt();
			int varAssignedNum = 0;
			for(Stmt stmt: pathStmts){
				if(!(stmt instanceof JGotoStmt)){
					//out.println(stmt.toString());
					List<ValueBox> defs = stmt.getDefBoxes();
					for(ValueBox def : defs){
						if(def.getValue().equals(var)){
							varAssignedNum++;
						}
					}
				}
			}
			if(varAssignedNum > 2) //loop header and loop tail
				return false;
		}
		return true;
	}


	/* check whether the it contains other InputStream functions.
	 * Currently, the only functions that potentially make the stride/loop counter move backwards is 
	 * mark and reset pair.
	 * If it only contains mark, it doesn't matter.
	 */
	private boolean notContainOtherIPSfuncs(List<List<String>> newFuncLists, PrintStream out) {
		if(newFuncLists == null || (newFuncLists != null && newFuncLists.size() == 0))
			return false;
		for(List<String> funcs : newFuncLists){
			for(String funcName : funcs){
				if(funcName.equals("write") || funcName.equals("transferFrom")
						|| funcName.equals("transferTo") || funcName.equals("truncate")){
					return false;
				}
			}
		}
		return true;
	}


	//get the map of InputStream instance and List<InputStream functions in the loop path>.
	private Map<Value, List<String>> getAllInputStreamFuncs(LoopPath path1, List<Stmt> ipStreamStmts, PrintStream out) {
		List<Stmt> pathStmts = path1.getpathStmt();
		List<Stmt> trimedPathStmts = new ArrayList<Stmt>();
		List<Condition> pathConds = new ArrayList<Condition>();
//		pathConds = path1.getconditions();
		pathConds = ExtraCondition.extractEqualConditions(path1, out);
		Map<Value, List<String>> varFuncMap = new HashMap<Value, List<String>>();
		for(Stmt stmt : pathStmts){
			boolean found = false;
			for(Stmt itstmt : ipStreamStmts){
				if(stmt.equals(itstmt)){
					found = true;
					break;
				}
			}
			if(found == true)
				trimedPathStmts.add(stmt);
		}
		Set<Value> refVars = new HashSet<Value>();
		if(pathConds != null && pathConds.size() > 0){
			for(Condition cond : pathConds){
				Value var1 = cond.cond.getOp1();
				refVars.add(var1);
			}
		}
		
		//out.println("refVars = " + refVars);
		for(Stmt stmt : trimedPathStmts){
			//out.println(LoopUtils.stmt_toString(stmt));
			InvokeExpr expression = stmt.getInvokeExpr();
			if(expression instanceof InstanceInvokeExpr 
					&& containIPSstr(expression.getMethodRef().toString())){
			//if(((InstanceInvokeExpr) expression).getBase().getType().toString().contains("java.nio.ByteBuffer")){
				Value insVar = ((InstanceInvokeExpr) expression).getBase();
				//out.println("insVar = " + insVar);
				String funcName = expression.getMethod().getName();
				//out.println("funcName = " + funcName);
				if(varFuncMap.containsKey(insVar)){
					List<String> funcs = varFuncMap.get(insVar);
					funcs.add(funcName);
					varFuncMap.put(insVar, funcs);
				} else {
					List<String> funcs = new ArrayList<String>();
					funcs.add(funcName);
					varFuncMap.put(insVar, funcs);
				}
			}
		}
		return varFuncMap;
	}
	
	//check whether the Matcher instance invokes the find()!= 0 
	private Map<Value, Boolean> checkHasREADFunc(List<Stmt> methodAllStmts, LoopPath path1, List<Stmt> ipStreamStmts, PrintStream out) {
		List<Stmt> pathStmts = path1.getpathStmt();
		List<Stmt> trimedPathStmts = new ArrayList<Stmt>();
		List<Condition> pathConds = new ArrayList<Condition>();
//		pathConds = path1.getconditions();
		pathConds = ExtraCondition.extractEqualConditions(path1, out);
		//Map<Value, List<String>> varFuncMap = new HashMap<Value, List<String>>();
		Map<Value, Boolean> varHasIPSfunMap = new HashMap<Value, Boolean>();
		for(Stmt stmt : pathStmts){
			boolean found = false;
			for(Stmt itstmt : ipStreamStmts){
				if(stmt.equals(itstmt)){
					found = true;
					break;
				}
			}
			if(found == true)
				trimedPathStmts.add(stmt);
		}
		Set<Value> refVars = new HashSet<Value>();
		if(pathConds != null && pathConds.size() > 0){
			for(Condition cond : pathConds){
				Value var1 = cond.cond.getOp1();
				String symbol = cond.cond.getSymbol().trim();
				Value var2 = cond.cond.getOp2();
				if(symbol.equals("!=") && (var2.toString().equals("0") || var2.toString().equals("0L"))){
					refVars.add(var1);
				}
			}
		}
		out.println("refVars = " + refVars);
		out.println("trimedPathStmts = " + trimedPathStmts);
		for(Stmt stmt : trimedPathStmts){
			boolean found = false;
			for(ValueBox vb : stmt.getDefBoxes()){
				Value value = vb.getValue();
				if(refVars.contains(value)){
					found = true;
					break;
				}
			}
			if(found){
				InvokeExpr expression = stmt.getInvokeExpr();
				if(expression instanceof InstanceInvokeExpr 
						&& containIPSstr(expression.getMethodRef().toString())){
				//if(((InstanceInvokeExpr) expression).getBase().getType().toString().contains("java.nio.ByteBuffer")){
					Value insVar = ((InstanceInvokeExpr) expression).getBase();
					//out.println("insVar = " + insVar);
					String funcName = expression.getMethod().getName();
//					out.println(expression.getMethod());//<java.io.DataInputStream: int read(byte[],int,int)>
//					out.println(expression.getMethod().getSubSignature());//int read(byte[],int,int)
					int argCount = expression.getArgCount();
					out.println("argCount = " + argCount);
//					String methodsub = expression.getMethod().getSubSignature();
//					String methodWargs = methodsub.split(" ")[1];
					if(funcName.equals("find")){
						if(argCount == 0){//Matcher.find()
							varHasIPSfunMap.put(insVar, true);
							out.println("matching find()");
							break;
						}else if(argCount == 1){//Matcher.find(int)
							Value firstArg = expression.getArgs().get(0);
							out.println("firstArg = " + firstArg.toString());
							boolean foundread = false;								
							//firstArg is Mather.end
							for(Stmt stmt2 : pathStmts){
								if(stmt2 instanceof JAssignStmt){
									JAssignStmt Jstmt = (JAssignStmt) stmt2;
									if(firstArg.equals(Jstmt.leftBox.getValue())){
										if(Jstmt.containsInvokeExpr()){
											InvokeExpr expr = Jstmt.getInvokeExpr();
											if(containIPSstr(expr.getMethodRef().toString())){
												String funName = expr.getMethod().getName();
												if(funName.equals("end")){
													out.println("matching find(int)");
													foundread = true;
													break;
												}
											}
										}
									}
								}
							}
							if(foundread) {
								varHasIPSfunMap.put(insVar, true);
								break;
							}
							
						}
					}
				}
			}
		}
		return varHasIPSfunMap;
	}

}
