
/* Soot - a J*va Optimization Framework
 * Copyright (C) 2008 Eric Bodden
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */
import java.util.ArrayList;
import java.util.List;

import infiniteLoopDetection.JimpleInterAnalysis;
import infiniteLoopDetection.LoopPathFinder;
import infiniteLoopDetection.LoopTagTransformer;
import infiniteLoopDetection.MethodTagTransformer;
import infiniteLoopDetection.TransformerAdapter;
import soot.Body;
import soot.BodyTransformer;
import soot.G;
import soot.PackManager;
import soot.PhaseOptions;
import soot.SceneTransformer;
import soot.Transform;
import soot.options.Options;

//**get loop exit conditions in a union format***/
//{ [ a==1 and b==2] or [ ...] or ...}
public class MyMain4 {

	public static void main(String[] args) {
		

		List<String> classNames = new ArrayList<String>();
		classNames.add(args[args.length-2]);//the main class
		classNames.add(args[args.length-1]);//the invoked method's class
		TransformerAdapter transAdapter = new TransformerAdapter();
		transAdapter.setClassNames(classNames);
		PackManager.v().getPack("wjtp").add(new Transform("wjtp.myTransform", transAdapter));
//		List<Body> otherClassMethodBodys = transAdapter.getClass2Bodies();
		//System.out.println("otherClassBodies' size = " + otherClassMethodBodys.size());
		
		
//		JimpleInterAnalysis interAnalysis = new JimpleInterAnalysis();
//		interAnalysis.setClassNames(classNames);
//		interAnalysis.setSootString(args);
//		interAnalysis.ananlyzeMultiClasses();
//		List<Body> otherClassMethodBodys = interAnalysis.getClass2Bodies();
//		System.out.println("otherClassBodies' size = " + otherClassMethodBodys.size());
		
		
		
		MethodTagTransformer methodTags = new MethodTagTransformer();
		methodTags.setMethodPrint(true);
		PackManager.v().getPack("jap").add(new Transform("jap.methdTag",methodTags)); //add this transformer during the jap phase

		LoopTagTransformer loopTags = new LoopTagTransformer(); //print all statements of a function contains loop		 
		loopTags.setLoopPrint(true);
		PackManager.v().getPack("jap").add(new Transform("jap.loopTag",loopTags));

		LoopPathFinder pathFinder = new LoopPathFinder();
//		pathFinder.setOtherBodies(otherClassMethodBodys);
		PackManager.v().getPack("jap").add(new Transform("jap.pathFinder", pathFinder));

		// BodyTransformer loopInvariant=new LoopInvariantTransformer();
		// PackManager.v().getPack("jap").add(new Transform("jap.loopInvar",loopInvariant));

//		LineNumberTagTransformer lnTag = new LineNumberTagTransformer();
//		PackManager.v().getPack("jap").add(new Transform("jap.lineInvar", lnTag));

		PhaseOptions.v().setPhaseOption("jj.ne", "on"); // nop eliminator
		PhaseOptions.v().setPhaseOption("jb.ne", "on");
//		PhaseOptions.v().setPhaseOption("jb", "use-original-names:true"); // use original names may cause type assign errors such as in Cassandra, it leads to java.lang.Exception: null typing passed to useChecker
		
		// or Options.v().setPhaseOption("jb", "use-original-names:true");
		PhaseOptions.v().setPhaseOption("jop.uce1", "on"); // unreachable code
		PhaseOptions.v().setPhaseOption("jop.uce2", "on");
		PhaseOptions.v().setPhaseOption("jop.ule", "on"); // unsused local
		PhaseOptions.v().setPhaseOption("jop.ule", "on"); // unsused local
		PhaseOptions.v().setPhaseOption("jap.lit", "on");// Loop Invariant Tagger
		

//		Options.v().set_exclude(List<String> setting);// set exclude packages
//		Options.v().set_no_bodies_for_excluded(true); //This option causes Soot to not load any method bodies of classes from the “exclude” packages
// 		Options.v().set_allow_phantom_refs(true); //-no-bodies-for-excluded implies -allow-phantom-refs, as it uses the phantom-refs mechanism to model classes that are not loaded
		
		
		// Options.v().set_time(true); //Report time required for transformations
		// Options.v().subtract_gc();//Subtract gc from time

		// Options.v().set_version(false); // Display version information and exit
		Options.v().set_keep_line_number(true);// Keep line number tables
		PhaseOptions.v().setPhaseOption("tag.ln", "on"); // The Line Number Tag Aggregator aggregates line number tags.

		
		//-trim-cfgs                   Trim unrealizable exceptional edges from CFGs 

		// Options.v().set_print_tags_in_output(true);
		// //-print-tags(-print-tags-in-output) Print tags in output files after stmt
		// Options.v().set_validate(true);//Run internal validation on bodies
		// Options.v().set_debug(true);

		// Options.v().setPhaseOption("cg", "verbose:false");
		// Options.v().setPhaseOption("cg", "all-reachable:true");
		// Options.v().set_whole_program(true);
		// Options.v().setPhaseOption("cg.spark", "on");
		

		// Options.v().set_src_prec(Options.src_prec_java);
		// //Options.src_prec_class, Options.src_prec_jimple
		// Options.v().set_process_dir(List<String> setting);
		// Options.v().set_soot_classpath(String classpath);
		// Options.v().set_unfriendly_mode(true); // Allow Soot to run with no command-line options
		// Options.v().set_prepend_classpath(false);
		// Options.v().set_whole_shimple(true);
		// Options.v().set_via_shimple(true);

		for (int i = 0; i < args.length; i++) {
			G.v().out.println(i + "	" + args[i]);
		}

		try{
			soot.Main.main(args);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
}