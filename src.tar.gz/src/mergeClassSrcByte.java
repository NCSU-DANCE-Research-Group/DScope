import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Logger;


public class mergeClassSrcByte {
	private static String srcFile="";
	private static String byteFile="";
	private static Map<String, String> srcMap = new HashMap<String, String>();
	private static Map<String, String> byteMap = new HashMap<String, String>();
	public static Logger logger = Logger.getLogger(mergeClassSrcByte.class.getName());
	private static String outputFile="";
	
	public static void main(String[] args){
		
		String argsManual[] = {
				"-srcFile", "/home/ting/DataLoopBugDetection/soot-soot-2.5.0/class.log",
				"-byteFile", "/home/ting/DataLoopBugDetection/soot-soot-2.5.0/classByte.log",
				"-outputFile", "/home/ting/DataLoopBugDetection/soot-soot-2.5.0/classFinal.log"
				};
		handleArgs(args);
		readFile(srcFile, srcMap);
		System.out.println(srcMap.entrySet().size());
		readFile(byteFile, byteMap);
		System.out.println(byteMap.entrySet().size());
		processEachClass();
	}
	
	private static void processEachClass(){
		File outfile = new File(outputFile);
	    if (outfile.exists()) {
	    	outfile.delete();     
	    }
	    
		Iterator<Entry<String, String>> itSrc = srcMap.entrySet().iterator();
		Entry<String, String> entrySrc = null;
		String printStr = "";
		int i = 0;
		while(itSrc.hasNext()){
			entrySrc = itSrc.next();
			String classname = entrySrc.getKey();
			String srcPath = entrySrc.getValue();
			String bytePath = "";
			if(byteMap.containsKey(classname)){
				bytePath = byteMap.get(classname);
				byteMap.remove(classname);
			}
			printStr += classname + ":" + srcPath + ":" + bytePath + "\n";
			if(i == 1000 ){
				write2File(outputFile, printStr);
				printStr = "";
				i = 0;
			}
			i++;
		}
		if(printStr != ""){
			write2File(outputFile, printStr);
		}
		Iterator<Entry<String, String>> itByte = byteMap.entrySet().iterator();
		Entry<String, String> entryByte = null;
		printStr = "";
		i = 0;
		while(itByte.hasNext()){
			entryByte = itByte.next();
			String classname = entryByte.getKey();
			String bytePath = entryByte.getValue();
			printStr += classname + ":" + ":" + bytePath + "\n";
			if(i == 1000 ){
				write2File(outputFile, printStr);
				printStr = "";
				i = 0;
			}
			i++;
		}
		if(printStr != ""){
			write2File(outputFile, printStr);
		}
	}
	
	private static void readFile(String filename, Map<String, String> outputMap){
		InputStream instream = null;
		BufferedReader reader = null;
		String line = "";
		try {
			instream = new FileInputStream(filename);
			reader = new BufferedReader(new InputStreamReader(instream));
			while ((line = reader.readLine()) != null) {
				System.out.println(line);
				String[] splitStr = line.split(":");
				String classname = splitStr[0];
				String srcPath = splitStr[1];
				outputMap.put(classname, srcPath);
			}
		} catch (Exception e) {
//			logger.severe("Exception: " + e.toString());
			e.printStackTrace();
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	public static void write2File(String filename, String content){
		File fout = new File(filename);
		FileOutputStream fos = null;
		BufferedWriter bw = null;
		try {
			fos = new FileOutputStream(fout, true);
			bw = new BufferedWriter(new OutputStreamWriter(fos));
			bw.write(content);
			bw.flush();
			fos.close();
			bw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
    public static void handleArgs(String[] args)
    {
        int argIndex = 0;
        boolean hasSrc = false;
        boolean hasByte = false;
        boolean hasOutput = false;
        while(argIndex < args.length)
        {
            String current = args[argIndex];
            if(current.compareTo("-h") == 0)
            {
                printUsage();
                System.exit(-1);
            }else if(current.compareTo("-srcFile") == 0)
            {
                argIndex++;
                srcFile = args[argIndex];
                hasSrc = true;
            }
            else if(current.compareTo("-byteFile") == 0)
            {
                argIndex++;
                byteFile = args[argIndex];
                hasByte = true;
            }
            else if(current.compareTo("-outputFile") == 0)
            {
                argIndex++;
                outputFile = args[argIndex];
                hasOutput = true;
            }
            else
            {
                System.out.println("current arg:" + current);
                System.out.println("Invalid configuration params, use -h for usage");
                System.exit(-1);
            }
            argIndex++;
        }
        if(!(hasSrc && hasByte && hasOutput)){
        	printUsage();
        	System.exit(-1);
        }
    }
    
    public static void printUsage()
    {
    	System.out.println("Valid options are:");
        System.out.println("java mergeClassSrcByte -srcFile srcFile -byteFile byteFile -outputFile outputFile");
    }
}
