package appIOClasses;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import datastruct.tree.ArrayMultiTreeNode;
import datastruct.tree.TreeNode;
import falsePositivePatterns.FPPattern1;
import falsePositivePatterns.FPPattern2;
import falsePositivePatterns.FPPattern3;
import falsePositivePatterns.FPPattern3Extend;
import falsePositivePatterns.FPPattern4;
import falsePositivePatterns.FPPattern5;
import soot.Body;
import soot.BodyTransformer;
import soot.G;
import soot.Local;
import soot.SootClass;
import soot.SootMethod;
import soot.Type;
import soot.Unit;
import soot.Value;
import soot.ValueBox;
import soot.jimple.Constant;
import soot.jimple.FieldRef;
import soot.jimple.InvokeExpr;
import soot.jimple.JimpleBody;
import soot.jimple.ReturnStmt;
import soot.jimple.Stmt;
import soot.jimple.toolkits.annotation.logic.Loop;
import soot.tagkit.IntegerConstantValueTag;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.LoopNestTree;
import soot.toolkits.graph.UnitGraph;
import soot.util.Chain;
import utilities.Condition;
import utilities.LoopGraph;
import utilities.LoopPath;
import utilities.LoopUtils;
import utilities.MethodUtils;
import utilities.PathExit;

public class ClassExtendImp extends BodyTransformer {

	@Override
	protected void internalTransform(Body body, String phaseName, Map options) {
		// TODO Auto-generated method stub
		String classname = body.getMethod().getDeclaringClass().getName();
		// use signature instead to avoid same-name functions
		String methodname = body.getMethod().getSubSignature();
		
//		String method_declare=body.getMethod().getDeclaration();
//		String class_name=body.getMethod().getDeclaringClass().getType().toString();
		
		G.v().out.println("ClassExtendImp: "+classname + ": " + methodname);

//		if(!LoopUtils.isPrint(body.getMethod().getName())){ //if it is not the targeted function, then do nothing
//			return;
//		}
		
		
//		PrintStream out = null;
//		try{
//			String fname = LoopUtils.getFileName2(classname, methodname, "methods/", ".txt");
//			File f = new File(fname);
//			if(f.exists() && !f.isDirectory()) { 
//				return;
//			}
//			G.v().out.println(fname);
//			out = new PrintStream(new FileOutputStream(fname));
//		} catch(FileNotFoundException e){
//			e.printStackTrace();
//		}
		
		PrintStream out2 = null;
		try{
			String fname2 = LoopUtils.getClassFileName(classname, "classes/", ".txt");
			File f = new File(fname2);
			if(f.exists() && !f.isDirectory()) { 
				out2 = null;
			} else {
				out2 = new PrintStream(new FileOutputStream(fname2));
			}
		} catch(FileNotFoundException e){
			e.printStackTrace();
		}
		
		SootClass klass = body.getMethod().getDeclaringClass();
		
		if(out2 != null){	
//			if(klass.isAbstract()){
//				out2.println("isAbstract=true");
//			} 
//			if(klass.isInterface()){
//				out2.println("isInterface=true");
//			}
			if(klass.getInterfaceCount()>0){
				Chain<SootClass> interfaces = klass.getInterfaces();
				String interfaceKlasses = "";
				for(SootClass interfaceKlass : interfaces){
					interfaceKlasses += interfaceKlass.getName() + ",";
				}
				//if(interfaceKlasses.length()>0)
				interfaceKlasses = interfaceKlasses.substring(0, interfaceKlasses.length() - 1);//delete last ,
				out2.println("implements="+interfaceKlasses);
			}
			if(klass.hasSuperclass()){//interface's super class is java.lang.Object, hasSuperclass()==false
				// Class java.lang.Object is the root of the class hierarchy.
				// Every class has java.lang.Object as a superclass.
				SootClass superClass = klass.getSuperclass();
				out2.println("extends="+superClass.getName());
			}
		}
	}
	
		

}