package falsePositivePatternsNew;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import soot.ArrayType;
import soot.Body;
import soot.IntType;
import soot.Local;
import soot.Value;
import soot.ValueBox;
import soot.jimple.AddExpr;
import soot.jimple.Constant;
import soot.jimple.DivExpr;
import soot.jimple.FieldRef;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.IntConstant;
import soot.jimple.InvokeExpr;
import soot.jimple.JimpleBody;
import soot.jimple.LongConstant;
import soot.jimple.MulExpr;
import soot.jimple.Ref;
import soot.jimple.StaticInvokeExpr;
import soot.jimple.Stmt;
import soot.jimple.SubExpr;
import soot.jimple.internal.JAssignStmt;
import soot.jimple.internal.JGotoStmt;
import soot.jimple.internal.JIdentityStmt;
import soot.jimple.internal.JInvokeStmt;
import soot.jimple.internal.JNewExpr;
import utilities.Condition;
import utilities.ExtraCondition;
import utilities.LoopPath;
import utilities.LoopUtils;
import utilities.MultiMethodUtils;


/* This is a customized pattern for InputStream class.
 * Especially using InputStream.read() function.
 * A lot of them checking whether read function reaches the EOF(-1).
 * Note that, there is some special case if this InputStream is extended by app class and the read() func is overriden,
 * then, when reaches EOF, the read() might not return -1. For example, POI-61300(https://bz.apache.org/bugzilla/show_bug.cgi?id=61300)
 * For this case, we should check whether the read() is overriden in future. To-do!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * */
public class FPPatternInputStream {	
	/* Pattern 6: check InputStream related patterns. 
	 * there are a set of FP patterns.
	 **/
	
	//It can also include the RandomAccessFile.read() functions.
	public boolean containIPSstr(String str){
		return LoopUtils.containAppIPSClass(str);
	}

	
	public boolean checkInputStreamPattern(List<LoopPath> paths, Body body, PrintStream out){
		//1. extract all the Iterator ref var in all stmts.
		List<String> classStrs = LoopUtils.getAppIPSClass();
		
		Map<Value, List<Stmt>> var2StmtsMap = MultiMethodUtils.getVarNStmts(body, classStrs);
		
		
//		out.println("ipsInstVar = " + ipsInstVar);
//		out.println("ipStreamStmts= " + ipStreamStmts);
		List<Map<Value, List<String>>> funcsinAllPathsOfallVars = new ArrayList<Map<Value, List<String>>>();
		for(LoopPath path1 : paths){
			Map<Value, List<String>> funcMap = getAllInputStreamFuncs(path1, body, classStrs, out);
			funcsinAllPathsOfallVars.add(funcMap);
		}
		out.println("funcsinAllPathsOfallVars = " + funcsinAllPathsOfallVars);
		
		List<Map<Value, Boolean>> funcsinAllCondsOfallVars = new ArrayList<Map<Value, Boolean>>();
		for(LoopPath path1 : paths){
			Map<Value, Boolean> funcMap = checkHasIPSFunc(body, path1, classStrs, out);
			funcsinAllCondsOfallVars.add(funcMap);
		}
		out.println("funcsinAllCondsOfallVars = " + funcsinAllCondsOfallVars);
		
		
		Iterator<Entry<Value, List<Stmt>>> var2StmtsIt = var2StmtsMap.entrySet().iterator();
		Entry<Value, List<Stmt>> var2StmtsEntry = null;
		while(var2StmtsIt.hasNext()){
			var2StmtsEntry = var2StmtsIt.next();
			Value ipStreamVar = var2StmtsEntry.getKey();
			boolean readInCond = false;
			for(Map<Value, Boolean> funcMap : funcsinAllCondsOfallVars){
				if(funcMap.containsKey(ipStreamVar) && funcMap.get(ipStreamVar) == true){
					readInCond = true;
					break;
				}
			}
			out.println("readInCond = " + readInCond);
			if(readInCond){
				List<List<String>> funcsinAllPaths = new ArrayList<List<String>>();
				for(Map<Value, List<String>> funcMap : funcsinAllPathsOfallVars){
					if(funcMap.containsKey(ipStreamVar)){
						funcsinAllPaths.add(funcMap.get(ipStreamVar));
					}
				}
				out.println("funcsinAllPaths = " + funcsinAllPaths);
				if(notContainOtherIPSfuncs(funcsinAllPaths, out) == true)
					return true;
			}
		}

		return false;
	}
	

	
	/*
	 * check the upperbound is unchanged in the loop paths
	 * */
	private boolean isUnchanged(Value var, List<LoopPath> paths, PrintStream out){
		for(LoopPath path : paths){
			List<Stmt> pathStmts = path.getpathStmt();
			int varAssignedNum = 0;
			for(Stmt stmt: pathStmts){
				if(!(stmt instanceof JGotoStmt)){
					//out.println(stmt.toString());
					List<ValueBox> defs = stmt.getDefBoxes();
					for(ValueBox def : defs){
						if(def.getValue().equals(var)){
							varAssignedNum++;
						}
					}
				}
			}
			if(varAssignedNum > 2) //loop header and loop tail
				return false;
		}
		return true;
	}


	/* check whether the it contains other InputStream functions.
	 * Currently, the only functions that potentially make the stride/loop counter move backwards is 
	 * mark and reset pair.
	 * If it only contains mark, it doesn't matter.
	 */
	private boolean notContainOtherIPSfuncs(List<List<String>> newFuncLists, PrintStream out) {
		if(newFuncLists == null || (newFuncLists != null && newFuncLists.size() == 0))
			return false;
		for(List<String> funcs : newFuncLists){
			for(String funcName : funcs){
				if(funcName.equals("reset") || funcName.equals("unread")){
					return false;
				}
			}
		}
		return true;
	}



	//get the map of InputStream instance and List<InputStream functions in the loop path>.
	private Map<Value, List<String>> getAllInputStreamFuncs(LoopPath path1, 
			Body body, List<String> classStrs, PrintStream out) {
		List<Stmt> pathStmts = path1.getpathStmt();
		
		Map<Value, List<String>> varFuncMap = new HashMap<Value, List<String>>();
		
		Map<Value, List<Stmt>> var2StmtsMap = MultiMethodUtils.getVarNStmts(body, pathStmts, classStrs);
		
		Iterator<Entry<Value, List<Stmt>>> var2StmtsIt = var2StmtsMap.entrySet().iterator();
		Entry<Value, List<Stmt>> var2StmtsEntry = null;
		while(var2StmtsIt.hasNext()){
			var2StmtsEntry = var2StmtsIt.next();
			Value var = var2StmtsEntry.getKey();
			for(Stmt stmt : var2StmtsEntry.getValue()){
				InvokeExpr expression = stmt.getInvokeExpr();
				String funcName = expression.getMethod().getName();
				if(varFuncMap.containsKey(var)){
					List<String> funcs = varFuncMap.get(var);
					funcs.add(funcName);
					varFuncMap.put(var, funcs);
				} else {
					List<String> funcs = new ArrayList<String>();
					funcs.add(funcName);
					varFuncMap.put(var, funcs);
				}
			}
		}
		return varFuncMap;
	}
	
	
	//check whether the InputStream instance invokes the read()!= -1 or >= 0 or > 0, etc. in the exit condition.
	private Map<Value, Boolean> checkHasIPSFunc(Body body, LoopPath path1, List<String> classStrs, PrintStream out) {
		List<Stmt> pathStmts = path1.getpathStmt();
		List<Condition> pathConds = new ArrayList<Condition>();
		pathConds = ExtraCondition.extractEqualConditions(path1, out);
		//Map<Value, List<String>> varFuncMap = new HashMap<Value, List<String>>();
		Map<Value, Boolean> varHasIPSfunMap = new HashMap<Value, Boolean>();
		
		Map<Value, List<Stmt>> var2StmtsMap = MultiMethodUtils.getVarNStmts(body, pathStmts, classStrs);
		
		boolean candirectlyReturn = false;
		Set<Value> refVars = new HashSet<Value>();
		if(pathConds != null && pathConds.size() > 0){
			for(Condition cond : pathConds){
				Value var1 = cond.cond.getOp1();
				String symbol = cond.cond.getSymbol().trim();
				Value var2 = cond.cond.getOp2();
				out.println(var1 + " " + symbol + " " + var2);
				if(symbol.equals("!=") && (var2.toString().equals("-1") || var2.toString().equals("-1L"))
						|| symbol.equals(">") && (var2.toString().equals("-1") || var2.toString().equals("-1L"))
						|| symbol.equals(">=") && (var2.toString().equals("0") || var2.toString().equals("0L"))){
					refVars.add(var1);
				} else if(symbol.equals(">") && (var2.toString().equals("0") || var2.toString().equals("0L"))){
					//this means the infinite loop requires inputstream.read()>0 always true
					// which is impossible, even in cases like read(byte[]) with unknown array size.
					refVars.add(var1);
					candirectlyReturn=true;
				}
			}
		}
		out.println("refVars = " + refVars);
		
		for(Value refVar : refVars){
			if(var2StmtsMap.containsKey(refVar)){
				for(Stmt stmt : var2StmtsMap.get(refVar)){
					Value insVar = refVar;
					InvokeExpr expression = stmt.getInvokeExpr();
					String funcName = expression.getMethod().getName();
					int argCount = expression.getArgCount();
					out.println("argCount = " + argCount);
					if(funcName.equals("read")){
						if(candirectlyReturn){
							varHasIPSfunMap.put(insVar, true);
							out.println("matching read(...)>0");
							break;
						}
						if(argCount == 0){//InputStream.read()
							varHasIPSfunMap.put(insVar, true);
							out.println("matching read()");
							break;
						} else if(argCount == 1){ //InputStream.read(byte[])
							Value firstArg = expression.getArg(0);
							boolean foundread = false;
							for(Stmt stmt2 : MultiMethodUtils.getMethodAllStmts(body)){//only need to check the current method stmts, dont have to check the invoked method stmts
								if(stmt2 instanceof JAssignStmt){
									JAssignStmt jstmt = (JAssignStmt) stmt2;
									if(jstmt.leftBox.getValue().equals(firstArg)){
										for(ValueBox vb : jstmt.getUseBoxes()){
											Value use = vb.getValue();
											if(use instanceof IntConstant){
												int sizeInt = ((IntConstant) use).value;
												if(sizeInt != 0){//array[size], size!=0
													varHasIPSfunMap.put(insVar, true);
													foundread = true;
													break;
												}
											} else {//the 3rd arg can be determined in the path condition
												if(pathConds != null && pathConds.size() > 0){
													for(Condition cond : pathConds){
														Value var1 = cond.cond.getOp1();
														String symbol = cond.cond.getSymbol().trim();
														Value var2 = cond.cond.getOp2();
														if(var1.equals(use) && var2 instanceof IntConstant){
															int thirdIntBound = ((IntConstant) var2).value;
															if(thirdIntBound == 0 && symbol.equals(">")
																	|| thirdIntBound > 0 && (symbol.equals(">") || symbol.equals(">="))){
																foundread = true;
																break;
															}
														}
													}
												}
											}
										}
									}
								}
								if(foundread) break;
							}
							if(foundread) {
								varHasIPSfunMap.put(insVar, true);
								out.println("matching read(byte[])");
								break;
							}
						} else if(argCount == 3){//InputStream.read(byte[] b, int offset, int len)
							Value thirdArg = expression.getArgs().get(2);
							out.println("thirdArg = " + thirdArg.toString());
							if(thirdArg instanceof IntConstant){
								int thirdInt = ((IntConstant) thirdArg).value;
								if(thirdInt != 0){//len != 0
									varHasIPSfunMap.put(insVar, true);
									out.println("matching read(byte[],int,int)");
									break;
								}
							} else {//the 3rd arg can be determined in the path condition
								boolean foundread = false;
								//1. check whether thirdArg itself is in the condition
								if(pathConds != null && pathConds.size() > 0){
									for(Condition cond : pathConds){
										out.println(cond.cond);
										Value var1 = cond.cond.getOp1();
										String symbol = cond.cond.getSymbol().trim();
										Value var2 = cond.cond.getOp2();
										if(var1.equals(thirdArg) && var2 instanceof IntConstant){
											int thirdIntBound = ((IntConstant) var2).value;
											if(thirdIntBound == 0 && symbol.equals(">")
													|| thirdIntBound > 0 && (symbol.equals(">")||symbol.equals(">="))){
												foundread = true;
												break;
											}
										}
									}
								}
								if(foundread) {
									varHasIPSfunMap.put(insVar, true);
									out.println("matching read(byte[],int,int)");
									break;
								}
								//2. or thirdArg is an arithmetic expression
								//   check whether the elements in the expression are in the condition
								for(Stmt stmt2 : pathStmts){
									if(stmt2 instanceof JAssignStmt){
										JAssignStmt Jstmt = (JAssignStmt) stmt2;
										if(thirdArg.equals(Jstmt.leftBox.getValue())){
											for(Iterator<ValueBox> boxes = Jstmt.getUseBoxes().iterator(); boxes.hasNext();){
												ValueBox box = (ValueBox)boxes.next();
												Value value = box.getValue();
												if(value instanceof AddExpr){ //we suppose in read(?,?,a+b), a+b > 0
													out.println("matching read(byte[],int,a+b)");
													foundread = true;
													break;
												} else if(value instanceof SubExpr){
													SubExpr se = (SubExpr) value;
													Value lo = se.getOp1();
													Value ro = se.getOp2();
													for(Condition cond : pathConds){
														//out.println(cond.cond);
														Value var1 = cond.cond.getOp1();
														String symbol = cond.cond.getSymbol().trim();
														Value var2 = cond.cond.getOp2();
														if(var1.equals(lo) && var2.equals(ro) && symbol.equals(">")
																|| var1.equals(ro) && var2.equals(lo) && symbol.equals("<")){
															out.println("matching read(byte[],int,a-b) & a-b>0");
															foundread = true;
															break;
														}
													}
												}
											}
										}
									}
								}
								if(foundread) {
									varHasIPSfunMap.put(insVar, true);
									out.println("matching read(byte[],int,int)");
									break;
								}
							}
						}
					}
				}
			}
		}
		
		return varHasIPSfunMap;
	}

}
