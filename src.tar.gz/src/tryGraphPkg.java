import java.util.ArrayList;
import java.util.List;

import soot.jimple.Stmt;
import soot.tagkit.IntegerConstantValueTag;
import datastruct.tree.TreeNode;
import graph.ControlFlowGraph;
import graph.ICFGStructure;
import graph.JimpleModelAnalysis;
import graph.VFClass;
import graph.VFEdge;
import graph.VFMethod;
import graph.VFMethodEdge;
import graph.VFNode;


public class tryGraphPkg {
	public static void main(String[] args){
		
		//String[] sootString = new String[] { "-cp", classpath, 
		//		"-exclude", "javax", "-allow-phantom-refs", "-no-bodies-for-excluded", 
		//		"-process-dir", location, "-src-prec", "only-class", "-w", "-output-format", "J", "-keep-line-number", 
		//		"-output-dir", folder.getLocation().toOSString()/* , "tag.ln","on" */ };
		ICFGStructure icfg = new ICFGStructure();
		JimpleModelAnalysis analysis = new JimpleModelAnalysis();
		analysis.setSootString(args);
		List<VFClass> jimpleClasses = new ArrayList<>();
		try {
			analysis.createICFG(icfg, jimpleClasses);
			System.out.println("jimpleClasses.size = " + jimpleClasses.size());
			/*for(VFClass jimpleClass : jimpleClasses){
				System.out.println("jimpleMethodes.size = " + jimpleClass.getMethods().size());
				for(VFMethod vmethod : jimpleClass.getMethods()){
					ControlFlowGraph cfg = vmethod.getControlFlowGraph();
					List<VFNode> vnodes = cfg.listNodes;
					List<VFEdge> edges = cfg.listEdges;
					System.out.println(vmethod.getSootMethod().getSignature() + "==============================");
					for(VFNode vnode : vnodes){
						System.out.println("node = " + vnode.getVFUnit().getFullyQualifiedName());
					}
					for(VFEdge edge : edges){
						System.out.println("edge = " 
								+ edge.getSource().getVFUnit().getFullyQualifiedName() 
								+ " -> "
								+ edge.getDestination().getVFUnit().getFullyQualifiedName());
					}
					//VFNode firstnode = vnodes.get(0);
					//printTreeH(firstnode, "", false, edges);
				}
			}*/
			System.out.println("icfg.listMethods.size = " + icfg.listMethods.size());
			System.out.println("icfg.listEdges.size = " + icfg.listEdges.size());
			//for(VFMethod vmethod : icfg.listMethods){
			//	System.out.println(vmethod.getSootMethod().getSignature());
			//}
			for(VFMethodEdge edge : icfg.listEdges){
				System.out.println("edge = "
						+ edge.getSourceMethod().getSootMethod().getSignature()
						+ " -> "
						+ edge.getDestMethod().getSootMethod().getSignature());
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
    private static void printTreeH(VFNode node, String prefix, boolean isTail, List<VFEdge> edges) {
    	String name = node.getVFUnit().getFullyQualifiedName();
        System.out.println(prefix + (isTail ? "└── " : "├── ") + name);
        List<VFNode> children = getSuccessors(node,edges);
        
        for (int i = 0; i < children.size() - 1; i++) {
        	printTreeH(children.get(i), prefix + (isTail ? "    " : "│   "), false, edges);
        }
        if (children.size() > 0) {
        	printTreeH(children.get(children.size() - 1), prefix + (isTail ?"    " : "│   "), true, edges);
        }
    }
    
    private static List<VFNode> getSuccessors(VFNode vnode, List<VFEdge> edges){
    	List<VFNode> successors = new ArrayList<VFNode>();
    	for(VFEdge vedge : edges){
    		if(vedge.getSource().equals(vnode)){
    			successors.add(vnode);
    		}
    	}
    	return successors;
    }
}
