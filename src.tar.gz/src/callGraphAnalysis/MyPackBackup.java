package callGraphAnalysis;
import java.util.Iterator;
import java.util.Map;

import soot.PackManager;
import soot.Scene;
import soot.SceneTransformer;
import soot.SootMethod;
import soot.Transform;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Edge;


public class MyPackBackup { 
	public static void main(String[] args) { 
		
		  PackManager.v().getPack("wjtp").add(new Transform("wjtp.myTransform", new SceneTransformer() { 
		        protected void internalTransform(String phaseName, Map options) { 
		          System.out.println("--- start"); 
		          CallGraph cg = Scene.v().getCallGraph(); 
		          SootMethod entryPoint = Scene.v().getEntryPoints().get(0); // main by default 
		          Iterator<Edge> it = cg.edgesOutOf(entryPoint); 
		          while(it.hasNext()) { 
		            Edge e = it.next(); 
		            System.out.println("edge out of main: "+ e.getTgt()); 
		          } 
		          System.out.println("--- end"); 
		        } 
		      })); 
		  soot.Main.main(args); 
	} 
} 
