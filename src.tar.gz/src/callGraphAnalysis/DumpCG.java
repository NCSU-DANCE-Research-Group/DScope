package callGraphAnalysis;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import soot.PackManager;
import soot.Scene;
import soot.SceneTransformer;
import soot.SootMethod;
import soot.Transform;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Edge;


public class DumpCG {

    public static void main(String[] args) {

        PackManager.v().getPack("wjtp").add(new Transform("wjtp.my", new SceneTransformer() {

            @Override
            protected void internalTransform(String phaseName, Map<String, String> options) {
                CallGraph callGraph = Scene.v().getCallGraph();
                List<SootMethod> methods = Scene.v().getEntryPoints();
                for(SootMethod m : methods){
                	//SootMethod m = Scene.v().getMethod("<snippet.Snippet: void arrayListTest()>");
                	Iterator<Edge> edgesOutOf = callGraph.edgesOutOf(m);
                	while(edgesOutOf.hasNext()) {
                    	System.out.println(edgesOutOf.next());
                	}
                }
            }
        }));

        soot.Main.main(args);
    }

}
