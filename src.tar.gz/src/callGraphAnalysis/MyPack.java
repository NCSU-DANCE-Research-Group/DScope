package callGraphAnalysis;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import soot.Body;
import soot.PackManager;
import soot.Scene;
import soot.SceneTransformer;
import soot.SootClass;
import soot.SootMethod;
import soot.Transform;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Edge;
import soot.options.Options;
import soot.util.Chain;


public class MyPack { 
	public static void main(final String[] args) {
		/*String printSt = "";
		for(String arg : args){
			printSt += arg + " ";
		}
		System.out.println(printSt);*/
		
		PackManager.v().getPack("wjtp").add(new Transform("wjtp.myTransform", new SceneTransformer() {
			protected void internalTransform(String phaseName, Map options) {
				  
		          CallGraph cg = Scene.v().getCallGraph();
		          List<SootMethod> methods = Scene.v().getEntryPoints();
		          cg.sourceMethods();
		          for(SootMethod entryPoint : methods){
		        	  //System.out.println("--- start"); 
		        	  Iterator<Edge> itIn = cg.edgesInto(entryPoint);
			          while(itIn.hasNext()) { 
			            Edge e = itIn.next(); 
			            System.out.println( e.getSrc() + " => " + e.getTgt());
			          }
			          Iterator<Edge> itOut = cg.edgesOutOf(entryPoint);
			          while(itOut.hasNext()) { 
			            Edge e = itOut.next(); 
			            System.out.println(e.getSrc() + " => " + e.getTgt());
			          }
			          //System.out.println("--- end");  
		          }
		          
				//Options.v().parse(args);
				//String forceMainClass = args[args.length-1];
				//System.out.println(forceMainClass);
				//SootClass c = Scene.v().forceResolve(forceMainClass, SootClass.BODIES);
		        //c.setApplicationClass();
		        //Scene.v().setMainClass(c);
		        //Scene.v().loadNecessaryClasses();
		        //SootMethod method1 = c.getMethodByName("main");
		        //List entryPoints = new ArrayList();
		        //entryPoints.add(method1);
		        //Scene.v().setEntryPoints(entryPoints);
		        //CallGraph cg = Scene.v().getCallGraph();
		        //List<SootMethod> methods = Scene.v().getEntryPoints();
		        //for(SootMethod entryPoint : methods){
				//	System.out.println("--- start"); 
				//	Iterator<Edge> it = cg.edgesOutOf(entryPoint); 
				//	while(it.hasNext()) { 
				//		Edge e = it.next(); 
				//		System.out.println("edge out of " + entryPoint.getName() + ": " + e.getTgt()); 
				//	} 
				//	System.out.println("--- end"); 
		        //}
		        //PackManager.v().runPacks();
		        
		        //SootMethod m = c.getMethods().get(0); 
				//String allClassesStr = "";
				//Chain<SootClass> classes = Scene.v().getClasses();
				//Iterator<SootClass> classIt = classes.iterator();
				//while(classIt.hasNext()){
				//	SootClass sootClass = classIt.next();
				//	allClassesStr += sootClass.getName() + " ";
				//}
				//System.out.println(allClassesStr);
				
				//CallGraph cg = Scene.v().getCallGraph();
				/*List<SootMethod> methods = Scene.v().getEntryPoints();
				String allMethods = "";
				for(SootMethod method : methods){
					if(!method.isJavaLibraryMethod()){
						allMethods += method.getDeclaringClass().getName() + "." + method.getName() + " ";
					}
				}
				System.out.print(allMethods);
				*/
				
				/*for(SootMethod entryPoint : methods){
					System.out.println("--- start"); 
					Iterator<Edge> it = cg.edgesOutOf(entryPoint); 
					while(it.hasNext()) { 
						Edge e = it.next(); 
						System.out.println("edge out of " + entryPoint.getName() + ": " + e.getTgt()); 
					} 
					System.out.println("--- end"); 
				}*/
				  
				/*SootMethod entryPoint = methods.get(0); // main by default 
				Iterator<Edge> it = cg.edgesOutOf(entryPoint); 
				while(it.hasNext()) { 
					Edge e = it.next(); 
					System.out.println("edge out of main: "+ e.getTgt()); 
				} 
				System.out.println("--- end"); */
			} 
		}));
		soot.Main.main(args); 
	} 
} 
