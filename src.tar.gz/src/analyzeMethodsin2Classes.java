
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import soot.Body;
import soot.MethodOrMethodContext;
import soot.PackManager;
import soot.Scene;
import soot.SceneTransformer;
import soot.SootClass;
import soot.SootMethod;
import soot.Transform;
import soot.Type;
import soot.Unit;
import soot.UnitBox;
import soot.Value;
import soot.ValueBox;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.InvokeExpr;
import soot.jimple.Stmt;
import soot.jimple.internal.JAssignStmt;
import soot.jimple.internal.JIdentityStmt;
import soot.jimple.internal.JInvokeStmt;
import soot.jimple.spark.SparkTransformer;
import soot.jimple.toolkits.callgraph.CHATransformer;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.ContextSensitiveCallGraph;
import soot.jimple.toolkits.callgraph.ContextSensitiveEdge;
import soot.jimple.toolkits.callgraph.Edge;
import soot.jimple.toolkits.callgraph.ReachableMethods;
import soot.jimple.toolkits.callgraph.Sources;
import soot.jimple.toolkits.callgraph.Targets;
import soot.jimple.toolkits.callgraph.ObjSensContextManager;
import soot.options.Options;
import soot.util.Chain;
import soot.util.queue.QueueReader;
import utilities.MethodUtils;
import utilities.MultiMethodUtils;


public class analyzeMethodsin2Classes { 
	public static void main(final String[] args) {
		
		PackManager.v().getPack("wjtp").add(new Transform("wjtp.myTransform", new SceneTransformer() {
			protected void internalTransform(String phaseName, Map options) {
				  CHATransformer.v().transform(); //cha
				  //setSparkAnalysis();               //spark
				  //setSparkAnalysisPTA(); //it can cause "OutOfMemoryError: GC overhead limit exceeded"
				  Scene.v().loadNecessaryClasses();
				  //Scene.v().setEntryPoints(getAllMethods(args));
				  
//		          CallGraph cg = Scene.v().getCallGraph();
//		          ContextSensitiveCallGraph cscg = Scene.v().getContextSensitiveCallGraph();
		          
		          String klassName = args[args.length-1];
		          String tobeMergedMethod = MultiMethodUtils.tobeMergedMethod;
		          List<Stmt> methodStmts = new ArrayList<Stmt>(); 
		          List<SootMethod> methods = getAllMethods(klassName);
		          System.out.println("class 1: " + klassName);
		          for(SootMethod method : methods){
		        	  System.out.println("method = " + method);
		        	  for(SootMethod method2 : methods){
		        		  if(!method2.equals(method)){
		        			  System.out.println("method: " + method + "========== method2: " + method2);
//		        			  methodStmts = MultiMethodUtils.mergeMethodStmts(method.getActiveBody(), method2.getActiveBody());
//		        			  for(Stmt stmt : methodStmts){
//		        				  System.out.println(stmt.toString());
//			        		  }
		        			  Map<Value, Value> equalVals = MultiMethodUtils.findEqualVars(method.getActiveBody(), method2.getActiveBody());
		        			  if(equalVals != null){
		        				  System.out.println(equalVals);
		        			  }
		        		  }
		        	  }
//		        	  Set<Value> bodyVars = MultiMethodUtils.getAllVarFromBody(method.getActiveBody());
//		        	  for(Value var : bodyVars){
//		        		  System.out.println("var = " + var);
//		        	  }
//		        	  System.out.println("method: " + method);
		        	  //if(method.equals(tobeMergedMethod)){
//		        		  methodStmts = MultiMethodUtils.getMethodAllStmts(method.getActiveBody());
//		        		  for(Stmt stmt : methodStmts){
////		        			  if(stmt instanceof JIdentityStmt && stmt.toString().contains("@this:")){
////		        				  System.out.println(stmt.toString()+"==============containing field ref");
////		        			  } else if(stmt instanceof JIdentityStmt && stmt.toString().contains("@parameter")){
////		        				  System.out.println(stmt.toString()+"==============containing parameter");
////		        			  } else
//		        				  System.out.println(stmt.toString());
//		        		  }
		        	  //}
		          }
		          
		          String klassName2 = args[args.length-2];
		          String mergingMethod = MultiMethodUtils.mergingMethod;
		          List<Stmt> methodStmts2 = new ArrayList<Stmt>(); 
		          List<SootMethod> methods2 = getAllMethods(klassName);
		          System.out.println("class 2: " + klassName2);
		          for(SootMethod method : methods2){
		        	  System.out.println("method: " + method);
		        	  if(method.equals(mergingMethod)){
		        		  methodStmts2 = MultiMethodUtils.getMethodAllStmts(method.getActiveBody());
		        	  }
		          }    
			} 
		}));
		soot.Main.main(args); 			
	} 
	
	public static String getMethodFullName(SootMethod method){
		String classname = method.getDeclaringClass().getName();
		// use signature instead to avoid same-name functions
		String methodname = method.getSubSignature(); 
		return classname + ":" + methodname;
	}
	
    public static String getPrex(String[] args) {
    	String klassName = args[args.length-1];
    	String[] splitK = klassName.split(".");
    	String prefix = "";
    	prefix = splitK[0] + "." + splitK[1] + "." + splitK[2]; //hard-coded, only choose the first 3 substring
        return prefix;
    }
    
    public static List<SootMethod> getAllMethods(String klassName) {
        ArrayList<SootMethod> entrypoints = new ArrayList<SootMethod>();
        //for (String klassName : allClasses) {
            // klassName such as org.abc.MyClass
            Scene.v().forceResolve(klassName, SootClass.SIGNATURES);
            //Scene.v().forceResolve(klassName, SootClass.HIERARCHY);
            //Scene.v().forceResolve(klassName, SootClass.BODIES | SootClass.HIERARCHY | SootClass.SIGNATURES);
            SootClass klass = Scene.v().getSootClass(klassName);
            // adding all non-abstract method as entrypoint
            for (SootMethod m : klass.getMethods()) {
              if (!m.isAbstract()) {
                entrypoints.add(m);
              }
            }
        return entrypoints;
    }
    
    private static void setSparkAnalysis() {
        HashMap<String,String> opt = new HashMap<String,String>();
        opt.put("enabled","true");
        opt.put("verbose","false");
        opt.put("vta","true");
        opt.put("on-fly-cg","true");
        opt.put("set-impl","double");
        opt.put("double-set-old","hybrid");
        opt.put("propagator", "iter");
        opt.put("double-set-new","hybrid");

        SparkTransformer.v().transform("",opt);
    }

    /*causing overhead*/
    public static void setSparkAnalysisPTA() {
    	HashMap<String,String> opt = new HashMap<String,String>();
    	opt.put("geom-pta","true");
    	opt.put("geom-encoding", "geom");
    	opt.put("geom-worklist", "PQ");
    	opt.put("geom-eval", "0");
    	opt.put("geom-trans", "false");
    	opt.put("geom-frac-base", "40");
    	opt.put("geom-blocking", "true");
    	opt.put("geom-runs", "1");
    	opt.put("enabled","true");
    	opt.put("verbose","false");
    	opt.put("ignore-types","true");
    	opt.put("force-gc","false");
    	opt.put("pre-jimplify","false");
    	opt.put("vta","false");
    	opt.put("rta","false");
    	opt.put("field-based","false");
    	opt.put("types-for-sites","false");
    	opt.put("merge-stringbuffer","false");
    	opt.put("string-constants","true");
    	opt.put("simulate-natives","true");
    	opt.put("simple-edges-bidirectional","false");
    	opt.put("on-fly-cg","true");
    	opt.put("simplify-offline","false");
    	opt.put("simplify-sccs","false");
    	opt.put("ignore-types-for-sccs","false");
    	opt.put("propagator","worklist");
    	opt.put("set-impl","double");
    	opt.put("double-set-old","hybrid");
    	opt.put("double-set-new","hybrid");
    	opt.put("dump-html","false");
    	opt.put("dump-pag","false");
    	opt.put("dump-solution","false");
    	opt.put("topo-sort","false");
    	opt.put("dump-types","true");
    	opt.put("class-method-var","true");
    	opt.put("dump-answer","false");
    	opt.put("add-tags","false");
    	opt.put("set-mass","false");
    	SparkTransformer.v().transform("",opt);
    }
} 
