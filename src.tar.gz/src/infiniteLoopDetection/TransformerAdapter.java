package infiniteLoopDetection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import soot.Body;
import soot.BodyTransformer;
import soot.Scene;
import soot.SceneTransformer;
import soot.SootClass;
import soot.SootMethod;
import soot.Value;
import soot.jimple.JimpleBody;
import soot.jimple.Stmt;
import soot.jimple.toolkits.callgraph.CHATransformer;
import utilities.MultiMethodUtils;

public class TransformerAdapter extends SceneTransformer {
    /** Construct a new transformer
     */
	
//    private BodyTransformer _transformer;
    private List<String> classNames = new ArrayList<String>();
    private List<Body> class2Bodies = new ArrayList<Body>();
//    public TransformerAdapter(BodyTransformer transformer) {
//        _transformer = transformer;
//    }
    
    public void setClassNames(List<String> classNames){
    	for(String className : classNames){
    		this.classNames.add(className);
    	}
    }
    
    public List<Body> getClass2Bodies(){
    	return class2Bodies;
    }
    
	protected void internalTransform(String phaseName, Map options) {
		CHATransformer.v().transform(); //cha
		//setSparkAnalysis();            //spark
		//setSparkAnalysisPTA();         //it can cause "OutOfMemoryError: GC overhead limit exceeded"
		Scene.v().loadNecessaryClasses();
        
        String klassName = classNames.get(0);
        String tobeMergedMethod = MultiMethodUtils.tobeMergedMethod;
        List<Stmt> methodStmts = new ArrayList<Stmt>(); 
        List<SootMethod> methods = getAllMethods(klassName);
        System.out.println("class 1: " + klassName);
//        for(SootMethod method : methods){
//      	  System.out.println("method = " + method);
//      	  for(SootMethod method2 : methods){
//      		  if(!method2.equals(method)){
//      			  System.out.println("method: " + method + "========== method2: " + method2);
//      			  Map<Value, Value> equalVals = MultiMethodUtils.findEqualVars(method.getActiveBody(), method2.getActiveBody());
//      			  if(equalVals != null){
//      				  System.out.println(equalVals);
//      			  }
//      		  }
//      	  }
//        }
        
        String klassName2 = classNames.get(1);
        String mergingMethod = MultiMethodUtils.mergingMethod;
        List<Stmt> methodStmts2 = new ArrayList<Stmt>(); 
        List<SootMethod> methods2 = getAllMethods(klassName);
        System.out.println("class 2: " + klassName2);
        for(SootMethod method : methods2){
        	class2Bodies.add(method.getActiveBody());
//      	  System.out.println("method: " + method);
//      	  if(method.equals(mergingMethod)){
//      		  methodStmts2 = MultiMethodUtils.getMethodAllStmts(method.getActiveBody());
//      	  }
        }
        MultiMethodUtils.setBodies(class2Bodies);
	} 


    
    public List<SootMethod> getAllMethods(String klassName) {
        ArrayList<SootMethod> entrypoints = new ArrayList<SootMethod>();
        //for (String klassName : allClasses) {
            // klassName such as org.abc.MyClass
            Scene.v().forceResolve(klassName, SootClass.SIGNATURES);
            //Scene.v().forceResolve(klassName, SootClass.HIERARCHY);
            //Scene.v().forceResolve(klassName, SootClass.BODIES | SootClass.HIERARCHY | SootClass.SIGNATURES);
            SootClass klass = Scene.v().getSootClass(klassName);
            // adding all non-abstract method as entrypoint
            for (SootMethod m : klass.getMethods()) {
              if (!m.isAbstract()) {
                entrypoints.add(m);
              }
            }
        return entrypoints;
    }

}
