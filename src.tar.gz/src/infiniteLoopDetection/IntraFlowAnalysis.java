package infiniteLoopDetection;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

import soot.Body;
import soot.BodyTransformer;
import soot.G;
import soot.Unit;
import soot.Value;
import soot.jimple.Constant;
import soot.jimple.ParameterRef;
import soot.jimple.Stmt;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.scalar.FlowSet;
import utilities.MethodUtils;
import utilities.PathExit;
import utilities.useCoffiUtils;

public class IntraFlowAnalysis extends BodyTransformer {

	IntraFlowAnalysis(){
		exitVariables = null;
	}
	
	IntraFlowAnalysis(Set<PathExit> set, PrintStream out){
		exitVariables = new HashSet<String>();
		if(!set.isEmpty()){
			Iterator<PathExit> it=set.iterator();
			while(it.hasNext()){
				PathExit pe = it.next();
				Set<Value> vars=pe.getVariables();		
				for(Value v:vars){
					if(v instanceof Constant){
						continue;
					}
					exitVariables.add(v.toString());
				}
			}
		}
		this.out = out;
	}
	
	@Override
	protected void internalTransform(Body body, String phaseName, Map<String, String> options) {
		// TODO Auto-generated method stub
		String classname = body.getMethod().getDeclaringClass().getName();
		// use signature instead to avoid same-name functions
		String methodname = body.getMethod().getSubSignature();
		G.v().out.println("IntraFlowAnalysis: " + classname + ": " + methodname);
		
		UnitGraph graph = new ExceptionalUnitGraph(body);
		
		
		
		if(exitVariables != null){ //this is for print loop exit variable related statements
			G.v().out.println("Analyze statements exit variables depend on ");
			LoopScopeVariableAnalysis lsv = new LoopScopeVariableAnalysis(graph, exitVariables);
			G.v().out.println("After Analyze statements exit variables depend on ");
		}
		//this.out.println("==methodname = " + methodname);
		String classFilePath = MethodUtils.getBytePath();
		useCoffiUtils coffUtil = new useCoffiUtils(classname, classFilePath, methodname, out);
		Map<String, String> localVarTypeTable = coffUtil.getLocalVariableTypeTable();
		
		List<Stmt> allMethodStmts = MethodUtils.getMethodAllStmts(body);
		//this.out.println("==localvartypetable = " + localVarTypeTable);
		
		LoopVariableAnalysis lv = new LoopVariableAnalysis(graph, out, localVarTypeTable, allMethodStmts, classname);		
		
		List<Unit> tails = graph.getTails();
		for (Unit t : tails) {
			FlowSet outSet = (FlowSet) lv.getFlowAfter(t);
			for (Object obj : outSet) {
				Pair<Value> p = (Pair) obj;
				if (!map.containsKey(p.impacted)) {
					map.put(p.impacted, new HashSet<Value>());
					//map.get(p.impacted).add(p.impacted); //add itself
				}
				map.get(p.impacted).add(p.impacting);

				if (!reverse_map.containsKey(p.impacting)) {
					reverse_map.put(p.impacting, new HashSet<Value>());
					//reverse_map.get(p.impacting).add(p.impacting); //add itself
				}
				reverse_map.get(p.impacting).add(p.impacted);
			}
		}

		data_related = lv.getDataRelatedValues();
		
		out.println("getDataRelatedOriginalValues:----" + data_related.toString());
		out.println("data_related_org = " + data_related);
		
		final_values = this.merge2();

//		G.v().out.println("IntraFlowAnalysis:------End " + classname + ": "
//				+ methodname);
		// G.v().out.println("-----------Variables impacting Set-----------");
		// for(Map.Entry<Value, Set<Value>> entry:map.entrySet()){
		// G.v().out.println(entry.getKey()+" "+entry.getValue().toString());
		// }
		
		//constructor of File as external data related
		//java.io.DataInput as external data related
	}
	
	
	
	
	void dataRelatedCal(){
		
	}

	public Map<Value, Set<Value>> map = new HashMap<Value, Set<Value>>();
	public Map<Value, Set<Value>> reverse_map = new HashMap<Value, Set<Value>>();
	public Map<Value, Set<Value>> map_merged = new HashMap<Value, Set<Value>>();
	public Set<Value> data_related;
	public Set<Value> loop_counters;
	public Set<Value> final_values;
	
	public Set<String> exitVariables;
	
	public PrintStream out;

	public Set<String> getExitVariables(){
		return exitVariables;
	}
	
	public Map<Value, Set<Value>> getResults() {
		return map;
	}
	
	public Map<Value, Set<Value>> getReverseResults() {
		return reverse_map;
	}

	public Map<Value, Set<Value>> getMergedResults() {
		return map_merged;
	}

	public Set<Value> getLoopCounter(){
		return loop_counters;
	}
	
	public Set<Value> getFinalValues(){
		return final_values;
	}
	
	public Set<Value> getDataRelatedVariables(){
		loop_counters = new HashSet<Value>();
		out.println("data_related = " + data_related);
		
		for (Map.Entry<Value, Set<Value>> entry : map_merged.entrySet()) {
			Value impacted = entry.getKey();
			if(data_related.contains(impacted)){
				continue;
			}
			boolean is_data_related = false;
			boolean is_others = false;
			for (Value impacting : map_merged.get(impacted)) {
				if(impacting instanceof Constant || impacting.equals(impacted)){
					continue;
				}else if(data_related.contains(impacting)){
					is_data_related = true;
				}else{
					is_others = true;
				}
			}
			if(is_data_related){
				data_related.add(impacted);
			}else if(!is_others){
				loop_counters.add(impacted); //only contain constant and itself
			}
		}
		return data_related;
	}
	
	public Set<Value> merge2() {
		Set<Value> final_value = new HashSet<Value>();
		for (Map.Entry<Value, Set<Value>> entry : reverse_map.entrySet()) {
			if (!map.containsKey(entry.getKey())) { //not impacted
				final_value.add(entry.getKey());
			}
		}
//		if (final_value.size() > 0) {
//			G.v().out.println("final values: " + final_value.toString());
//		}
//		G.v().out.println("After final values----");
		for (Value impacting_final : final_value) {
			/**
			if(impacting_final instanceof ParameterRef && impacting_final.getType().toString().equals("java.io.DataInput")){
				data_related.add(impacting_final);
				G.v().out.println("Data related Parameter-----"+impacting_final.toString());
			}
			*/
			Stack<Value> s = new Stack<Value>(); // one DFS for each impactiing_final
			Map<Value,Boolean> visited = new HashMap<Value,Boolean>();
			s.push(impacting_final);
		//	G.v().out.println("push stack----"+impacting_final.toString());
			while (!s.isEmpty()) {
				Value impacting = s.pop();
				if(visited.containsKey(impacting)){
					continue;
				}
				visited.put(impacting, true);				
				if (!map_merged.containsKey(impacting)) {
					map_merged.put(impacting, new HashSet<Value>());
				}
				map_merged.get(impacting).add(impacting_final);
				//G.v().out.println("merge value----"+impacting.toString()+": "+impacting_final.toString());
				if (reverse_map.containsKey(impacting)) {
					Set<Value> impacted_set = reverse_map.get(impacting);
					if(data_related.contains(impacting)){
						data_related.addAll(impacted_set);
					}
					for (Value impacted :impacted_set ) {
						if(impacted.equals(impacting)){
							map_merged.get(impacting).add(impacted);
						}else{
							s.push(impacted);
						}
					}
				}
			}
			map_merged.remove(impacting_final);
		}
//		G.v().out
//				.println("-----------Variables merged impacting Set-----------");
//		for (Map.Entry<Value, Set<Value>> entry : map_merged.entrySet()) {
//			G.v().out.println(entry.getKey() + " "
//					+ entry.getValue().toString());
//		}
		// return map_merged;
		return final_value;
	}

	public Map<Value, Set<Value>> merge() {
		Map<Value, Set<Value>> map_merged = new HashMap<Value, Set<Value>>();
		for (Map.Entry<Value, Set<Value>> entry : map.entrySet()) {
			Set<Value> impactings = entry.getValue();
			//Set<Value> final_value = new HashSet<Value>();

			boolean changed = true;
			for (Value v : impactings) {
				if (!map.containsKey(v) || v.equals(entry.getKey())) {
					continue;
				}
				changed = true;
			}
			// if(final_value.size()>0){
			// map_merged.put(entry.getKey(), final_value);
			// map.get(entry.getKey()).removeAll(final_value);
			// }
			if (!changed) {
				map_merged.put(entry.getKey(), impactings);
			}
		}
		// do{
		for (Map.Entry<Value, Set<Value>> entry : map.entrySet()) {
			// Set<Value> impactings=entry.getValue();
			//
			// boolean e_change=false;
			// for(Value v:impactings){
			// if(!map_merged.containsKey(v)){
			// visitValue(v);
			// }
			// }
			//
			// if(!e_change){
			//
			// }
			visitValue(entry.getKey(), map, map_merged);
		}
		// }while(true);
		return map_merged;
	}

	private void visitValue(Value v, Map<Value, Set<Value>> map,
			Map<Value, Set<Value>> map_merged) {
		if (map_merged.containsKey(v)) {
			return;
		}
		// !map_merged.containsKey(v)
		Set<Value> impactings_new = new HashSet<Value>();
		for (Value value : map.get(v)) {
			visitValue(v, map, map_merged);
			impactings_new.addAll(map_merged.get(v));
		}
		if (!map_merged.containsKey(v)) {
			map_merged.put(v, impactings_new);
		}
		// return impactings_new;
	}
}