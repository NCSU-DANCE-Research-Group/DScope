package infiniteLoopDetection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import soot.Body;
import soot.BodyTransformer;
import soot.G;
import soot.Local;
import soot.Unit;
import soot.Value;
import soot.ValueBox;
import soot.tagkit.LoopInvariantTag;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.UnitGraph;
import soot.util.Chain;

public class LoopInvariantTransformer extends BodyTransformer {

	@Override
	protected void internalTransform(Body body, String phaseName, Map options) {
		// TODO Auto-generated method stub
		String classname = body.getMethod().getDeclaringClass().getName();
		// use signature instead to avoid same-name functions
		String methodname = body.getMethod().getSubSignature();
		G.v().out.println("LoopInvariantTransformer: " + classname + ": "
				+ methodname);

		// if(!LoopUtils.isPrint(classname)){ //if it is not the targeted
		// function, then do nothing
		// return;
		// }

		// List<Local> plocals=body.getParameterLocals();
		Chain<Local> locals = body.getLocals();
		List<ValueBox> defs = body.getDefBoxes();
		List<ValueBox> uses = body.getUseBoxes();

//		G.v().out.println("Locals");
//		for (Local l : locals) {
//			G.v().out.println(l.toString());
//			G.v().out.println("local type: "+l.getType().toString());
//			G.v().out.println("local class: "+l.getClass().toString());
//		}
//
//		G.v().out.println("Definitions");
//		for (ValueBox v : defs) {
////			Value v=vb.getValue();
//			G.v().out.println(v.toString());
//			G.v().out.println("def valuebox value: "+v.getValue().toString());
//			G.v().out.println("def valuebox value type: "+v.getValue().getType().toString());
//			G.v().out.println("def valuebox class: "+v.getClass().toString());
//		}
//
//		G.v().out.println("Use");
//		for (ValueBox v : uses) {
//			G.v().out.println(v.toString());
//			G.v().out.println("use valuebox value: "+v.getValue().toString());
//			G.v().out.println("use valuebox value type: "+v.getValue().getType().toString());
//			G.v().out.println("use valuebox class: "+v.getClass().toString());
//		}

		
		/**
		 * A loop invariant is a condition that is necessarily true immediately before 
		 * and immediately after each iteration of a loop. (Note that this says nothing about 
		 * its truth or falsity part way through an iteration.)
		 *
		 */
		UnitGraph g = new ExceptionalUnitGraph(body);
		Iterator<Unit> it = g.iterator();
		int i = 0;
		while (it.hasNext()) {
			Unit u = it.next();
			if (u.hasTag("LoopInvariantTag")) {
				G.v().out.println(u.toString());
				LoopInvariantTag t = (LoopInvariantTag) u
						.getTag("LoopInvariantTag");
				

				G.v().out.println("analysis type: " + t.getAnalysisType());
				G.v().out.println("info: " + t.getInfo());
//				G.v().out.println("String: "+t.toString());
				// G.v().out.println("value:"+t.getValue()); //StringTag do not
				// use getValue
			}
		}
	}
}