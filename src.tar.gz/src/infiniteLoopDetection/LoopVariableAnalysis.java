package infiniteLoopDetection;
import heros.fieldsens.AccessPath;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import soot.G;
import soot.Local;
import soot.PrimType;
import soot.RefType;
import soot.SootClass;
import soot.SootField;
import soot.SootMethod;
import soot.Type;
import soot.Unit;
import soot.UnitBox;
import soot.Value;
import soot.ValueBox;
import soot.jimple.Constant;
import soot.jimple.DefinitionStmt;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.InvokeExpr;
import soot.jimple.Ref;
import soot.jimple.Stmt;
import soot.jimple.internal.AbstractDefinitionStmt;
import soot.jimple.internal.JArrayRef;
import soot.jimple.internal.JAssignStmt;
import soot.jimple.internal.JInvokeStmt;
import soot.jimple.internal.JNewExpr;
import soot.jimple.internal.JSpecialInvokeExpr;
import soot.tagkit.LineNumberTag;
import soot.tagkit.SignatureTag;
import soot.tagkit.Tag;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.scalar.ArraySparseSet;
import soot.toolkits.scalar.FlowSet;
import soot.toolkits.scalar.ForwardFlowAnalysis;
import utilities.IOMethod;
import utilities.LoopUtils;
import utilities.MethodUtils;
import utilities.SetCheckMethod;
import utilities.SetMethod;

public class LoopVariableAnalysis extends ForwardFlowAnalysis {

//	public LoopVariableAnalysis(UnitGraph graph) {
//		super(graph);
//		// TODO Auto-generated constructor stub
//		throw new RuntimeException("Don't use this Constructor!");
//		// doAnalysis();
//	}

//	public LoopVariableAnalysis(UnitGraph graph, Set<Unit> exits) {
//		super(graph);
//		doAnalysis();
//	}
	
	Set<Value> data_related;
	PrintStream out;
	Map<String, String> localVarTypeTable;
	List<Stmt> allStmts;
	String classname;
	
	@SuppressWarnings("unchecked")
	public LoopVariableAnalysis(UnitGraph graph, PrintStream out, Map<String, String> localVarTypeTable, List<Stmt> allStmts, String classname) {
		super(graph);
		data_related = new HashSet<Value>();
		this.out = out;
		this.localVarTypeTable = localVarTypeTable;
		this.allStmts = allStmts;
		this.classname = classname;
		doAnalysis();
	}

	@Override
	protected void flowThrough(Object in, Object d, Object out) {
		copy(in, out);
//		kill(in, d, out);
//		gen(out, d);
//		G.v().out.println(d.toString() + " // " + d.toString());
		// handle new stmt
//		Unit node=(Unit)d;
//		if(node instanceof JAssignStmt){
//			Value rop=((JAssignStmt) node).getRightOp();
//			if(rop instanceof JNewExpr){
//				G.v().out.println(d.toString());
//				G.v().out.println("right operation of assign: "+rop.getClass().toString()+" type: "+rop.getType().toString());
//			}
//			
//		}
		addPair(in, d, out);
		//addPairNew(in, d, out); //---------This is the new function, but it seems like the results are not correct. Need debugging?
	//	G.v().out.println(d.toString() + " // " + out.toString());
		//printPairs(out);
	}
	
	public static void printPairs(Object dest){
		FlowSet destSet = (FlowSet) dest;
		for(Object obj: destSet){
			Pair p = (Pair)obj;
			G.v().out.println("pair-----" + p.toString());
		}
	}
	
	public Set<Value> getDataRelatedValues(){
		return data_related;
	}
	
	protected void addPair(Object src, Object n, Object dest) {
		Unit node = (Unit) n;
		//out.println("print unit n =" + n.toString());
		FlowSet srcSet = (FlowSet) src;
		FlowSet destSet = (FlowSet) dest;		
		Set<Value> defs = new HashSet<Value>();
		Set<Value> uses = new HashSet<Value>();
		
		//out.println("LocalVariableTable = " + this.localVarTypeTable);
		for(ValueBox vb : node.getUseAndDefBoxes()){
			Value val = vb.getValue();
			if(val instanceof Local){ //for those (temporary) local variable
				//check this local variable is date related or not
				//out.println("val = " + val + " is Local.");
//				if(localVarTypeTable ==  null || localVarTypeTable.size() == 0){
//					this.out.println("localVarTable is empty");
//				}
				if(localVarTypeTable != null && localVarTypeTable.size() > 0 && isIOLocalVar(val)){
					data_related.add(val);
				}
			}
		}
		
		for (ValueBox box : node.getDefBoxes()) {
			Value value = box.getValue();
			if (value instanceof Local || value instanceof Ref || value instanceof Constant){
				defs.add(value);
			}
			//else{
			//	G.v().out.println("Def: not local, ref, constant-----"+value.toString());
			//}
		}
		for (ValueBox box : node.getUseBoxes()) {
			Value value = box.getValue();
			if ( value instanceof Local 
					|| (value instanceof Ref && !(value instanceof JArrayRef)) 
					|| value instanceof Constant 
					|| value instanceof JNewExpr ){ //JNewExpr for new object					
				uses.add(value);
				//out.println("Use: local, ref, constant--"+value.toString()+"----type-"+value.getType().toString()+" class:--"+value.getClass().toString());	
			} else if(value instanceof JSpecialInvokeExpr){
				JSpecialInvokeExpr spExpr = (JSpecialInvokeExpr) value;
				//G.v().out.println("Use: not local, ref, constant--"+value.toString()+"----type-"+value.getType().toString()+" class:--"+value.getClass().toString());	
				Set<Value> args = new HashSet<Value>();
				for(Value arg : spExpr.getArgs()){
					//G.v().out.println("Arg: --"+arg.toString());
					uses.add(arg);
					args.add(arg);
				}
				for(ValueBox vb : spExpr.getUseBoxes()){
					Value val = vb.getValue();
					if(!args.contains(val)){
						defs.add(val);
					}
					//G.v().out.println("Use: --"+val.toString());	
				}
			}
			/* add parameters send to new File() as data related
			 if( value instanceof JSpecialInvokeExpr){ //constructor
				Value base=((JSpecialInvokeExpr)value).getBase();
				List<Value> args=((JSpecialInvokeExpr)value).getArgs();
				SootMethod method=((JSpecialInvokeExpr)value).getMethod();			
//				G.v().out.println("new constructor method name: "+method.getName());
				if(method.getName().equals("<init>")){  //make sure it is constructor
					defs.add(base);
					uses.addAll(args);					
					//mark arguments of new File(args) as data related
					if(base.getType().toString().equals("java.io.File")){
						data_related.addAll(args);
						G.v().out.println("Data related Args-----"+args.toString());
					}
				}			
//				G.v().out.println("new constructor base: "+base.toString()+" class: "+base.getClass().toString()+" type: "+base.getType().toString());
//				G.v().out.println("new constructor method: "+method.toString()+" class: "+method.getClass().toString());
//				G.v().out.println("new constructor args: "+args.toString()); 				
			}*/
//			else{
//				G.v().out.println("Use: not local, ref, constant-----"+value.toString());
//			}
//			if(value instanceof JNewExpr){
//				JNewExpr expr = (JNewExpr)value;
//				Type t = value.getType();
//				
//				if(t instanceof PrimType){
//					out.println("value = " + value + ", type = " + t + ", is primtype");
//				}
//				if(t instanceof RefType){
//					out.println("value = " + value + ", type = " + t + ", is reftype");
//					//String name = ((RefType) t).getClassName();
//					//out.println("type classname = " + name);
//					//out.println(((RefType) t).getSootClass());
//					out.println("------print all tags--------");
//					SootClass cl = ((RefType) t).getSootClass();
//					out.println(cl.getName() + "," + cl.toString());
//					Iterator<Tag> cTagIterator = cl.getTags().iterator();
//		            while (cTagIterator.hasNext()) {
//		                Tag t2 = cTagIterator.next();
//		                out.print("/*");
//		                out.print(t2.toString());
//		                out.println("*/");
//		            }
//					out.println("--------print all tags----------");
//					
//					
//					for (Tag tag : ((RefType) t).getSootClass().getTags()) {
//						if (tag instanceof SignatureTag) {
//							SignatureTag stag = (SignatureTag) tag;
//							//String foundSig = signature2classname(((SignatureTag) tag).getSignature());
//							String foundSig = ((SignatureTag) tag).getSignature();
//							out.println("tag signature = " + foundSig); //
//							//String tagname = ((SignatureTag) tag).getName();
//							//out.println("tag name = " + tagname);
//							//byte[] tagValue = ((SignatureTag) tag).getValue();
//							//out.println("tagValue = " + tagValue.toString());
//						}
//					}
//				}
////				out.println("getUseBoxes:::"+expr.toString());
////				for(ValueBox vb : expr.getUseBoxes()){
////					Value val = vb.getValue();
////					out.println("getUseBoxes::::"+val);
////				}
//			}
			

			if(value instanceof InstanceInvokeExpr){
				InstanceInvokeExpr expr = (InstanceInvokeExpr)value;
				Value base = expr.getBase();
				SootMethod method = expr.getMethod();
//				List<Value> args = expr.getArgs();
				
				String base_class = base.getType().toString();	
				//out.println("method invoke method name:" + method.getName());
				String subSignature = method.getSubSignature();
				String declaring_class = method.getDeclaringClass().toString();
				//out.println("---base_class: " + base_class);
				//out.println("---declaring_class :" + declaring_class);
				//out.println("---method :" + subSignature);
				//Testing: we expand the granularity to classes not methods
				/*
				IOMethod m = LoopUtils.match(base_class,subSignature);
				if(m == null){
					m = LoopUtils.match(declaring_class,subSignature);
				}
				G.v().out.println("method invoke method base:" + base_class);
				G.v().out.println("method invoke method subsignature:" + subSignature);
				G.v().out.println("method invoke method declaring class:" + declaring_class);
				if(m != null){
					G.v().out.println("method invoke method found:" + method.getDeclaration());
					G.v().out.println("method invoke stmt:" + LoopUtils.stmt_toString(node));
					if(m.type.equals("get")){
						if(node instanceof JAssignStmt){
							data_related.add(((JAssignStmt)node).getLeftOp());
						}
					}else if(m.type.equals("set")){
						SetMethod setM=(SetMethod)m;
						String data=setM.data;
						int index=Integer.parseInt(data.substring(3));
						data_related.add(args.get(index));
						
					}else if(m.type.equals("check")){
						//G.v().out.println("method invoke stmt not data related");
						if(node instanceof JAssignStmt){
							data_related.add(((JAssignStmt)node).getLeftOp());
						}
					}else if(m.type.equals("get_check")){ //get_check
						if(node instanceof JAssignStmt){
							data_related.add(((JAssignStmt)node).getLeftOp());
						}
					}else{//set_check
						SetCheckMethod setCheckM=(SetCheckMethod)m;
						String data=setCheckM.data;
						int index=Integer.parseInt(data.substring(3));
						data_related.add(args.get(index));
					}
				}*/
				if(LoopUtils.match(base_class) || LoopUtils.match(declaring_class)){
					if(node instanceof JAssignStmt){
						//out.println("--def = " + ((JAssignStmt)node).getLeftOp() + ", base_class = " + base_class + ", declaring_class = " + declaring_class);
						data_related.add(((JAssignStmt)node).getLeftOp());
					}
					//if the method is io related method, the return value is io related, but the arg are not always io related
//					for(Value arg : args){ //need to check the type of the arguments, if the type are Integer, String... then we should at least filter those out
//						out.println("--arg = " + arg + ", base_class = " + base_class + ", declaring_class = " + declaring_class);
//						data_related.add(arg);
//					}
				}
//				G.v().out.println("method invoke method declaration:"+method.getDeclaration()); //public abstract boolean hasNext()
			} else if(value instanceof InvokeExpr){
				InvokeExpr expr = (InvokeExpr)value;
				String declaring_class = expr.getMethod().getDeclaringClass().toString();
//				List<Value> args = expr.getArgs();
				if(LoopUtils.match(declaring_class)){
					if(node instanceof JAssignStmt){
						data_related.add(((JAssignStmt)node).getLeftOp());
					}
					//if the method is io related method, the return value is io related, but the arg are not always io related
//					for(Value arg : args){ //need to check the type of the arguments, if the type are Integer, String... then we should at least filter those out
//						data_related.add(arg);
//					}
				}
			}
		}

		
//		if(node instanceof JAssignStmt){
//			Value rop=((JAssignStmt) node).getRightOp();
//			if(rop instanceof JNewExpr){				
//			//	uses.add(rop); //Def: not local, ref, constant-----new java.io.File				
//				G.v().out.println(node.toString());
//				G.v().out.println("right operation of assign: "+rop.getClass().toString()+" type: "+rop.getType().toString());
//				//print Defs
//				for(Value obj: defs){
//					G.v().out.println("Defs-----"+obj.toString());
//				}
//				//print Uses
//				for(Value obj: uses){
//					G.v().out.println("Uses-----"+obj.toString());
//				}
//			}
//			
//		}else if(node instanceof JInvokeStmt){
//			JInvokeStmt invoke_stmt=(JInvokeStmt)node;
//			InvokeExpr expr=invoke_stmt.getInvokeExpr();
//			if(expr instanceof JSpecialInvokeExpr){  //constructor
//				Value base=((JSpecialInvokeExpr)expr).getBase();
//				List<Value> args=((JSpecialInvokeExpr)expr).getArgs();
//				SootMethod method=((JSpecialInvokeExpr)expr).getMethod();
//				
//				G.v().out.println(node.toString());
//				G.v().out.println("new constructor base: "+base.toString()+" class: "+base.getClass().toString()+" type: "+base.getType().toString());
//				G.v().out.println("new constructor method: "+method.toString()+" class: "+method.getClass().toString());
//				G.v().out.println("new constructor args: "+args.toString()); 
//			}
//		}
		
		for(Value v_def : defs){
			for(Value v_use : uses){
				destSet.add(new Pair(v_def, v_use)); //defined value(v_def) is impacted by used value(v_use)
			}
		}
	}
	
	
	private boolean isIOLocalVar(Value var){
		String srcpath = MethodUtils.getSrcPath();
		if(srcpath == null){
			return false;
		}
		String srcname = "";
		for(Stmt stmt : this.allStmts){
        	int linenum = -1;
        	for(Tag tag : stmt.getTags()){
        		if(tag instanceof LineNumberTag){
        			linenum = ((LineNumberTag)tag).getLineNumber();
        		}
        	}
        	for( ValueBox vb : stmt.getDefBoxes()){
        		Value val = vb.getValue();
        		if(val instanceof Local && val.equals(var)){
        			srcname = MethodUtils.readJavaSrcFile(srcpath, this.classname, linenum);
        		}
        	}
        }
		this.out.println("srcname = " + srcname);
		if(srcname != "" && localVarTypeTable.containsKey(srcname)){
			String varType = localVarTypeTable.get(srcname);
			List<String> allTypes = signature2classnames(varType);
			for(String baseClass : allTypes){
				this.out.println("baseClass = " + baseClass);
				if(LoopUtils.match(baseClass)){
					return true;
				}
			}
		}
		return false;
	}
	
	
	
	
	private List<String> signature2classnames(String sig) {
		if (sig == null) return null;
		sig = sig.replace('/', '.');
		//sig = sig.replaceAll("\\WL", "");
		//sig = sig.replaceFirst(";", "");
		sig = sig.replaceAll(">;",">");
		sig = sig.replaceAll("Ljava","java");
		sig = sig.replaceAll("Lorg", "org");
		sig = sig.replaceAll("<", ";");
		sig = sig.replaceAll(">", ";");
		sig = sig.replaceAll("\\[",";");
		String[] splitStr = sig.split(";");
		List<String> allTypes = new ArrayList<String>();
		for(int i = 0; i < splitStr.length; i++){
			//System.out.println(splitStr[i]);
			if(!splitStr[i].matches("^\\s*$"))
				allTypes.add(splitStr[i]);
		}
		return allTypes;
	}
	
//	private String signature2classname(String sig) {
//		if (sig == null) return null;
//		sig = sig.replace('/', '.');
//		sig = sig.replaceAll("\\WL", "");
//		sig = sig.replaceFirst(";", "");
//		return sig;
//	}

	protected void addPairNew(Object src, Object n, Object dest) {
		Stmt stmt = (Stmt) n;
		if((stmt instanceof JAssignStmt && stmt.containsInvokeExpr()) 
				|| stmt instanceof JInvokeStmt ){
			InvokeExpr expression = stmt.getInvokeExpr();
			List<Value> args = expression.getArgs();
			IOMethod m = LoopUtils.match(expression.getMethod().getDeclaringClass().toString(), expression.getMethod().getName());
			if(m != null){
				if(m.type.equals("get") || m.type.equals("check") || m.type.equals("get_check")){
					if(stmt instanceof JAssignStmt){
						data_related.add(((JAssignStmt) stmt).getLeftOp());
					}
				}else if(m.type.equals("set")){
					SetMethod setM = (SetMethod)m;
					String data = setM.data;
					int index = Integer.parseInt(data.substring(3));
					data_related.add(args.get(index));
				}else if(m.type.equals("set_check")){
					SetCheckMethod setCheckM = (SetCheckMethod)m;
					String data = setCheckM.data;
					int index = Integer.parseInt(data.substring(3));
					data_related.add(args.get(index));
				}
			} else {
				//e.g., org.apache.cassandra.streaming.messages.StreamMessage deserialize(
          		//             java.nio.channels.ReadableByteChannel, 
          		//             int, 
          		//             org.apache.cassandra.streaming.StreamSession)
				if(stmt instanceof JAssignStmt){
					for(Value arg : args){
						out.println("arg.getType = " + arg.getType());
						if(LoopUtils.matchArg(arg.getType().toString())){
							data_related.add(((JAssignStmt) stmt).getLeftOp());
							break;
						}
					}
				}
			}
		}
	}
	
	@Override
	protected Object newInitialFlow() {
		// TODO Auto-generated method stub
		return new ArraySparseSet<Pair<Value>>();
	}

	@Override
	protected Object entryInitialFlow() {
		// TODO Auto-generated method stub
		return new ArraySparseSet<Pair<Value>>();
	}

	@Override
	protected void merge(Object in1, Object in2, Object out) {
		// TODO Auto-generated method stub
		FlowSet inSet1 = (FlowSet) in1;
		FlowSet inSet2 = (FlowSet) in2;
		FlowSet outSet = (FlowSet) out;
		inSet1.union(inSet2, outSet);
	}

	@Override
	protected void copy(Object source, Object dest) {
		FlowSet srcSet = (FlowSet) source;
		FlowSet destSet = (FlowSet) dest;
		srcSet.copy(destSet);
	}

	private void kill(Object src, Object n, Object dest) {
		Unit node=(Unit)n;
		FlowSet srcSet = (FlowSet)src;
		FlowSet destSet = (FlowSet) dest;
		
		for (ValueBox box : node.getDefBoxes()) {
			Value value = box.getValue();
			if (value instanceof Local)
				destSet.remove((Local) value);
		}
	}

	private void gen(Object dest, Object n) {
		Unit node=(Unit)n;
		FlowSet destSet = (FlowSet) dest;
		for (ValueBox box : node.getUseBoxes()) {
			Value value = box.getValue();
			if (value instanceof Local)
				destSet.add((Local) value);
		}
	}
}

class Pair<T> {
	T impacted;
	T impacting;

	Pair(T h1, T h2) {
		impacted = h1;
		impacting = h2;
	}
	
	public String toString(){
		return impacting + "->" + impacted;
	}
	
	public boolean equals(Object obj){
		Pair<T> p = (Pair<T>) obj;
		if(this.impacted.equals(p.impacted) && this.impacting.equals(p.impacting)){
			return true;
		}
		return false;
	}
	
	public int hashCode(){
		return toString().hashCode();
	}
}