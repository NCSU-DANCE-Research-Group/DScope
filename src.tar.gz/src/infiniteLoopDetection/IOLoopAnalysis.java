package infiniteLoopDetection;
import heros.fieldsens.AccessPath;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import soot.G;
import soot.Local;
import soot.PrimType;
import soot.RefType;
import soot.SootClass;
import soot.SootField;
import soot.SootMethod;
import soot.Type;
import soot.Unit;
import soot.UnitBox;
import soot.Value;
import soot.ValueBox;
import soot.jimple.Constant;
import soot.jimple.DefinitionStmt;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.InvokeExpr;
import soot.jimple.Ref;
import soot.jimple.Stmt;
import soot.jimple.internal.AbstractDefinitionStmt;
import soot.jimple.internal.JArrayRef;
import soot.jimple.internal.JAssignStmt;
import soot.jimple.internal.JIdentityStmt;
import soot.jimple.internal.JInvokeStmt;
import soot.jimple.internal.JNewExpr;
import soot.jimple.internal.JSpecialInvokeExpr;
import soot.tagkit.IntegerConstantValueTag;
import soot.tagkit.LineNumberTag;
import soot.tagkit.SignatureTag;
import soot.tagkit.Tag;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.scalar.ArraySparseSet;
import soot.toolkits.scalar.FlowSet;
import soot.toolkits.scalar.ForwardFlowAnalysis;
import utilities.IOMethod;
import utilities.LoopUtils;
import utilities.MethodUtils;
import utilities.SetCheckMethod;
import utilities.SetMethod;

public class IOLoopAnalysis{
	public List<Value> data_related = new ArrayList<Value>();
	PrintStream out;
	Map<String, String> localVarTypeTable;
	List<Stmt> allStmts;
	String classname;
	UnitGraph graph;
	List<Stmt> stmts;
	
	public IOLoopAnalysis(UnitGraph graph, PrintStream out, Map<String, String> localVarTypeTable, List<Stmt> allStmts, String classname) {
		this.graph = graph;
		this.out = out;
		this.localVarTypeTable = localVarTypeTable;
		this.allStmts = allStmts;
		this.classname = classname;
		this.stmts = allStmts; //this contains all the method stmts, 
		                       //it can be either of caller-callee relation or the multi-threading on the same variable.
		                       //the current granularity is in each class.
	}
	
	public void extractIOVariable(){
		if(localVarTypeTable == null || localVarTypeTable.size() == 0){
			return;
		}
		for (Unit stmt : stmts) {
			for(ValueBox vb : stmt.getUseAndDefBoxes()){
				Value val = vb.getValue();
				if(val instanceof Local){ //for those (temporary) local variable
					if(localVarTypeTable != null && localVarTypeTable.size() > 0){
						if(isIOLocalVar(val) && !data_related.contains(val))
							data_related.add(val);
					}
				}
			}
//			if(stmt instanceof JIdentityStmt){//for identityStmt, another I/O or non-I/O var is assigned to the current var.
//				JIdentityStmt idstmt = (JIdentityStmt) stmt;
//				for(ValueBox vb : idstmt.getUseBoxes()){
//					Value use = vb.getValue();
//					if(isIOLocalVar(use)){
//						data_related.add(idstmt.getLeftOp());
//						break;
//					}
//				}
//			} else if(stmt instanceof JAssignStmt){ //for assignStmt, check whether it is create a new instance
//				JAssignStmt agstmt = (JAssignStmt) stmt;
//				if(agstmt.containsInvokeExpr()){
//					InvokeExpr expr = agstmt.getInvokeExpr();
//					String declaring_class = expr.getMethod().getDeclaringClass().toString();
//					if(LoopUtils.match(declaring_class)){
//						data_related.add(agstmt.getLeftOp());
//					}
//					if(expr instanceof InstanceInvokeExpr){
//						InstanceInvokeExpr inexpr = (InstanceInvokeExpr)expr;
//						Value base = inexpr.getBase();
//						String base_class = base.getType().toString();	
//						if(LoopUtils.match(base_class)){
//							data_related.add(agstmt.getLeftOp());
//						}
//					}
//				}
//			} else if(stmt instanceof JInvokeStmt){
//				JInvokeStmt ivstmt = (JInvokeStmt) stmt;
//				if(ivstmt.containsInvokeExpr()){
//					InvokeExpr expr = ivstmt.getInvokeExpr();
//					if(expr instanceof JSpecialInvokeExpr){
//						JSpecialInvokeExpr ivexpr = (JSpecialInvokeExpr) expr;
//						Value base = ivexpr.getBase();
//						String base_class = base.getType().toString();	
//						if(LoopUtils.match(base_class)){
//							data_related.add(base); //for special invoke expr, it doesn't have leftop, it only contains base.method(arg,...)
//						}
//					}
//				}
//			}	
		}
	}
	
	public List<Value> getDataRelatedValues(){
		return data_related;
	}
	
	private boolean isIOLocalVar(Value var){
		String srcpath = MethodUtils.getSrcPath();
		if(srcpath == null){
			return false;
		}
		String srcname = "";
		for(Stmt stmt : this.allStmts){
        	int linenum = -1;
        	for(Tag tag : stmt.getTags()){
        		if(tag instanceof LineNumberTag){
        			linenum = ((LineNumberTag)tag).getLineNumber();
        		}
        	}
        	for( ValueBox vb : stmt.getDefBoxes()){
        		Value val = vb.getValue();
        		if(val instanceof Local && val.equals(var)){
        			srcname = MethodUtils.readJavaSrcFile(srcpath, this.classname, linenum);
        		}
        	}
        }
		this.out.println("srcname = " + srcname);
		if(srcname != "" && localVarTypeTable.containsKey(srcname)){
			String varType = localVarTypeTable.get(srcname);
			List<String> allTypes = signature2classnames(varType);
			for(String baseClass : allTypes){
				this.out.println("baseClass = " + baseClass);
				if(LoopUtils.match(baseClass)){
					return true;
				}
			}
		}
		return false;
	}
	
	
	
	
	private List<String> signature2classnames(String sig) {
		if (sig == null) return null;
		sig = sig.replace('/', '.');
		//sig = sig.replaceAll("\\WL", "");
		//sig = sig.replaceFirst(";", "");
		sig = sig.replaceAll(">;",">");
		sig = sig.replaceAll("Ljava","java");
		sig = sig.replaceAll("Lorg", "org");
		sig = sig.replaceAll("<", ";");
		sig = sig.replaceAll(">", ";");
		sig = sig.replaceAll("\\[",";");
		String[] splitStr = sig.split(";");
		List<String> allTypes = new ArrayList<String>();
		for(int i = 0; i < splitStr.length; i++){
			//System.out.println(splitStr[i]);
			if(!splitStr[i].matches("^\\s*$"))
				allTypes.add(splitStr[i]);
		}
		return allTypes;
	}
}