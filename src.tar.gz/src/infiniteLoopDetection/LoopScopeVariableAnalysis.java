package infiniteLoopDetection;
import java.util.Set;

import soot.G;
import soot.Unit;
import soot.Value;
import soot.ValueBox;
import soot.tagkit.IntegerConstantValueTag;
import soot.tagkit.Tag;
import soot.toolkits.graph.UnitGraph;
import soot.toolkits.scalar.ArraySparseSet;
import soot.toolkits.scalar.FlowSet;
import soot.toolkits.scalar.ForwardFlowAnalysis;


public class LoopScopeVariableAnalysis extends ForwardFlowAnalysis {


	public LoopScopeVariableAnalysis(UnitGraph graph) {
		super(graph);
		// TODO Auto-generated constructor stub
		doAnalysis();
	}
	

	public LoopScopeVariableAnalysis(UnitGraph graph, Set<String> exitVariables) {
		super(graph);
		this.exitVariables = exitVariables;
		
		G.v().out.println("Initalize LoopScopeVariableAnalysis");
		
		doAnalysis();
		// TODO Auto-generated constructor stub
	}
	
	
	protected void flowThrough(Object in, Object d, Object out) {
		copy(in, out);
		G.v().out.println("FlowThrough LoopScopeVariableAnalysis");
		//check if the statement that exit condition variables of these "for" loops do not depend on inside the loop
		Unit node=(Unit)d;
		markLoopVariableStmt(node);
		
	}
	
	protected void markLoopVariableStmt(Unit node){
		G.v().out.println("Check should have ExitVariableDependOnStmt or not");
		
		if(node.hasTag("LoopTag") && !node.hasTag("ExitVariableDependOnStmt")){ //is a loop statement and no dependon tag			
			int id=((IntegerConstantValueTag) (node.getTag("IntegerConstantValueTag"))).getIntValue();
			G.v().out.println("Should tag ExitVariableDependOnStmt: " + id);
			
			for (ValueBox box : node.getDefBoxes()) {
				Value value = box.getValue();
				if(exitVariables.contains(value.toString())){ //the stmt exit variables are defined/assigned
					//addDependableTag
					node.addTag(new ExitVariableDependOnStmt(id, value.toString(), value));
				}
			}
		}
	}
	
	Set<String> exitVariables;

	@Override
	protected void merge(Object in1, Object in2, Object out) {
		// TODO Auto-generated method stub
		FlowSet inSet1 = (FlowSet) in1;
		FlowSet inSet2 = (FlowSet) in2;
		FlowSet outSet = (FlowSet) out;
		inSet1.union(inSet2, outSet);
	}

	@Override
	protected void copy(Object source, Object dest) {
		FlowSet srcSet = (FlowSet) source;
		FlowSet destSet = (FlowSet) dest;
		srcSet.copy(destSet);
	}

	
	@Override
	protected Object newInitialFlow() {
		// TODO Auto-generated method stub
		return new ArraySparseSet<Pair<Value>>();
	}

	@Override
	protected Object entryInitialFlow() {
		// TODO Auto-generated method stub
		return new ArraySparseSet<Pair<Value>>();
	}
}

class ExitVariableDependOnStmt implements Tag {
	int id;
	String value;
	Value exitValue;

	ExitVariableDependOnStmt(int i, String evalue, Value exitV){
		id = i;
		value = evalue;
		exitValue = exitV;
	}

	public String getName() {
		return "ExitVariableDependOnStmt";
	}

	public String getInfo() {
		return value + " depend on stmt:" + id;
	}

	public String toString() {
		return value + " depend on stmt:" + id;
	}

	public int getId() {
		return id;
	}
	
	public Value getExitVariable(){
		return exitValue;
	}

	/** Returns the tag raw data. */
	public byte[] getValue() {
		throw new RuntimeException("ExitVariableDependOnStmt has no value for bytecode");
	}
}
