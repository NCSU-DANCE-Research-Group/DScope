package infiniteLoopDetection;
import java.util.ArrayList;
import java.util.List;

import soot.PackManager;
import soot.Scene;
import soot.SootClass;
import soot.SootMethod;
import soot.options.Options;
/**
 * Usually we recommend users to just call Soot’s very own main method after setting up the initial configuration. 
 * Note that in this particular case this is not recommended. 
 * The problem is that the above code is loading classes, which conflicts with the standard class-loading process that Soot’s main method implements. 
 * Instead above we call runPacks which will run all of Soot’s packs in the usual order. 
 * At the beginning of the above code, we call parse to parse the command-line arguments given to your driver class, forwarding those to Soot (as usual).
 *
 */
public class SetEntryPoints {
	public static void main(String[] args) {
		Options.v().parse(args);
		SootClass c = Scene.v().forceResolve("MyEntryPoint", SootClass.BODIES);
		c.setApplicationClass();
		Scene.v().loadNecessaryClasses();
		SootMethod method = c.getMethodByName("myMethod");
		List entryPoints = new ArrayList();
		entryPoints.add(method);
		Scene.v().setEntryPoints(entryPoints);
		PackManager.v().runPacks();
	}
}
