package infiniteLoopDetection;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import falsePositivePatterns.FPPattern1;
import falsePositivePatterns.FPPattern10;
import falsePositivePatterns.FPPattern11;
import falsePositivePatterns.FPPattern12;
import falsePositivePatterns.FPPattern12Extend;
import falsePositivePatterns.FPPattern13;
import falsePositivePatterns.FPPattern14;
import falsePositivePatterns.FPPattern2;
import falsePositivePatterns.FPPattern3;
import falsePositivePatterns.FPPattern3Extend;
import falsePositivePatterns.FPPattern4;
import falsePositivePatterns.FPPattern4Extend;
import falsePositivePatterns.FPPattern5;
import falsePositivePatterns.FPPattern6;
import falsePositivePatterns.FPPattern7;
import falsePositivePatterns.FPPattern8;
import falsePositivePatterns.FPPattern9;
import falsePositivePatterns.FPPatternNotConsiderInterProc;
import soot.Body;
import soot.BodyTransformer;
import soot.G;
import soot.Unit;
import soot.Value;
import soot.ValueBox;
import soot.jimple.Constant;
import soot.jimple.FieldRef;
import soot.jimple.JimpleBody;
import soot.jimple.Stmt;
import soot.jimple.toolkits.annotation.logic.Loop;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.LoopNestTree;
import soot.toolkits.graph.UnitGraph;
import soot.util.Chain;
import truePositivePatterns.TPPattern1;
import utilities.Condition;
import utilities.LoopGraph;
import utilities.LoopPath;
import utilities.LoopUtils;
import utilities.MethodUtils;
import utilities.MultiMethodUtils;
import utilities.PathExit;

public class LoopPathFinder extends BodyTransformer {
	
//	private List<Body> otherClassBodies = new ArrayList<Body>();
//	
//	public void setOtherBodies(List<Body> otherClassBodies){
//		for(Body otherBody : otherClassBodies){
//			this.otherClassBodies.add(otherBody);
//		}
//	}
	
	@Override
	protected void internalTransform(Body body, String phaseName, Map options) {
		// TODO Auto-generated method stub
		String classname = body.getMethod().getDeclaringClass().getName();
		// use signature instead to avoid same-name functions
		String methodname = body.getMethod().getSubSignature();
		
//		String method_declare=body.getMethod().getDeclaration();
//		String class_name=body.getMethod().getDeclaringClass().getType().toString();
		
		G.v().out.println("LoopPathFinder: "+classname + ": " + methodname);
//		G.v().out.println("LoopPathFinder: "+class_name + ": " + method_declare);

//		if(!LoopUtils.isPrint(body.getMethod().getName())){ //if it is not the targeted function, then do nothing
//			return;
//		}
		
		//System.out.println("otherClassBody's size = " + MultiMethodUtils.getBodies().size());
		
		if(!LoopUtils.isPrint(classname)||LoopUtils.isSkippedFunction(body.getMethod().getName())){ 
			//if it is not the targeted function, then do nothing
			return;
		}
		
		UnitGraph g = new ExceptionalUnitGraph(body);
		G.v().out.println("LoopPathFinder Size: " + g.size());

		LoopNestTree loopNestTree = new LoopNestTree(body);
		boolean isNested = loopNestTree.hasNestedLoops();
		Iterator<Loop> iterator = loopNestTree.iterator();
		//Map<Integer, List<Integer>> loopTopoMap = MethodUtils.getLoopTopology(body);
		Map<String, List<Stmt>> allClassStmts = MethodUtils.getClassAllStmts(body);
		
		int loop_id = 0;
		while (iterator.hasNext()) {
			Loop l = iterator.next();
			//comment the following if branch for testing
//			if (l.getLoopStatements().size() < 3) { // remove synchronized() or
//													// try-catch-finally-loop
//													// 3 is the value Peipei observed, might a hard-coded part need to be improved
//				continue;
//			}

			LoopGraph lg = new LoopGraph(classname, methodname, allClassStmts, l , g, loop_id++);
			
			PrintStream out = null;
//			PrintStream out=G.v().out;
			try{
				String fname = LoopUtils.getFileName(classname, methodname,"_Loop"+lg.loop_id+".txt");
				File f = new File(fname);
				if(f.exists() && !f.isDirectory()) { 
					return;
				}
				G.v().out.println(fname);
				out = new PrintStream(new FileOutputStream(fname));
			}catch(FileNotFoundException e){
				e.printStackTrace();
			}
			
			
			if(out != null){
				if(l.loopsForever()){
					out.println("This is an infinite loop.");
				}else{
					lg.setPrintStream(out);
					
//					if(!lg.IOLoopPreparation()){
//						continue;
//					}
					
					lg.printLoop(out);
				
					lg.pathSearch(out);
//					lg.buildDifferentPaths(out);
					
					lg.pathPrune(); // pruned the path that contains "a == b && a != b"
					
					int pathsize = lg.printPaths(out);
					//==ting: when the pathsize is too big, it will consume too many cpu to do the following analyze
					// we simply just drop this method.
//					if(pathsize > 100){
//						out.println("The loop size is too big, larger than 100.");
//						continue;
//					}
					///////////////////
					lg.printPathConditions_Exceptions(out); //for every path
					Set<PathExit> exits = lg.printLoopExitConditions_Exceptions(out); //for the whole loop
					
					//=======ting===========
					int loopID = lg.getLoopID();
					/*actually, we don't need to use the loopTopoMap,
					 * This is because we consider the topology of the nested loop when generate the Path.
					 * Check the LoopGraph.search4Path() and LoopGraph.generatePaths() functions*/
					//List<Integer> innerIDs = loopTopoMap.get(loopID);
					//out.println(loopTopoMap);
					
					List<LoopPath> nonExitPaths = lg.getCandidateNonExitLoops(out); // for non-exit paths
					List<Stmt> loopAllstmts = lg.getLoopStmt();
					
					List<LoopPath> allPaths = lg.getAllPaths(); //get all paths
					
					//out.println("------loop " + loopID + " has " + innerIDs.size() + " inner loops------");
					
					Map<LoopPath, Boolean> matchFPPatterns = new HashMap<LoopPath, Boolean>();
					if(loopAllstmts != null && loopAllstmts.size() > 0
							&& allPaths != null && allPaths.size() > 0
							&& nonExitPaths != null && nonExitPaths.size() > 0){
						
						out.println("consider all the inner loops:");
						FPPattern1 checkFPpattern1 = new FPPattern1();
						out.println("-------------Check mathing FP pattern1-----------------------");
						int pathId = 0;
						for(LoopPath nonExitPath1 : nonExitPaths){
							boolean matched = true;
							//for(int i = innerIDs.size(); i >= 0; i--){ //exclude the innerest loops in iterations
								//List<Integer> notbelongIDs = innerIDs.subList(i, innerIDs.size());
								//List<Stmt> statements = MethodUtils.getMethodStmts(body, loopID, notbelongIDs);
								List<Stmt> statements = MethodUtils.getMethodAllStmts(body);
								//out.println("not consider the inner loop " + notbelongIDs + ":");
								if(checkFPpattern1.compareConstantPattern(nonExitPath1, nonExitPaths, statements, out) == true){
									out.println("Path " + pathId + ": " + "Matching False Positive Pattern1.");
									matched = matched & true;
//									matchFPPatterns.put(nonExitPath1, true);
								} else {
									out.println("Path " + pathId + ": " + "Not Match False Positive Pattern1.");
//									matchFPPatterns.put(nonExitPath1, false);//Boolean default value is null, so need to put false in the map
									matched = false;
								}
								matchFPPatterns.put(nonExitPath1, matched);
							//}
							pathId++;
						}
						out.println("-------------End Checking mathing FP pattern1----------------");						
						FPPattern2 checkFPpattern2 = new FPPattern2();
						out.println("-------------Check mathing FP pattern2-----------------------");
						pathId = 0;
						for(LoopPath nonExitPath1 : nonExitPaths){
							boolean matched = true;
							//for(int i = innerIDs.size(); i >= 0; i--){ //exclude the innerest loops in iterations
								//List<Integer> notbelongIDs = innerIDs.subList(i, innerIDs.size());
								//List<Stmt> statements = MethodUtils.getMethodStmts(body, loopID, notbelongIDs);
								List<Stmt> statements = MethodUtils.getMethodAllStmts(body);
								//out.println("not consider the inner loop " + notbelongIDs + ":");
								if(checkFPpattern2.compareConstantPattern(body, nonExitPath1, nonExitPaths, statements, out) == true){
									out.println("Path " + pathId + ": " + "Matching False Positive Pattern2.");
									matched = matched & true;
								} else {
									out.println("Path " + pathId + ": " + "Not Match False Positive Pattern2.");
									matched = false;
								}
								matchFPPatterns.put(nonExitPath1, matched);
							//}
							pathId++;
						}
						out.println("-------------End Checking mathing FP pattern2----------------");
						FPPattern3 checkFPpattern3 = new FPPattern3();
						FPPattern3Extend checkFPpattern3Extend = new FPPattern3Extend();
						out.println("-------------Check mathing FP pattern3--ByteBuffer--IntBuffer------------");
						//for this pattern, currently, we analyze all paths, not each path.
						boolean matched = true;
						//for(int i = innerIDs.size(); i >= 0; i--){ //exclude the innerest loops in iterations
							//List<Integer> notbelongIDs = innerIDs.subList(i, innerIDs.size());
							//List<Stmt> statements = MethodUtils.getMethodStmts(body, loopID, notbelongIDs);
							//out.println("not consider the inner loop " + notbelongIDs + ":");
							List<Stmt> statements = MethodUtils.getMethodAllStmts(body);
							if(checkFPpattern3.checkByteBufferPattern(nonExitPaths, statements, out) == true
									|| checkFPpattern3Extend.checkByteBufferPattern(nonExitPaths, statements, out) == true){
								matched = true;
							} else {
								matched = false;
							}
						//}
						if(matched == true){ //if matched considering/non-considering inner loops, then the FP pattern match
							pathId = 0;
							for (Map.Entry<LoopPath, Boolean> entry : matchFPPatterns.entrySet()) {
								out.println("Path " + pathId + ": " + "Matching False Positive Pattern3.");
								matchFPPatterns.put(entry.getKey(), true);
								pathId++;
							}
						}
						out.println("-------------End Checking mathing FP pattern3----------------");
						FPPattern4 checkFPpattern4 = new FPPattern4();
						FPPattern4Extend checkFPpattern4Extend = new FPPattern4Extend();
						out.println("-------------Check mathing FP pattern4--Iterator--Enumeration-------------");
						//for this pattern, currently, we analyze all paths, not each path.						
						matched = true;
						//for(int i = innerIDs.size(); i >= 0; i--){ //exclude the innerest loops in iterations
							//List<Integer> notbelongIDs = innerIDs.subList(i, innerIDs.size());
							//List<Stmt> statements = MethodUtils.getMethodStmts(body, loopID, notbelongIDs);
							//out.println("not consider the inner loop " + notbelongIDs + ":");
							
							if(checkFPpattern4.checkIteratorPattern(nonExitPaths, statements, out) == true
									|| checkFPpattern4Extend.checkEnumerationPattern(nonExitPaths, statements, out) == true){
								matched = true;
							} else {
								matched = false;
							}
						//}

						if(matched == true){ //if matched considering/non-considering inner loops, then the FP pattern match
							pathId = 0;
							for (Map.Entry<LoopPath, Boolean> entry : matchFPPatterns.entrySet()) {
								out.println("Path " + pathId + ": " + "Matching False Positive Pattern4.");
								matchFPPatterns.put(entry.getKey(), true);
								pathId++;
							}
						}
						out.println("-------------End Checking mathing FP pattern4----------------");
//					}
//					if(loopAllstmts != null && loopAllstmts.size() > 0
//							&& allPaths != null && allPaths.size() > 0
//							&& nonExitPaths != null && nonExitPaths.size() > 0){
						FPPattern5 checkFPpattern5 = new FPPattern5();
						out.println("-------------Check mathing FP pattern5-----------------------");
						//for this pattern, currently, we analyze all paths, not each path.
						matched = true;
						//for(int i = innerIDs.size(); i >= 0; i--){ //exclude the innerest loops in iterations
							//List<Integer> notbelongIDs = innerIDs.subList(i, innerIDs.size());
							//List<Stmt> statements = MethodUtils.getMethodStmts(body, loopID, notbelongIDs);
							//out.println("not consider the inner loop " + notbelongIDs + ":");
							
							if(checkFPpattern5.checkBufferedReaderPattern(nonExitPaths, statements, out) == true){
								matched = true;
							} else {
								matched = false;
							}
						//}
						if(matched == true){ //if matched considering/non-considering inner loops, then the FP pattern match
							pathId = 0;
							for (Map.Entry<LoopPath, Boolean> entry : matchFPPatterns.entrySet()) {
								out.println("Path " + pathId + ": " + "Matching False Positive Pattern5.");
								matchFPPatterns.put(entry.getKey(), true);
								pathId++;
							}
						}
						out.println("-------------End Checking mathing FP pattern5----------------");
						FPPattern6 checkFPpattern6 = new FPPattern6();
						out.println("-------------Check mathing FP pattern6-----------------------");
						//for this pattern, currently, we analyze all paths, not each path.
						matched = true;
						//for(int i = innerIDs.size(); i >= 0; i--){ //exclude the innerest loops in iterations
							//List<Integer> notbelongIDs = innerIDs.subList(i, innerIDs.size());
							//List<Stmt> statements = MethodUtils.getMethodStmts(body, loopID, notbelongIDs);
							//out.println("not consider the inner loop " + notbelongIDs + ":");
							
							if(checkFPpattern6.checkInputStreamPattern(body, nonExitPaths, statements, out) == true){
								matched = true;
							} else {
								matched = false;
							}
						//}
						if(matched == true){ //if matched considering/non-considering inner loops, then the FP pattern match
							pathId = 0;
							for (Map.Entry<LoopPath, Boolean> entry : matchFPPatterns.entrySet()) {
								out.println("Path " + pathId + ": " + "Matching False Positive Pattern6.");
								matchFPPatterns.put(entry.getKey(), true);
								pathId++;
							}
						}
						out.println("-------------End Checking mathing FP pattern6----------------");
						FPPattern7 checkFPpattern7 = new FPPattern7();
						out.println("-------------Check mathing FP pattern7---List----------------");
						//for this pattern, currently, we analyze all paths, not each path.
						matched = true;
						//for(int i = innerIDs.size(); i >= 0; i--){ //exclude the innerest loops in iterations
							//List<Integer> notbelongIDs = innerIDs.subList(i, innerIDs.size());
							//List<Stmt> statements = MethodUtils.getMethodStmts(body, loopID, notbelongIDs);
							//out.println("not consider the inner loop " + notbelongIDs + ":");
							
							if(checkFPpattern7.checkListPattern(nonExitPaths, statements, out) == true){
								matched = true;
							} else {
								matched = false;
							}
						//}
						if(matched == true){ //if matched considering/non-considering inner loops, then the FP pattern match
							pathId = 0;
							for (Map.Entry<LoopPath, Boolean> entry : matchFPPatterns.entrySet()) {
								out.println("Path " + pathId + ": " + "Matching False Positive Pattern7.");
								matchFPPatterns.put(entry.getKey(), true);
								pathId++;
							}
						}
						out.println("-------------End Checking mathing FP pattern7----------------");
						FPPattern8 checkFPpattern8 = new FPPattern8();
						out.println("-------------Check mathing FP pattern8---StringTokenizer-----");
						//for this pattern, currently, we analyze all paths, not each path.
						matched = true;
						//for(int i = innerIDs.size(); i >= 0; i--){ //exclude the innerest loops in iterations
							//List<Integer> notbelongIDs = innerIDs.subList(i, innerIDs.size());
							//List<Stmt> statements = MethodUtils.getMethodStmts(body, loopID, notbelongIDs);
							//out.println("not consider the inner loop " + notbelongIDs + ":");
							
							if(checkFPpattern8.checkStringTokenizerPattern(nonExitPaths, statements, out) == true){
								matched = true;
							} else {
								matched = false;
							}
						//}
						if(matched == true){ //if matched considering/non-considering inner loops, then the FP pattern match
							pathId = 0;
							for (Map.Entry<LoopPath, Boolean> entry : matchFPPatterns.entrySet()) {
								out.println("Path " + pathId + ": " + "Matching False Positive Pattern8.");
								matchFPPatterns.put(entry.getKey(), true);
								pathId++;
							}
						}
						out.println("-------------End Checking mathing FP pattern8----------------");
						FPPattern9 checkFPpattern9 = new FPPattern9();
						out.println("-------------Check mathing FP pattern9---File----------------");
						//for this pattern, currently, we analyze all paths, not each path.
						matched = true;
						//for(int i = innerIDs.size(); i >= 0; i--){ //exclude the innerest loops in iterations
							//List<Integer> notbelongIDs = innerIDs.subList(i, innerIDs.size());
							//List<Stmt> statements = MethodUtils.getMethodStmts(body, loopID, notbelongIDs);
							//out.println("not consider the inner loop " + notbelongIDs + ":");
							
							if(checkFPpattern9.checkFilePattern(nonExitPaths, statements, out) == true){
								matched = true;
							} else {
								matched = false;
							}
						//}
						if(matched == true){ //if matched considering/non-considering inner loops, then the FP pattern match
							pathId = 0;
							for (Map.Entry<LoopPath, Boolean> entry : matchFPPatterns.entrySet()) {
								out.println("Path " + pathId + ": " + "Matching False Positive Pattern9.");
								matchFPPatterns.put(entry.getKey(), true);
								pathId++;
							}
						}
						out.println("-------------End Checking mathing FP pattern9----------------");
						FPPattern10 checkFPpattern10 = new FPPattern10();
						out.println("-------------Check mathing FP pattern10---FileChannel--------");
						//for this pattern, currently, we analyze all paths, not each path.
						matched = true;
						//for(int i = innerIDs.size(); i >= 0; i--){ //exclude the innerest loops in iterations
							//List<Integer> notbelongIDs = innerIDs.subList(i, innerIDs.size());
							//List<Stmt> statements = MethodUtils.getMethodStmts(body, loopID, notbelongIDs);
							//out.println("not consider the inner loop " + notbelongIDs + ":");
							
							if(checkFPpattern10.checkFileChannelPattern(nonExitPaths, statements, out) == true){
								matched = true;
							} else {
								matched = false;
							}
						//}
						if(matched == true){ //if matched considering/non-considering inner loops, then the FP pattern match
							pathId = 0;
							for (Map.Entry<LoopPath, Boolean> entry : matchFPPatterns.entrySet()) {
								out.println("Path " + pathId + ": " + "Matching False Positive Pattern10.");
								matchFPPatterns.put(entry.getKey(), true);
								pathId++;
							}
						}
						out.println("-------------End Checking mathing FP pattern10----------------");
						FPPattern11 checkFPpattern11 = new FPPattern11();
						out.println("-------------Check mathing FP pattern11---ServerSocketChannel-");
						//for this pattern, currently, we analyze all paths, not each path.
						matched = true;
						//for(int i = innerIDs.size(); i >= 0; i--){ //exclude the innerest loops in iterations
							//List<Integer> notbelongIDs = innerIDs.subList(i, innerIDs.size());
							//List<Stmt> statements = MethodUtils.getMethodStmts(body, loopID, notbelongIDs);
							//out.println("not consider the inner loop " + notbelongIDs + ":");
							if(checkFPpattern11.checkServerSocketChannelPattern(nonExitPaths, statements, out) == true){
								matched = true;
							} else {
								matched = false;
							}
						//}
						if(matched == true){ //if matched considering/non-considering inner loops, then the FP pattern match
							pathId = 0;
							for (Map.Entry<LoopPath, Boolean> entry : matchFPPatterns.entrySet()) {
								out.println("Path " + pathId + ": " + "Matching False Positive Pattern11.");
								matchFPPatterns.put(entry.getKey(), true);
								pathId++;
							}
						}
						out.println("-------------End Checking mathing FP pattern11----------------");
						FPPattern12 checkFPpattern12 = new FPPattern12();
						out.println("-------------Check mathing FP pattern12---Queue---------------");
						//for this pattern, currently, we analyze all paths, not each path.
						matched = true;
						//for(int i = innerIDs.size(); i >= 0; i--){ //exclude the innerest loops in iterations
							//List<Integer> notbelongIDs = innerIDs.subList(i, innerIDs.size());
							//List<Stmt> statements = MethodUtils.getMethodStmts(body, loopID, notbelongIDs);
							//out.println("not consider the inner loop " + notbelongIDs + ":");
							if(checkFPpattern12.checkQueuePattern(nonExitPaths, statements, out) == true){
								matched = true;
							} else {
								matched = false;
							}
						//}
						if(matched == true){ //if matched considering/non-considering inner loops, then the FP pattern match
							pathId = 0;
							for (Map.Entry<LoopPath, Boolean> entry : matchFPPatterns.entrySet()) {
								out.println("Path " + pathId + ": " + "Matching False Positive Pattern12.");
								matchFPPatterns.put(entry.getKey(), true);
								pathId++;
							}
						}
						out.println("-------------End Checking mathing FP pattern12----------------");
						FPPattern12Extend checkFPpattern12Ext = new FPPattern12Extend();
						out.println("-------------Check mathing FP pattern12---Stack---------------");
						//for this pattern, currently, we analyze all paths, not each path.
						matched = true;
						//for(int i = innerIDs.size(); i >= 0; i--){ //exclude the innerest loops in iterations
							//List<Integer> notbelongIDs = innerIDs.subList(i, innerIDs.size());
							//List<Stmt> statements = MethodUtils.getMethodStmts(body, loopID, notbelongIDs);
							//out.println("not consider the inner loop " + notbelongIDs + ":");
							if(checkFPpattern12Ext.checkQueuePattern(nonExitPaths, statements, out) == true){
								matched = true;
							} else {
								matched = false;
							}
						//}
						if(matched == true){ //if matched considering/non-considering inner loops, then the FP pattern match
							pathId = 0;
							for (Map.Entry<LoopPath, Boolean> entry : matchFPPatterns.entrySet()) {
								out.println("Path " + pathId + ": " + "Matching False Positive Pattern12Ext.");
								matchFPPatterns.put(entry.getKey(), true);
								pathId++;
							}
						}
						out.println("-------------End Checking mathing FP pattern12Ext-------------");
						FPPattern13 checkFPpattern13 = new FPPattern13();
						out.println("-------------Check mathing FP pattern13---Matcher-------------");
						//for this pattern, currently, we analyze all paths, not each path.
						matched = true;
						//for(int i = innerIDs.size(); i >= 0; i--){ //exclude the innerest loops in iterations
							//List<Integer> notbelongIDs = innerIDs.subList(i, innerIDs.size());
							//List<Stmt> statements = MethodUtils.getMethodStmts(body, loopID, notbelongIDs);
							//out.println("not consider the inner loop " + notbelongIDs + ":");
							if(checkFPpattern13.checkMatcherPattern(nonExitPaths, statements, out) == true){
								matched = true;
							} else {
								matched = false;
							}
						//}
						if(matched == true){ //if matched considering/non-considering inner loops, then the FP pattern match
							pathId = 0;
							for (Map.Entry<LoopPath, Boolean> entry : matchFPPatterns.entrySet()) {
								out.println("Path " + pathId + ": " + "Matching False Positive Pattern13.");
								matchFPPatterns.put(entry.getKey(), true);
								pathId++;
							}
						}
						out.println("-------------End Checking mathing FP pattern13----------------");
						FPPattern14 checkFPpattern14 = new FPPattern14();
						out.println("-------------Check mathing FP pattern14---DataInput------------");
						//for this pattern, currently, we analyze all paths, not each path.
						matched = true;
						//for(int i = innerIDs.size(); i >= 0; i--){ //exclude the innerest loops in iterations
							//List<Integer> notbelongIDs = innerIDs.subList(i, innerIDs.size());
							//List<Stmt> statements = MethodUtils.getMethodStmts(body, loopID, notbelongIDs);
							//out.println("not consider the inner loop " + notbelongIDs + ":");
							if(checkFPpattern14.checkDataInputPattern(nonExitPaths, statements, out) == true){
								matched = true;
							} else {
								matched = false;
							}
						//}
						if(matched == true){ //if matched considering/non-considering inner loops, then the FP pattern match
							pathId = 0;
							for (Map.Entry<LoopPath, Boolean> entry : matchFPPatterns.entrySet()) {
								out.println("Path " + pathId + ": " + "Matching False Positive Pattern14.");
								matchFPPatterns.put(entry.getKey(), true);
								pathId++;
							}
						}
						out.println("-------------End Checking mathing FP pattern14----------------");
						FPPatternNotConsiderInterProc checkFPpatternNotInterP = new FPPatternNotConsiderInterProc();
						out.println("-------------Check mathing FP pattern---not consider InterProcedure---");
						//for this pattern, currently, we analyze each path, not all paths.
						pathId = 0;
						for(LoopPath nonExitPath1 : nonExitPaths){
							if(checkFPpatternNotInterP.checkBoundStrideisInterProc(body, nonExitPath1, statements, out) == true){
								out.println("Path " + pathId + ": " + "Matching False Positive Pattern NoInterP.");
								matchFPPatterns.put(nonExitPath1, true);
							} else {
								out.println("Path " + pathId + ": " + "Not Match False Positive Pattern NoInterP.");
							}
							pathId++;
						}
						out.println("-------------End Checking mathing FP pattern---not consider InterProcedure---");
					}
					out.println("=========================================================================");
					int isAllMatchFPPattern = 0;
					Iterator<Entry<LoopPath, Boolean>> matchFPPatternsIt = matchFPPatterns.entrySet().iterator();
					while(matchFPPatternsIt.hasNext()){
						Entry<LoopPath, Boolean> matchFPPatternsEntry = matchFPPatternsIt.next();
						if(matchFPPatternsEntry.getValue() == true)
							isAllMatchFPPattern++;
					}
					boolean isFalsePositive = false;
					if(isAllMatchFPPattern == nonExitPaths.size()){
						isFalsePositive = true;
					}
					//add intra flow analysis
					//isFalsePositive = false; //turn the intra-flow on.
					
					/* **************************************************
					 * The following is to do the intraflow analysis
					 * **************************************************/
					//IntraFlowAnalysis intra=new IntraFlowAnalysis();
					if(isFalsePositive == false){ // Don't match the FP patterns
						//out.println("Getting into intraFlowAnalysis");
						IntraFlowAnalysis intra = new IntraFlowAnalysis(exits, out);
						intra.transform(body);
						
						lg.printLoopVariableScope(out, intra.getExitVariables());
						
						Map<Value,Set<Value>> map = intra.getResults();
						
						out.println("-----------Variables impacting Set-----------");
						out.println("--key:impacted----value:impacting------------");
						for(Map.Entry<Value, Set<Value>> entry : map.entrySet()){
							 out.println(entry.getKey()+" "+entry.getValue().toString());
						}
						
						
						Map<Value,Set<Value>> reverse_map = intra.getReverseResults();
						
						out.println("-----------Reverse Variables impacting Set-----------");
						out.println("--key:impacting----value:impacted------------");
						for(Map.Entry<Value, Set<Value>> entry : reverse_map.entrySet()){
							 out.println(entry.getKey()+" "+entry.getValue().toString());
						}
						
	//					map=intra.getReverseResults();
	//					out.println("-----------Variables impacted Set-----------");
	//					for(Map.Entry<Value, Set<Value>> entry:map.entrySet()){
	//						 out.println(entry.getKey()+" "+entry.getValue().toString());
	//					}
						
						Set<Value> final_values = intra.getFinalValues();
						out.println("-----------Final Variables-----------");	
						out.println(final_values.toString());
						
						Map<Value,Set<Value>> map_merged = intra.getMergedResults();					
						out.println("-----------Variables merged impacting Set-----------");					
						for(Map.Entry<Value, Set<Value>> entry : map_merged.entrySet()){
							 out.println(entry.getKey()+" "+entry.getValue().toString());
						}
						
						Set<Value> data_related_variables = intra.getDataRelatedVariables();
						out.println("-----------Data Related Variables-----------");	
						out.println(data_related_variables.toString());
						
						Set<Value> loop_counters = intra.getLoopCounter();
						out.println("-----------Loop Counter Variables-----------");	
						out.println(loop_counters.toString());
						
					//	lg.printPaths(out);
					//	lg.printPathConditions_Exceptions(out);
					//	Set<PathExit> exits=lg.printLoopExitConditions_Exceptions(out);  //print only the exit paths
						boolean isDataRelated = lg.checkDataRelated(out, exits, map_merged, data_related_variables, loop_counters);
						
						//currently we don't use the TP pattern to match, just use the FP pattern to filter.
						/*
						if(isDataRelated){
							TPPattern1 checkTPpattern1 = new TPPattern1();
							out.println("-------------Check mathing TP pattern1-----------------------");
							int pathId = 0;
							for(LoopPath nonExitPath1 : nonExitPaths){
								boolean matched = true;
								//for(int i = innerIDs.size(); i >= 0; i--){ //exclude the innerest loops in iterations
									//List<Integer> notbelongIDs = innerIDs.subList(i, innerIDs.size());
									//List<Stmt> statements = MethodUtils.getMethodStmts(body, loopID, notbelongIDs);
									List<Stmt> statements = MethodUtils.getMethodAllStmts(body);
									//out.println("not consider the inner loop " + notbelongIDs + ":");
									if(checkTPpattern1.compareIOasStridePattern(body, nonExitPath1, nonExitPaths, statements, out) == true){
										out.println("Path " + pathId + ": " + "Matching True Positive Pattern1.");
										matched = matched & true;
									} else {
										out.println("Path " + pathId + ": " + "Not Match True Positive Pattern1.");
										matched = false;
									}
								//}
								pathId++;
							}
							out.println("-------------End Checking mathing TP pattern1----------------");
						}*/
					}
				}
			}
		}
	}
	
	
	/* Pattern 1: like "i = 0; i > 3; i++"
	 * Usage: only for non-exit loop paths
	 * Constraint: paths must contain path1
	 **/
	void compareConstantPattern(LoopPath path1, List<LoopPath> paths){ 
		//List<Stmt> path1stmts = path1.getpathStmt();
		Map<Value, List<Stmt>> conVarMap = new HashMap<Value, List<Stmt>>();
		for(LoopPath path2: paths){
			List<Stmt> path2stmts = path2.getpathStmt();
			List<Condition> path1conds = path1.conds; //all the condition in path1
			//List<Value> path1conVars = new ArrayList<Value>();
			for(Condition cond : path1conds){
				Value conVar1 = cond.cond.getOp1();
				Value conVar2 = cond.cond.getOp2();
				if(!(conVar2 instanceof Constant)){
					continue; //not match pattern "i = 0; i > 3; i++"
				}
				//put the other "i > 3" conditions in the conVarMap
				for(Stmt path2stmt : path2stmts){
					List<ValueBox> defs = path2stmt.getDefBoxes();
					for(ValueBox def : defs){
						if(def.getValue().equals(conVar1)){
							if(conVarMap.containsKey(conVar1)){
								List<Stmt> conVarStmts = conVarMap.get(conVar1);
								conVarStmts.add(path2stmt);
								conVarMap.put(conVar1, conVarStmts);
							} else {
								List<Stmt> conVarStmts = new ArrayList<Stmt>();
								conVarStmts.add(path2stmt);
								conVarMap.put(conVar1, conVarStmts);
							}
						}
					}
				//List<ValueBox> uses = path1stmt.getUseBoxes();
				}
			}
		}
		//call compareStmts function.
		Map<Value, Boolean> sameOrNotMap = compareStmts(conVarMap);
		Iterator<Entry<Value, Boolean>> sameOrNotIt = sameOrNotMap.entrySet().iterator();
		while(sameOrNotIt.hasNext()){
			Entry<Value, Boolean> sameOrNotEntry = sameOrNotIt.next();
			if(sameOrNotEntry.getValue() == true){ //the condition variable has the same change in all non-exit loop paths
				
			}
		}
	}
	
	Map<Value, Boolean> compareStmts(Map<Value, List<Stmt>> conVarMap){
		Map<Value, Boolean> sameStmts = new HashMap<Value,Boolean>();
		Iterator<Entry<Value, List<Stmt>>> conVarIt = conVarMap.entrySet().iterator();
		while(conVarIt.hasNext()){
			Entry<Value, List<Stmt>> conVarEntry = conVarIt.next();
			Value conVar = conVarEntry.getKey();
			List<Stmt> conVarStmts = conVarEntry.getValue();
		}
		return sameStmts;
	}
	

}