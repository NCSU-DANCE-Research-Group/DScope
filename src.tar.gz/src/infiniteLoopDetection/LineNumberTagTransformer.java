package infiniteLoopDetection;
import java.util.Iterator;
import java.util.Map;

import soot.Body;
import soot.BodyTransformer;
import soot.G;
import soot.Unit;
import soot.tagkit.LineNumberTag;
import soot.tagkit.SourceLineNumberTag;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.UnitGraph;

public class LineNumberTagTransformer extends BodyTransformer {

	@Override
	protected void internalTransform(Body body, String phaseName, Map options) {
		// TODO Auto-generated method stub
		String classname = body.getMethod().getDeclaringClass().getName();
		// use signature instead to avoid same-name functions
		String methodname = body.getMethod().getSubSignature();
		G.v().out.println("LineNumberTagTransformer: " + classname + ": "
				+ methodname);

		// if(!LoopUtils.isPrint(classname)){ //if it is not the targeted
		// function, then do nothing
		// return;
		// }
		
		
		UnitGraph g = new ExceptionalUnitGraph(body);
		Iterator<Unit> it = g.iterator();
		int i = 0;
		while (it.hasNext()) {
			Unit u = it.next();
			G.v().out.println(u.toString());
			int lu = u.getJavaSourceStartLineNumber();
			G.v().out.println("line number from source: " + lu);
			
			if (u.hasTag("LineNumberTag")) {
				LineNumberTag t = (LineNumberTag) u.getTag("LineNumberTag");
				
				G.v().out.println("line number: " + t.getLineNumber());
				G.v().out.println("class: "+t.getClass().toString());
				G.v().out.println("String: "+t.toString());
				G.v().out.println("value:"+t.getValue());
			}
			
//			if (u.hasTag("SourceLineNumberTag")) {   //This part does not work, the correct way is unit.getJavaSoruceStartLineNumber();
//				G.v().out.println(u.toString());
//				SourceLineNumberTag t = (SourceLineNumberTag) u
//						.getTag("SourceLineNumberTag");
//				
//				G.v().out.println("source line number: " + t.getLineNumber());
//				G.v().out.println("source class: "+t.getClass().toString());
//				G.v().out.println("source String: "+t.toString());
//				G.v().out.println("source value:"+t.getValue());
//			}
		}
	}
}