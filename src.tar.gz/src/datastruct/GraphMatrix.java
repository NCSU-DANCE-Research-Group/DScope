package datastruct;

import java.util.Collection;
import java.util.Set;
import java.util.HashSet;

/**
 * Adjacency Matrix implementation of a simple graph.
 *   @param <E> 
 *   @author Dave Reed
 *   @version 11/25/13
 */
public class GraphMatrix<E> extends DiGraphMatrix<E> {
        
    /**
     * Constructs an empty simple graph.
     */
    public GraphMatrix(Collection<E> vertices) {
        super(vertices);
    }
   
    /**
     * Adds an edge to the graph.
     *   @param v1 the vertex at the start of the edge
     *   @param v2 the vertex at the end of the edge
     */
    public void addEdge(E v1, E v2) {
        super.addEdge(v1, v2);
        super.addEdge(v2, v1);
    }
    
    ////////////////////////////////////////////////////////////////
    
    public static void main(String[] args) {
        Set<String> v = new HashSet<String>();
        v.add("foo");
        v.add("bar");
        v.add("biz");
        v.add("boo");
        
        Graph<String> words = new DiGraphMatrix<String>(v);
        words.addEdge("foo", "bar");
        words.addEdge("foo", "biz");
        words.addEdge("bar", "boo");
        words.addEdge("boo", "foo");
        
        System.out.println(words.getAdj("foo"));
        System.out.println(words.getAdj("bar"));
        System.out.println(words.getAdj("biz"));
        System.out.println(words.getAdj("boo"));
        
        System.out.println(words.containsEdge("foo", "biz") + " " +
                           words.containsEdge("foo", "boo"));
    }
}
