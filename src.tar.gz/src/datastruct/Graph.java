package datastruct;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Interface that defines a generic graph.
 *   @author Dave Reed
 *   @version 11/25/13
 */
public interface Graph<E> {
    public abstract void addEdge(E v1, E v2);
    public abstract Set<E> getAdj(E v);
    public abstract boolean containsEdge(E v1, E v2);
    //public abstract boolean isreachable(E v1, E v2);
	public abstract void printMatrix();
	public abstract List<E> BFS(E v);
	public abstract Map<E, Integer> getLookUp();
}
