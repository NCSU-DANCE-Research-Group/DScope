package datastruct;

/**
 * Generic class that implements a binary tree structure.
 *   @author Dave Reed
 *   @version 10/14/13
 */
public class BinaryTree<E> {
	
    protected class TreeNode<T> {
        private T data;
        private TreeNode<T> left;
        private TreeNode<T> right;

        public TreeNode(T d, TreeNode<T> l, TreeNode<T> r) {
            this.data = d;
            this.left = l;
            this.right = r;
        }

        public T getData() {
            return this.data;
        }

        public TreeNode<T> getLeft() {
            return this.left;
        }

        public TreeNode<T> getRight() {
            return this.right;
        }

        public void setData(T newData) {
            this.data = newData;
        }

        public void setLeft(TreeNode<T> newLeft) {
            this.left = newLeft;
        }

        public void setRight(TreeNode<T> newRight) {
            this.right = newRight;
        }
    }
    
    protected TreeNode<E> root;

    /**
     * Constructs an empty binary tree.
     */
    public BinaryTree() {
        this.root = null;
    }

    /**
     * Adds a value to the binary tree (at the shallowest possible location)
     *   @param value the value to be added
     */
    public void add(E value) {
        this.root = this.add(this.root, value);
    }
    
    private TreeNode<E> add(TreeNode<E> current, E value) {
        if (current == null) {
            current = new TreeNode<E>(value, null, null);
        }
        else if (this.size(current.getLeft()) <= this.size(current.getRight())) {
            current.setLeft(this.add(current.getLeft(), value));
        }
        else {
            current.setRight(this.add(current.getRight(), value));
        }
        return current;
    }
    
    public void addCallee(E value1, E value2) {//caller, callee
    	TreeNode<E> node2 = retrive(this.root, value2);
    	if(node2 == null){
    		addCallee(retrive(this.root, value1), value2);
    	} else {
    		
    	}
    }
    
    private TreeNode<E> addCallee(TreeNode<E> current, E value) {
        if (current == null) {
            current = new TreeNode<E>(value, null, null);
        }
        if(current.getLeft() == null){
        	current.setLeft(this.add(current.getLeft(), value));
        } else {
        	current.setRight(this.add(current.getRight(), value));
        }
        return current;
    }



    /**
     * Determines the size of the binary tree
     *   @return the size (number of nodes in the tree)
     */
    public int size() {
        return this.size(this.root);
    }
    
    private int size(TreeNode<E> current) {
        if (current == null) {
            return 0;
        }
        else {
            return this.size(current.getLeft()) +
                   this.size(current.getRight()) + 1;
        }
    }


    /**
     * Determines whether the tree contains a particular value.
     *   @param value the value to be searched for
     *   @return true if value is in the tree, otherwise false
     */
    public boolean contains(E value) {
        return this.contains(this.root, value);
    }
    private  boolean contains(TreeNode<E> current, E value) {
        if (current == null) {
            return false;
        }
        else {
            return value.equals(current.getData()) ||
                   this.contains(current.getLeft(), value) ||
                   this.contains(current.getRight(), value);
        }
    }
    
    public TreeNode<E> retrive(E value) {
        return this.retrive(this.root, value);
    }
    private  TreeNode<E> retrive(TreeNode<E> current, E value) {
        if (current == null) {
            return null;
        }
        else {
        	if(value.equals(current.getData()))
        		return current;
        	else{
        		TreeNode<E> leftnode = retrive(current.getLeft(), value);
        		if(leftnode != null)
        			return leftnode;
        		else
        			return retrive(current.getRight(), value);
        	}
        }
    }


    /**
     * Removes one occurrence of the specified value.
     *   @param value the value to be removed
     *   @return true if the value was found and removed, else false
     */
    public boolean remove(E value) {
        if (!this.contains(value)) {
            return false;
        }
        else {
            this.root = this.remove(this.root, value);
            return true;
        }
    }
    
    private TreeNode<E> remove(TreeNode<E> current, E value) {
        if (value.equals(current.getData())) {
            if (current.getLeft() == null) {
                current = current.getRight();
            }
            else {
                TreeNode<E> righty = current.getLeft();
                while (righty.getRight() != null) {
                    righty = righty.getRight();
                }
                current.setData(righty.getData());
                current.setLeft(this.remove(current.getLeft(), current.getData()));
            }
        }
        else if (this.contains(current.getLeft(), value)) {
            current.setLeft(this.remove(current.getLeft(), value));
        }
        else {
            current.setRight(this.remove(current.getRight(), value));
        }
        return current;
    }


    /**
     * Converts the tree to a String using an inorder traversal.
     *   @return the String representation of the tree.
     */
    public String toString() {
        if (this.root == null) {
            return "[]";
        }

        String recStr = this.toString(this.root);
        return "[" + recStr.substring(0,recStr.length()-1) + "]";
    }
    private String toString(TreeNode<E> current) {
        if (current ==  null) {
            return "";
        }

        return this.toString(current.getLeft()) +
               current.getData().toString() + "," +
               this.toString(current.getRight());
    }


    public static void main(String[] args) {
//        BinaryTree<Integer> tree = new BinaryTree<Integer>();
//        tree.add(7);
//        tree.add(2);
//        tree.add(12);
//        tree.add(1);
//        tree.add(5);
//        tree.add(6);
//        tree.add(99);
//        tree.add(88);
//
//        System.out.println(tree);
//        System.out.println("size = " + tree.size());
//        System.out.println(tree.contains(2) + " " + tree.contains(5)
//                                            + " " + tree.contains(8));
//
//        tree.remove(2);
//        System.out.println(tree);
//        System.out.println("size = " + tree.size());
//        System.out.println(tree.contains(2) + " " + tree.contains(5)
//                                            + " " + tree.contains(8));
        
        ///testing add callee....
        BinaryTree<Integer> tree2 = new BinaryTree<Integer>();
        tree2.add(7);
        tree2.addCallee(7, 3);
        tree2.addCallee(7, 4);
        tree2.addCallee(3, 2);
        System.out.println(tree2);
    }
}
