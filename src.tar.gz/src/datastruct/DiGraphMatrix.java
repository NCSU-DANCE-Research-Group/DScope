package datastruct;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Objects;
import java.util.Queue;
import java.util.Set;
import java.util.HashSet;
import java.util.Collection;
import java.util.Map.Entry;

/**
 * Adjacency Matrix implementation of a directed graph.
 *   @param <E> 
 *   @author Dave Reed
 *   @version 11/25/13
 */
public class DiGraphMatrix<E> implements Graph<E>{
    private E[] vertices;
    private Map<E, Integer> lookup;
    private boolean[][] adjMatrix;
    //private boolean[][] reachableMatrix; //row, column
    private List<E> allPaths = new ArrayList<E>();
    /**
     * Constructs an empty directed graph.
     */
    public DiGraphMatrix(Collection<E> vertices) {
        this.vertices = (E[])(new Object[vertices.size()]);
        this.lookup = new HashMap<E, Integer>();
        
        int index = 0;
        for (E nextVertex : vertices) {
            this.vertices[index] = nextVertex;
            lookup.put(nextVertex, index);
            index++;
        }
        
        this.adjMatrix = new boolean[index][index];
        //this.reachableMatrix = new boolean[index][index];
    }
    
    public Map<E, Integer> getLookUp(){
    	return lookup;
    }
    
    /**
     * Adds an edge to the graph.
     *   @param v1 the vertex at the start of the edge
     *   @param v2 the vertex at the end of the edge
     */
    public void addEdge(E v1, E v2) {
        Integer index1 = this.lookup.get(v1);
        Integer index2 = this.lookup.get(v2);
        if (index1 == null || index2 == null) {
            throw new java.util.NoSuchElementException();
        }
        this.adjMatrix[index1][index2] = true;
    }
    

    /**
     * Gets all adjacent vertices.
     *   @param v a vertex in the graph
     *   @return a set of all vertices adjacent to v
     */
    public Set<E> getAdj(E v) {
        int row = this.lookup.get(v);
        
        Set<E> neighbors = new HashSet<E>();
        for (int c = 0; c < this.adjMatrix.length; c++) {
            if (this.adjMatrix[row][c]) {
                neighbors.add(this.vertices[c]);
            }
        }
        return neighbors;
    }

//    public List<E> getAllPath(E v){
//    	allPaths = new ArrayList<E>(adjMatrix.length); //empty the lists
//    	for(List<E> path: allPaths){
//    		path.add(v);
//    	}
//    	return allPaths;
//    }
//    
//    private void addMoreVs(E v, List<E> path){
//    	for(E vet : getAdj(v)){
//    		
//    	}
//    	
//    }
    /**
     * Determines whether the graph contains an edge.
     *   @param v1 the vertex at the start of the edge
     *   @param v2 the vertex at the end of the edge
     *   @return true if v1->v2 edge is in the graph
     */
    public boolean containsEdge(E v1, E v2) {
        Integer index1 = this.lookup.get(v1);
        Integer index2 = this.lookup.get(v2);
        return index1 != null && index2 != null && 
               this.adjMatrix[index1][index2];
    }
    
//    //prints BFS traversal from a given source s
//    public boolean isreachable(E s, E d)
//    {
//        // Mark all the vertices as not visited(By default set as false)
//        Map<E, Boolean> visited = new HashMap<E, Boolean>();
//        // Create a queue for BFS
//        LinkedList<E> queue = new LinkedList<E>();
// 
//        // Mark the current node as visited and enqueue it
//        visited.put(s, true);
//        queue.add(s);
// 
//        // 'i' will be used to get all adjacent vertices of a vertex
//        //Iterator<E> i;
//        while (queue.size()!=0)
//        {
//            // Dequeue a vertex from queue and print it
//            s = queue.poll();
// 
//            for(E n : getAdj(s)){
// 
//            // Get all adjacent vertices of the dequeued vertex s
//            // If a adjacent has not been visited, then mark it visited and enqueue it
//                // If this adjacent node is the destination node,
//                // then return true
//                if (n == d)
//                    return true;
// 
//                // Else, continue to do BFS
//                if (!visited.containsKey(n) || (visited.containsKey(n) && !visited.get(n)))
//                {
//                    visited.put(n, true);
//                    queue.add(n);
//                }
//            }
//        }
// 
//        // If BFS is complete without visited d
//        return false;
//    }
    
    public List<E> BFS(E givenVertex){ //this is the vertex value, not the vertex index
    	Integer givenIndex = this.lookup.get(givenVertex);
    	int vertexCount = this.adjMatrix.length;
        // Result array.
        boolean[] mark = new boolean[vertexCount];

        Queue<Integer> queue = new LinkedList<Integer>();
        queue.add(givenIndex);
        //mark[givenIndex] = true;

        while (!queue.isEmpty())
        {
          Integer current = queue.remove();

          for (int i = 0; i < vertexCount; ++i) //i is index, not value
              if (adjMatrix[i][current] && !mark[i])
              {
                  mark[i] = true;
                  queue.add(i);
              }
        }

        //return mark;
        List<E> reached = new ArrayList<E>();
        for(int i = 0; i < mark.length; i++){
        	if(mark[i])
        		reached.add(getKeyByValue(this.lookup, i));
        }
        
        return reached;
    }
    
	private <T, E> T getKeyByValue(Map<T, E> map, E value) {
	    for (Entry<T, E> entry : map.entrySet()) {
	        if (Objects.equals(value, entry.getValue())) {
	            return entry.getKey();
	        }
	    }
	    return null;
	}
    
    public void printMatrix(){
    	
    	for(int r = 0; r < this.adjMatrix.length; r++){
    		for(int c = 0; c < this.adjMatrix.length; c++){
    			System.out.print(this.adjMatrix[r][c]+ "\t");
    		}
    		System.out.println();
    	}
    }
   ////////////////////////////////////////////////////////////////
    
    public static void main(String[] args) {
        Set<String> v = new HashSet<String>();
        v.add("foo");
        v.add("bar");
        v.add("biz");
        v.add("boo");
        
        Graph<String> words = new DiGraphMatrix<String>(v);
        words.addEdge("foo", "bar");
        words.addEdge("foo", "biz");
        words.addEdge("bar", "boo");
        words.addEdge("boo", "foo");
        
        System.out.println(words.getAdj("foo"));
        System.out.println(words.getAdj("bar"));
        System.out.println(words.getAdj("biz"));
        System.out.println(words.getAdj("boo"));
        
        System.out.println(words.containsEdge("foo", "biz") + " " +
                           words.containsEdge("foo", "boo"));
        
//        System.out.println(words.isreachable("foo", "biz"));
//        System.out.println(words.isreachable("biz", "bar"));
        System.out.println(words.BFS("biz"));
        
        
    }




}
