
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import java.util.regex.PatternSyntaxException;

import datastruct.DiGraphMatrix;
import datastruct.Graph;
//import datastruct.MultiTree;


/* This class is original from the numberizeALLFuncReturn class.
 * In numberizeALLFuncReturn, we didn't consider the combinations of interfaces, abstract classes, super/subclasses. 
 * */
public class findAllJavaFuncReturn {

	
	static String analysisClassPath = "";
	static String analysisMethodPath = "";
	static String abstractClassFile = "";
	static String abstractClassPath = "";
	static String interfacePath = "";
	static String interfacesFile = "";
	static String outputFile="";
	static String nativeFile = "";
	static String splitSymb = "=";
//	static List<String> files = new ArrayList<String>();
//	static List<classFuncRet> allClasses = new ArrayList<classFuncRet>();
//	static Map<String, List<String>> fun2RetMap = new HashMap<String, List<String>>();
//	static Map<String, InterfaceSubSuper> classinfoMap = new HashMap<String, InterfaceSubSuper>();
	static Map<String, Map<String, Set<String>>> class2FunMap = new HashMap<String, Map<String, Set<String>>>();//true=io func
	//abstract methods can only be in abstract class.
	static Map<String, Map<String,Boolean>> absClass2FunMap = new HashMap<String, Map<String,Boolean>>();//true=abstract methods.
	static Map<String, Set<String>> inter2FunMap = new HashMap<String, Set<String>>();
	static Set<String> needAnalyzeClasses = new HashSet<String>();
//	static List<String> interfaceReplaced = new ArrayList<String>();
//	static Map<String, Map<String, List<String>>> class2fun2RetMap = new HashMap<String, Map<String, List<String>>>();
	static Map<String, Set<String>> funDependMap = new HashMap<String, Set<String>>();// key is caller, value is callee. or key is the method in interface/subclass, value is the methods in implementations/superclass
	static Map<String, Set<String>> funDependMapR = new HashMap<String, Set<String>>();//key is callee, value is caller. or key is the method in implementation/superclass, value is the methods in interface/subclass
//	static Map<String, Map<String, List<String>>> class2funDependMap = new HashMap<String, Map<String, List<String>>>();
 	static Map<String, Set<String>> superClassMap = new HashMap<String, Set<String>>();//<K,V>=<super,subs>
	static Map<String, String> superClassMapR = new HashMap<String, String>();//<K,V>=<sub,super>
	static Map<String, Set<String>> interfaceMap = new HashMap<String, Set<String>>();//<K,V>=<implements,interface>
	static Map<String, Set<String>> interfaceMapR = new HashMap<String, Set<String>>();//<K,V>=<interface,implements>
	static Set<String> allSuperClasses = new HashSet<String>();
	
	static Set<String> allInterfaces = new HashSet<String>();
	static Set<String> allAbstractClasses = new HashSet<String>();
	
	static Map<String, Set<String>> nativeFun2RetMap = new HashMap<String, Set<String>>();
	static Map<String, Set<String>> appIOMethods = new HashMap<String, Set<String>>(); 
	public static Logger logger = Logger.getLogger(findAllJavaFuncReturn.class.getName());
	
	public static void main(String[] args){
		args = new String[] {"-Classpath", 
				             "/home/ting/DataLoopBugDetection/ResultIOClasses/openjdk.fun.ret/classes",
				             "-Methodpath", 
				             "/home/ting/DataLoopBugDetection/ResultIOClasses/openjdk.fun.ret/methods",
				             "-AbstractClasses",
				             "/home/ting/DataLoopBugDetection/ResultIOClasses/openjdk.fun.ret/abstracts.log",
				             "-Interfaces",
				             "/home/ting/DataLoopBugDetection/ResultIOClasses/openjdk.fun.ret/interfaces.log",
				             "-AbstractClassPath",
				             "/home/ting/DataLoopBugDetection/ResultIOClasses/openjdk.fun.ret/abstractClasses",
				             "-InterfacePath",
				             "/home/ting/DataLoopBugDetection/ResultIOClasses/openjdk.fun.ret/interfaces",
				             "-native",
				             "/home/ting/DataLoopBugDetection/ResultIOClasses/JNI.summary",
				             "-output", 
				             "/home/ting/DataLoopBugDetection/ResultIOClasses/openjdk.fun.ret/openjdk.fun.ret.summary"
				            };
		handleArgs(args);
		
		File outfile = new File(outputFile);
	    if (outfile.exists()) {
	    	outfile.delete();     
	    }
	    readNativeFunc();
	    readAbstractClass();
	    readInterface();
		readAbstractClasses();
		readInterfaces();
		readClasses();
		readMethods();
//		System.out.println("after readMethods");
//		testInputStreamSkip();
		linkIntImps();
//		System.out.println("after linkIntImps");
//		testInputStreamSkip();
		linkClasses();
//		System.out.println("after linkClasses");
//		testInputStreamSkip();
		propagrateIO();
//		System.out.println("after propagrateIO");
//		testInputStreamSkip();
		write2File();
	}
	
	public static void readNativeFunc(){
		logger.info("starting reading native input file...");
		InputStream instream = null;
		BufferedReader reader = null;
		String line = "";
		try {
			instream = new FileInputStream(nativeFile);
			reader = new BufferedReader(new InputStreamReader(instream));
			String className = "";
			String funcName = "";
			
			while ((line = reader.readLine()) != null) {
				String[] lineSplit = line.split(":");
				className = lineSplit[0];
				funcName = lineSplit[1];
				String[] retSplit = lineSplit[2].split(",");
				Set<String> retVals = new HashSet<String>();
				for(String ret : retSplit){
					if(ret.equals("NULL")){
						retVals.add("null");
					} else if(ret.equals("JNI_TRUE")){
						retVals.add("true");
					} else if(ret.equals("JNI_FALSE")){
						retVals.add("false");
					} else if(ret.equals("jlong_zero")){
						retVals.add("0L");
					} else{
						retVals.add(ret);
					}
				}
				if(retVals.size()>0){
					nativeFun2RetMap.put(className+splitSymb+funcName, retVals);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		logger.info("finish reading native input file...");
		
	}
	
	public static void readAbstractClass(){
		logger.info("starting reading abstract classe file...");
		InputStream instream = null;
		BufferedReader reader = null;
		String line = "";
		try {
			instream = new FileInputStream(abstractClassFile);
			reader = new BufferedReader(new InputStreamReader(instream));
			while ((line = reader.readLine()) != null) {
				if(line.length() > 0){
					allAbstractClasses.add(line);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		logger.info("finish reading abstract classe file...");
	}
	
	public static void readInterface(){
		logger.info("starting reading interface file...");
		InputStream instream = null;
		BufferedReader reader = null;
		String line = "";
		try {
			instream = new FileInputStream(interfacesFile);
			reader = new BufferedReader(new InputStreamReader(instream));
			while ((line = reader.readLine()) != null) {
				if(line.length() > 0){
					allInterfaces.add(line);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		logger.info("finish reading interface file...");		
	}
	
	public static void readAbstractClasses(){
		logger.info("starting reading abstract class files...");
		if(abstractClassPath != null && abstractClassPath != ""){
			List<String> files = new ArrayList<String>();
			File folder = new File(abstractClassPath);
			File[] listofFiles = folder.listFiles();
			for(File file : listofFiles){
			    if (file.isFile()) {
			        files.add(file.getName());
			    }
			}
			for(String file : files){
				String className = file.replace(".txt", "");
				InputStream instream = null;
				BufferedReader reader = null;
				String line = "";
				Map<String, Boolean> funcAbs = new HashMap<String, Boolean>();
				Map<String, Set<String>> funcRets = new HashMap<String, Set<String>>();
				try {
					instream = new FileInputStream(abstractClassPath+"/"+file);
					reader = new BufferedReader(new InputStreamReader(instream));
					while ((line = reader.readLine()) != null) {
						if(line.startsWith("notAbsMethod=")){
							String methodName = line.replace("notAbsMethod=", "").split(" ")[1];//not include return value
							funcAbs.put(methodName, false);
//							funcIO.put(methodName, false);
							Set<String> returns = new HashSet<String>();
							funcRets.put(methodName, returns);
						} else if(line.startsWith("abstractMethod=")){
							String methodName = line.replace("abstractMethod=", "").split(" ")[1];//not include return value
							funcAbs.put(methodName, true);
//							funcIO.put(methodName,false);
							Set<String> returns = new HashSet<String>();
							funcRets.put(methodName, returns);
						} else if(line.contains("extends=")){
							String superClass = line.replace("extends=","");
							if(!superClass.equals("java.lang.Object")){ //we do not consider java.lang.Object, cause its the root of every class.
								                                        //every class has java.lang.Object as the super class.
								if(superClassMap.containsKey(superClass)){
									Set<String> subClasses = superClassMap.get(superClass);
									subClasses.add(className);
									superClassMap.put(superClass, subClasses);
								} else {
									Set<String> subClasses = new HashSet<String>();
									subClasses.add(className);
									superClassMap.put(superClass, subClasses);
								}
								superClassMapR.put(className, superClass);
							}
						} else if(line.contains("implements=")){
							String[] allInterfaceSplit = line.split("implements=")[1].split(",");
							Set<String> allimplements = new HashSet<String>();
							for(int i = 0; i < allInterfaceSplit.length; i++){
								String interfaceKlass = allInterfaceSplit[i];
								allimplements.add(interfaceKlass);
								if(interfaceMapR.containsKey(interfaceKlass)){
									Set<String> allimplementations = interfaceMapR.get(interfaceKlass);
									allimplementations.add(className);
									interfaceMapR.put(interfaceKlass, allimplementations);
								} else {
									Set<String> allimplementations = new HashSet<String>();
									allimplementations.add(className);
									interfaceMapR.put(interfaceKlass, allimplementations);
								}
								
							}
							interfaceMap.put(className, allimplements);
						}						
					}
					absClass2FunMap.put(className, funcAbs);
					class2FunMap.put(className, funcRets);
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					try {
						reader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
		logger.info("finish reading abstract class files...");
	}
	
	public static void readInterfaces(){
		logger.info("starting reading interface files...");
		if(interfacePath != null && interfacePath != ""){
			List<String> files = new ArrayList<String>();
			File folder = new File(interfacePath);
			File[] listofFiles = folder.listFiles();
			for(File file : listofFiles){
			    if (file.isFile()) {
			        files.add(file.getName());
			    }
			}
			for(String file : files){
				String className = file.replace(".txt", "");
				InputStream instream = null;
				BufferedReader reader = null;
				String line = "";
				Set<String> funcs = new HashSet<String>();
//				Map<String, Boolean> funcIO = new HashMap<String, Boolean>();
				Map<String, Boolean> funcAbs = new HashMap<String, Boolean>();
				Map<String, Set<String>> funcRets = new HashMap<String, Set<String>>();
				try {
					instream = new FileInputStream(interfacePath+"/"+file);
					reader = new BufferedReader(new InputStreamReader(instream));
					while ((line = reader.readLine()) != null) {
						if(line.startsWith("notAbsMethod=")){
							String methodName = line.replace("notAbsMethod=", "").split(" ")[1];//not include return value
							funcs.add(methodName);
//							funcIO.put(methodName, false);
							Set<String> returns = new HashSet<String>();
							funcRets.put(methodName, returns);
							funcAbs.put(methodName, false);
						} else if(line.startsWith("abstractMethod=")){
							String methodName = line.replace("abstractMethod=", "").split(" ")[1];//not include return value
							funcs.add(methodName);
//							funcIO.put(methodName, false);
							Set<String> returns = new HashSet<String>();
							funcRets.put(methodName, returns);
							funcAbs.put(methodName, true);
						} else if(line.contains("extends=")){
							String superClass = line.replace("extends=","");
							if(!superClass.equals("java.lang.Object")){ //we do not consider java.lang.Object, cause its the root of every class.
								                                        //every class has java.lang.Object as the super class.
								if(superClassMap.containsKey(superClass)){
									Set<String> subClasses = superClassMap.get(superClass);
									subClasses.add(className);
									superClassMap.put(superClass, subClasses);
								} else {
									Set<String> subClasses = new HashSet<String>();
									subClasses.add(className);
									superClassMap.put(superClass, subClasses);
								}
								superClassMapR.put(className, superClass);
							}
						} else if(line.contains("implements=")){
							String[] allInterfaceSplit = line.split("implements=")[1].split(",");
							Set<String> allimplements = new HashSet<String>();
							for(int i = 0; i < allInterfaceSplit.length; i++){
								String interfaceKlass = allInterfaceSplit[i];
								allimplements.add(interfaceKlass);
								if(interfaceMapR.containsKey(interfaceKlass)){
									Set<String> allimplementations = interfaceMapR.get(interfaceKlass);
									allimplementations.add(className);
									interfaceMapR.put(interfaceKlass, allimplementations);
								} else {
									Set<String> allimplementations = new HashSet<String>();
									allimplementations.add(className);
									interfaceMapR.put(interfaceKlass, allimplementations);
								}
								
							}
							interfaceMap.put(className, allimplements);
						}
					}
					inter2FunMap.put(className, funcs);
//					class2FunMap.put(className, funcIO);
					absClass2FunMap.put(className, funcAbs);
					class2FunMap.put(className, funcRets);
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					try {
						reader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
		logger.info("finish reading interface files...");
	}
	
	public static void readClasses(){
		logger.info("starting reading class files...");
		List<String> files = new ArrayList<String>();
		if(analysisClassPath != null && analysisClassPath != ""){
			File folder = new File(analysisClassPath);
			File[] listofFiles = folder.listFiles();
			for(File file : listofFiles){
			    if (file.isFile()) {
			        files.add(file.getName());
			    }
			}
			for(String file : files){
				String className = file.replace(".txt", "");
//				Map<String, Boolean> funcIO = new HashMap<String, Boolean>();
				InputStream instream = null;
				BufferedReader reader = null;
				String line = "";
				try {
					instream = new FileInputStream(analysisClassPath+"/"+file);
					reader = new BufferedReader(new InputStreamReader(instream));
					while ((line = reader.readLine()) != null) {
						if(line.contains("extends=")){
							String superClass = line.replace("extends=","");
							if(!superClass.equals("java.lang.Object")){ //we do not consider java.lang.Object, cause its the root of every class.
								                                        //every class has java.lang.Object as the super class.
								if(superClassMap.containsKey(superClass)){
									Set<String> subClasses = superClassMap.get(superClass);
									subClasses.add(className);
									superClassMap.put(superClass, subClasses);
								} else {
									Set<String> subClasses = new HashSet<String>();
									subClasses.add(className);
									superClassMap.put(superClass, subClasses);
								}
								superClassMapR.put(className, superClass);
							}
						} else if(line.contains("implements=")){
							String[] allInterfaceSplit = line.split("implements=")[1].split(",");
							Set<String> allimplements = new HashSet<String>();
							for(int i = 0; i < allInterfaceSplit.length; i++){
								String interfaceKlass = allInterfaceSplit[i];
								allimplements.add(interfaceKlass);
								if(interfaceMapR.containsKey(interfaceKlass)){
									Set<String> allimplementations = interfaceMapR.get(interfaceKlass);
									allimplementations.add(className);
									interfaceMapR.put(interfaceKlass, allimplementations);
								} else {
									Set<String> allimplementations = new HashSet<String>();
									allimplementations.add(className);
									interfaceMapR.put(interfaceKlass, allimplementations);
								}
								
							}
							interfaceMap.put(className, allimplements);
						}
					}
					if(!class2FunMap.containsKey(className)){
						Map<String, Set<String>> funcRets = new HashMap<String, Set<String>>();
						class2FunMap.put(className, funcRets);
					}
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					try {
						reader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
		logger.info("finish reading class files...");
	}
	
	public static void readMethods(){
		logger.info("start reading method files...");
		if(analysisMethodPath != null && analysisMethodPath != ""){
			List<String> files = new ArrayList<String>();
			File folder = new File(analysisMethodPath);
			File[] listofFiles = folder.listFiles();
			for(File file : listofFiles){
			    if (file.isFile()) {
			        files.add(file.getName());
			    }
			}
			for(String file : files){
				InputStream instream = null;
				BufferedReader reader = null;
				String line = "";
				try {
					instream = new FileInputStream(analysisMethodPath+"/"+file);
					reader = new BufferedReader(new InputStreamReader(instream));
					Set<String> returnVals = new HashSet<String>();
					Set<String> natives = new HashSet<String>();
					String funcFullname = file.replace(".txt","");
					String klassName  = funcFullname.split(splitSymb)[0];
					while ((line = reader.readLine()) != null) {
						if(line.contains("natives=")){
							String nativeFunc = line.replace("natives=","").split(" ")[1];//del return type
							natives.add(klassName+splitSymb+nativeFunc);
						}
						if(line.contains("return=<")){
							String[] returnValSplits = line.replace("return=<","").replace(")>",")").split(": ");
							String returnVal = returnValSplits[0]+splitSymb+returnValSplits[1].split(" ")[1]; //del the return type
							returnVals.add(returnVal);
							
						} else if(line.contains("return=")){
//							if(funcFullname.startsWith("java.io.InputStream_skip")){
//								System.out.println(line);
//							}
							returnVals.add(line.replace("return=",""));//it is the explict return value, e.g., 0L, null, true, ...
						}
					}
					Set<String> needChange = new HashSet<String>();
					for(String returnVal : returnVals){
//						String nativeName = returnVal.substring(0, returnVal.indexOf("("));//native func is without arguments
						if(natives.contains(returnVal)){ //java method invokes JNI
							needChange.add(returnVal);
						} else {
//							returnVals.add(returnVal);								
							if(funDependMap.containsKey(funcFullname)){//key is caller, value is callee
								Set<String> callees = funDependMap.get(funcFullname);
								callees.add(returnVal);
								funDependMap.put(funcFullname, callees);
							} else {
								Set<String> callees = new HashSet<String>();
								callees.add(returnVal);
								funDependMap.put(funcFullname, callees);
							}
							if(funDependMapR.containsKey(returnVal)){//key is callee, value is caller
								Set<String> callers = funDependMapR.get(returnVal);
								callers.add(funcFullname);
								funDependMapR.put(returnVal, callers);
							} else {
								Set<String> callers = new HashSet<String>();
								callers.add(funcFullname);
								funDependMapR.put(returnVal, callers);
							}
							String invocaClass = returnVal.split(splitSymb)[0];
							needAnalyzeClasses.add(invocaClass);
						}
					}
					for(String returnVal : needChange){
						String nativeName = returnVal;
						if(nativeName.contains("(")){
							nativeName = nativeName.substring(0,nativeName.indexOf("("));
						} 
						if(nativeFun2RetMap.containsKey(nativeName)){
							Set<String> nativeRets = nativeFun2RetMap.get(nativeName);
							returnVals.addAll(nativeRets);
							returnVals.remove(nativeName);
						}
					}
					if(returnVals.size() > 0){
						String[] funcFullSplit = funcFullname.split(splitSymb);
						String className = funcFullSplit[0];
						String funcName = funcFullSplit[1];
						if(class2FunMap.containsKey(className)){
							Map<String, Set<String>> functions = class2FunMap.get(className);
							if(functions.containsKey(funcName)){
								Set<String> returns = functions.get(funcName);
								returns.addAll(returnVals);
								functions.put(funcName, returns);
							} else {
								functions.put(funcName, returnVals);
							}
							class2FunMap.put(className, functions);
						} else {
							Map<String,Set<String>> functions = new HashMap<String,Set<String>>();
							functions.put(funcName, returnVals);
							class2FunMap.put(className, functions);
						}
					}
				} catch (Exception e) {
					logger.severe("Exception: " + e.toString());
					e.printStackTrace();
				} finally {
					try {
						reader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}				
			}
			logger.info("finish reading all methods files");
		}
	}
	

	public static void linkIntImps(){
		logger.info("start linking interfaces and implementation classes...");
		for(String interfaces : allInterfaces){
			if(needAnalyzeClasses.contains(interfaces)){
				if(allSuperClasses.contains(interfaces)){//interface is a super class
					if(!superClassMapR.containsKey(interfaces)){//interface is not a subclass
						Set<String> allSubInterfaces = new HashSet<String>();
						retriveAllSubClasses(interfaces, allSubInterfaces);
						Set<String> allImpClasses = retriveIntsImpClasses(interfaces);
						for(String subInterfaces: allSubInterfaces){
							allImpClasses.addAll(retriveIntsImpClasses(subInterfaces));
						}
						for(String impClass : allImpClasses){
							addDepFromIntf2Imp(interfaces, impClass);
						}
					} else {//interface is both super-/sub-class
						Set<String> allSubInterfaces = new HashSet<String>();
						retriveAllSubClasses(interfaces, allSubInterfaces);
						List<String> allSuperInterfaces = new ArrayList<String>();
						retriveAllSuperClasses(interfaces, allSuperInterfaces);
						Set<String> allImpClasses = retriveIntsImpClasses(interfaces);
						for(String subInterfaces: allSubInterfaces){
							allImpClasses.addAll(retriveIntsImpClasses(subInterfaces));
						}
						for(String superInterfaces: allSuperInterfaces){
							allImpClasses.addAll(retriveIntsImpClasses(superInterfaces));
						}
						for(String impClass : allImpClasses){
							addDepFromIntf2Imp(interfaces, impClass);
						}
						//add sub-super dependency
						addMethodsFromSup2Sub(interfaces, allSuperInterfaces);
					}
				} else if(superClassMapR.containsKey(interfaces)){//interface is only a subclass
					List<String> allSuperInterfaces = new ArrayList<String>();
					retriveAllSuperClasses(interfaces, allSuperInterfaces);
					Set<String> allImpClasses = retriveIntsImpClasses(interfaces);
					for(String superInterfaces: allSuperInterfaces){
						allImpClasses.addAll(retriveIntsImpClasses(superInterfaces));
					}
					for(String impClass : allImpClasses){
						addDepFromIntf2Imp(interfaces, impClass);
					}
					//add sub-super dependency
					addMethodsFromSup2Sub(interfaces, allSuperInterfaces);
				}
			}
		}
		logger.info("finish linking interfaces and implementation classes...");
	}
	
	public static void linkClasses(){
		logger.info("start linking classes...");
		Iterator<Entry<String, Map<String, Set<String>>>> class2FunIt = class2FunMap.entrySet().iterator();
		Entry<String, Map<String, Set<String>>> class2FunEntry = null;
		while(class2FunIt.hasNext()){
			class2FunEntry = class2FunIt.next();
			String className = class2FunEntry.getKey();
			if(needAnalyzeClasses.contains(className)){
				if(!allInterfaces.contains(className)){//for non-interface classes
					if(!superClassMapR.containsKey(className)){//is a subClass
						List<String> allSuperClasses = new ArrayList<String>();
						retriveAllSuperClasses(className, allSuperClasses);
						//add sub-super dependency
						addMethodsFromSup2Sub(className, allSuperClasses);
					} else {//is a super class
//						if(className.equals("java.nio.channels.FileChannel")){
//							System.out.println(className);
//						}
						if(absClass2FunMap.containsKey(className)){
							Map<String, Boolean> abFunmap = absClass2FunMap.get(className);
							Iterator<Entry<String, Boolean>> abFunIt = abFunmap.entrySet().iterator();
							Entry<String, Boolean> abFunEntry = null;
							Set<String> allAbsFuncs = new HashSet<String>();
							while(abFunIt.hasNext()){
								abFunEntry = abFunIt.next();
								String methodName = abFunEntry.getKey();
								boolean isAbs = abFunEntry.getValue();
								if(isAbs){
									allAbsFuncs.add(methodName);
								}
							}
							if(allAbsFuncs.size()>0){
								Set<String> allSubClasses = new HashSet<String>();
								retriveAllSubClasses(className, allSubClasses);
								addMethodDepenFromSub2Sup(className, allSubClasses, allAbsFuncs);
							}
						}
					}
				} 
			}
		}
		logger.info("finish linking classes...");
	}
	
	
	private static void testInputStreamSkip(){
//		if(class2FunMap.containsKey("java.io.InputStream")){
//			Map<String, Set<String>> funcRets = class2FunMap.get("java.io.InputStream");
//			if(funcRets.containsKey("skip(long)")){
//				Set<String> returns = funcRets.get("skip(long)");
//				for(String ret : returns){
//					System.out.println(ret);
//				}
//			}	
//			
//		}
//		//java.io.BufferedInputStream:skip(long):java.io.InputStream=skip(long)
//		String fucFull = "java.io.BufferedInputStream"+splitSymb+"skip(long)";
//		if(funDependMap.containsKey(fucFull)){
//			Set<String> dependecies = funDependMap.get(fucFull);
//			for(String dep : dependecies){
//				System.out.println("dependency = " + dep);
//			}
//		}
		
//		String fucFull = "java.nio.channels.FileChannel"+splitSymb+"transferTo(long,long,java.nio.channels.WritableByteChannel)";
//		if(funDependMap.containsKey(fucFull)){
//			Set<String> dependecies = funDependMap.get(fucFull);
//			for(String dep : dependecies){
//				System.out.println("dependency = " + dep);
//			}
//		}
//		String className = "java.nio.channels.FileChannel";
//		if(superClassMap.containsKey(className)){
//			Set<String> subClasses = superClassMap.get(className);
//			for(String subClass : subClasses){
//				System.out.println("subClass = " + subClass);
//			}
//		}
		
		String className = "java.util.zip.Inflater";
		String methodName="inflate(byte[],int,int)";
		
	}

	
	/* It is insensitively adding.
	 * In runtime, not every implementation are called.
	 * JVM only invoke a specific implementation method. */
	private static void addDepFromIntf2Imp(String interfaces, String implementClass){
		if(class2FunMap.containsKey(interfaces) && class2FunMap.containsKey(implementClass)){
			Map<String, Set<String>> intfuncIO = class2FunMap.get(interfaces);
			Map<String, Set<String>> impfuncIO = class2FunMap.get(interfaces);
			Iterator<Entry<String, Set<String>>> intfuncIt = intfuncIO.entrySet().iterator();
			Entry<String, Set<String>> intfuncEntry = null;
			while(intfuncIt.hasNext()){
				intfuncEntry = intfuncIt.next();
				String funcName = intfuncEntry.getKey();
				if(impfuncIO.containsKey(funcName)){
					String intMethodFull = interfaces+splitSymb+funcName;
					String impMethodFull = implementClass + splitSymb + funcName;
					if(funDependMap.containsKey(intMethodFull)){// key is the method in interface, value is the methods in implementations
						Set<String> depends = funDependMap.get(intMethodFull);
						depends.add(impMethodFull);
						funDependMap.put(intMethodFull, depends);
					} else {
						Set<String> depends = new HashSet<String>();
						depends.add(impMethodFull);
						funDependMap.put(intMethodFull, depends);
					}
					if(funDependMapR.containsKey(impMethodFull)){//key is the method in implementation, value is the methods in interface
						Set<String> depends = funDependMap.get(impMethodFull);
						depends.add(intMethodFull);
						funDependMapR.put(impMethodFull, depends);
					} else {
						Set<String> depends = new HashSet<String>();
						depends.add(intMethodFull);
						funDependMapR.put(impMethodFull, depends);
					}
					needAnalyzeClasses.add(implementClass);
				}
			}
		}
	}
	
	private static void addMethodsFromSup2Sub(String subClass, List<String> allSuperClasses){
//		Map<String, Boolean> subfuncIO = class2FunMap.get(subClass);
		allSuperClasses.add(0, subClass);//all itself in the 0th pos, incase the method is already inside of itself
		Map<String, Set<String>> subfuncIOMerge = new HashMap<String, Set<String>>();
		Map<String, String> funDepend = new HashMap<String, String>();//key is the method in subclass, value is the methods in superclass
		//from the toppest superclass to the direct superclass
		//in this way, if one method is override, then subfuncIO can get updated.
		for(int i = allSuperClasses.size()-1; i >= 0; i--){
			String superClass = allSuperClasses.get(i);
			Map<String, Set<String>> superfuncIO = class2FunMap.get(superClass);
			Iterator<Entry<String, Set<String>>> superfuncIt = superfuncIO.entrySet().iterator();
			Entry<String, Set<String>> superfuncEntry = null;
			while(superfuncIt.hasNext()){
				superfuncEntry = superfuncIt.next();
				String methodName = superfuncEntry.getKey();
				Set<String> returns = superfuncEntry.getValue();
				subfuncIOMerge.put(methodName, returns);
				funDepend.put(subClass+splitSymb+methodName, superClass+splitSymb+methodName);
			}
		}
		Iterator<Entry<String, String>> funcDependIt = funDepend.entrySet().iterator();
		Entry<String, String> funcDependEntry = null;
		while(funcDependIt.hasNext()){
			funcDependEntry = funcDependIt.next();
			String subMethodFull = funcDependEntry.getKey();
			String superMethodFull = funcDependEntry.getValue();
			if(!subMethodFull.equals(superMethodFull)){ //the method is not implemented/override in the subClass
				if(funDependMap.containsKey(subMethodFull)){
					Set<String> depends = funDependMap.get(subMethodFull);
					depends.add(superMethodFull);
					funDependMap.put(subMethodFull, depends);
				} else {
					Set<String> depends = new HashSet<String>();
					depends.add(superMethodFull);
					funDependMap.put(subMethodFull, depends);
				}
				if(funDependMapR.containsKey(superMethodFull)){
					Set<String> depends = funDependMapR.get(superMethodFull);
					depends.add(subMethodFull);
					funDependMapR.put(superMethodFull, depends);
				} else {
					Set<String> depends = new HashSet<String>();
					depends.add(subMethodFull);
					funDependMapR.put(superMethodFull, depends);
				}
				needAnalyzeClasses.add(superMethodFull.split(splitSymb)[0]);
			}
		}
		class2FunMap.put(subClass, subfuncIOMerge);
	}
	
	
	private static void addMethodDepenFromSub2Sup(String className, Set<String> allSubClasses, Set<String> allAbsFuncs){
		for(String absFun : allAbsFuncs){
			for(String subClass : allSubClasses){
				if(class2FunMap.containsKey(subClass)){
					Map<String, Set<String>> funRets = class2FunMap.get(subClass);
					if(funRets.containsKey(absFun)){
						String subMethodFull = subClass+splitSymb+absFun;
						String superMethodFull = className+splitSymb+absFun;
						if(funDependMapR.containsKey(subMethodFull)){//key is the subclass method, value is superClass abstract method
							Set<String> depends = funDependMapR.get(subMethodFull);
							depends.add(superMethodFull);
							funDependMapR.put(subMethodFull, depends);
						} else {
							Set<String> depends = new HashSet<String>();
							depends.add(superMethodFull);
							funDependMapR.put(subMethodFull, depends);
						}
						if(funDependMap.containsKey(superMethodFull)){//key is the superClass abstract method, value is subclass method
							Set<String> depends = funDependMap.get(superMethodFull);
							depends.add(subMethodFull);
							funDependMap.put(superMethodFull, depends);
						} else {
							Set<String> depends = new HashSet<String>();
							depends.add(subMethodFull);
							funDependMap.put(superMethodFull, depends);
						}
						needAnalyzeClasses.add(subClass);
					}
				}
			}
		}
	}
	
	private static Set<String> retriveIntsImpClasses(String interfaces){
		Set<String> allImpClasses = new HashSet<String>();
		if(interfaceMapR.containsKey(interfaces)){
			Set<String> implementClasses = interfaceMapR.get(interfaces);
			for(String implementClass : implementClasses){
				allImpClasses.add(implementClass);
				if(allAbstractClasses.contains(implementClass)){//implement class is an abstract class
					if(superClassMap.containsKey(implementClass)){
						Set<String> AllsubClasses = new HashSet<String>(); //get the Abstract classes' all subclasses(DFS search)
						retriveAllSubClasses(implementClass, AllsubClasses);
						allImpClasses.addAll(AllsubClasses);
					}
				}
			}
		}
		return allImpClasses;
	}
	
	private static void retriveAllSubClasses(String superClass, Set<String> AllsubClasses){
		if(superClassMap.containsKey(superClass)){
			Set<String> subClasses = superClassMap.get(superClass);
			for(String subClass : subClasses){
				AllsubClasses.add(subClass);
				retriveAllSubClasses(subClass, AllsubClasses);
			}
		}
	}
	
	/*the last superClass in the list is the root superclass*/
	private static void retriveAllSuperClasses(String subClass, List<String> AllsuperClasses){
		if(superClassMapR.containsKey(subClass)){
			String superClass = superClassMapR.get(subClass);
			AllsuperClasses.add(superClass);
			retriveAllSuperClasses(superClass, AllsuperClasses);
		}
	}
	
	
	public static void propagrateIO(){
		for(int i = 0; i < 5; i++){
			logger.info("start propagrateIO, iteration " + i);
//			propagrateIOIteration();
			propagrateRetIteration();
		}
	}
	/* This method should call multiple times.
	 * In each iteration, it search class2FunMap,   and funDependMapR
	 * to propagate return results*/
	private static void propagrateIOIteration(){
		Iterator<Entry<String, Map<String, Set<String>>>> class2FunIt = class2FunMap.entrySet().iterator();
		Entry<String, Map<String, Set<String>>> class2FunEntry = null;
		while(class2FunIt.hasNext()){
			class2FunEntry = class2FunIt.next();
			String className = class2FunEntry.getKey();
			Map<String, Set<String>> funcIO = class2FunEntry.getValue();
			Iterator<Entry<String, Set<String>>> funcIt = funcIO.entrySet().iterator();
			Entry<String, Set<String>> funcEntry = null;
			while(funcIt.hasNext()){
				funcEntry = funcIt.next();
				String funcName = funcEntry.getKey();
				Set<String> returns = funcEntry.getValue();
				for(String retFull : returns){
//					try{
					String retClassName = retFull.split(splitSymb)[0];
					String retFuncName = retFull.split(splitSymb)[1];
					if(class2FunMap.containsKey(retClassName)){
						Map<String, Set<String>> funcRets = class2FunMap.get(retClassName);
						if(funcRets.containsKey(retFuncName)){
							Set<String> retReturns = funcRets.get(retFuncName);
							if(retReturns.contains(className+splitSymb+funcName)){
								retReturns.remove(className+splitSymb+funcName);
							}
							returns.remove(retFull);
							returns.addAll(retReturns);
						}
					}
//					}catch(Exception e){
//						e.printStackTrace();
//						logger.warning("retFull = "+ retFull);
//						throw e;
//					}
				}
				funcIO.put(funcName, returns);				
			}
			class2FunMap.put(className, funcIO);
		}
	}
	
	
	private static void propagrateRetIteration(){
		Iterator<Entry<String, Map<String, Set<String>>>> class2FunIt = class2FunMap.entrySet().iterator();
		Entry<String, Map<String, Set<String>>> class2FunEntry = null;
		while(class2FunIt.hasNext()){
			class2FunEntry = class2FunIt.next();
			String className = class2FunEntry.getKey();
			Map<String, Set<String>> funcNames = class2FunEntry.getValue();
			Iterator<Entry<String, Set<String>>> funcIt = funcNames.entrySet().iterator();
			Entry<String, Set<String>> funcEntry = null;
			while(funcIt.hasNext()){
				funcEntry = funcIt.next();
				String methodName = funcEntry.getKey();
				Set<String> allDepends = new HashSet<String>();
				Set<String> alreadyVisited = new HashSet<String>();
				String funcFull = className + splitSymb + methodName;
//				if(className.equals("java.io.BufferedInputStream") && methodName.equals("skip(long)")){
//					retriveAllDepend(funcFull, allDepends, alreadyVisited);
//					funcNames.put(methodName, allDepends);
//				}
				if(funDependMap.containsKey(funcFull)){
					retriveAllDepend(funcFull, allDepends, alreadyVisited);
//					logger.info("allDepends size = " + allDepends.size());
					funcNames.put(methodName, allDepends);
				}
			}
			class2FunMap.put(className, funcNames);
		}
	}
	
	private static void retriveAllDepend(String funcFull, Set<String> allDepend, Set<String> alreadyVisited){
		alreadyVisited.add(funcFull);
		if(funDependMap.containsKey(funcFull)){
			Set<String> dependencies = funDependMap.get(funcFull);
			for(String dependecy : dependencies){
				if(alreadyVisited.contains(dependecy) || dependecy.equals(funcFull) || dependecy.startsWith("java.lang.Object")){
//					allDepend.add(dependecy);
					return;
				} else if(dependecy.contains(splitSymb)){
//					alreadyVisited.add(dependecy);
//					logger.info("dependecy = " + dependecy);
					retriveAllDepend(dependecy, allDepend, alreadyVisited);
				} else {
//					alreadyVisited.add(dependecy);
					allDepend.add(dependecy);
				}
			}
		} else {
			String className = funcFull.split(splitSymb)[0];
			String methodName = funcFull.split(splitSymb)[1];
			if(class2FunMap.containsKey(className)){
				Map<String, Set<String>> funcRets = class2FunMap.get(className);
				if(funcRets.containsKey(methodName)){
					Set<String> returns = funcRets.get(methodName);
					allDepend.addAll(returns);
				}
			}
		}
	}
	
	
	public static void write2File(){
		Iterator<Entry<String, Map<String,Set<String>>>> class2FunIt = class2FunMap.entrySet().iterator();
		Entry<String, Map<String,Set<String>>> class2FunEntry = null;
		while(class2FunIt.hasNext()){
			String outputStr="";
			class2FunEntry = class2FunIt.next();
			String className = class2FunEntry.getKey();
			Map<String, Set<String>> fun2RetMap = class2FunEntry.getValue();
			Iterator<Entry<String,Set<String>>> fun2RetIt = fun2RetMap.entrySet().iterator();
			Entry<String,Set<String>> fun2RetEntry = null;
			while(fun2RetIt.hasNext()){
				fun2RetEntry = fun2RetIt.next();
				String funcName = fun2RetEntry.getKey();
				Set<String> funcRets = fun2RetEntry.getValue();
				String outputRetStr="";
				for(String retVal : funcRets){
					if(!retVal.contains("implements=") && !retVal.contains("extends=") &&
							!retVal.contains("isAbstract=true") && !retVal.contains("isInterface=true") &&
//							!retVal.contains(splitSymb))
							!retVal.contains("("))
						outputRetStr += retVal+",";
				}
//				if(outputRetStr.equals("java.nio.channels.FileChannel")){
//					logger.info(msg);
//				}
				if(!outputRetStr.equals("")){
					outputStr += className + ":" + funcName + ":" + outputRetStr;
					outputStr = outputStr.substring(0, outputStr.length() - 1);//delete last ,
					outputStr+="\n";
				}
			}
//			logger.info("writing " + className +"'s methods into file...");
			write2File(outputFile, outputStr);
		}

		//write2File(outputFile, outputStr);
	}
	
	
	private static void write2File(String filename, String content){
		File fout = new File(filename);
		FileOutputStream fos = null;
		BufferedWriter bw = null;
		try {
			fos = new FileOutputStream(fout, true);
			bw = new BufferedWriter(new OutputStreamWriter(fos));
			bw.write(content);
			bw.flush();
			fos.close();
			bw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void handleArgs(String []args)
    {
        int argIndex = 0;
        while(argIndex < args.length)
        {
            String current = args[argIndex];
            if(current.compareTo("-h") == 0)
            {
                printUsage();
                System.exit(-1);
            } else if(current.compareTo("-Classpath") == 0){
            	argIndex++;
            	analysisClassPath = args[argIndex];
            } else if(current.compareTo("-Methodpath") == 0){
            	argIndex++;
            	analysisMethodPath = args[argIndex];
            } else if(current.compareTo("-AbstractClasses") == 0){
            	argIndex++;
            	abstractClassFile = args[argIndex];
            } else if(current.compareTo("-Interfaces") == 0){
            	argIndex++;
            	interfacesFile = args[argIndex];
            } else if(current.compareTo("-AbstractClassPath") == 0){
            	argIndex++;
            	abstractClassPath = args[argIndex];
            } else if(current.compareTo("-InterfacePath") == 0){
            	argIndex++;
            	interfacePath = args[argIndex];
            } else if(current.compareTo("-native") == 0){
            	argIndex++;
            	nativeFile = args[argIndex];
            } else if(current.compareTo("-output") == 0){
            	argIndex++;
            	outputFile = args[argIndex];
            } else {
                System.out.println("current arg:" + current);
                System.out.println("Invalid configuration params, use -h for usage");
                System.exit(-1);
            }
            argIndex++;
        }
    }
	
    public static void printUsage()
    {
        System.out.println("java findAllJavaFuncReturn [options] "
        		+ "-Classpath analysisClassPath "
        		+ "-Methodpath analysisMethodPath "
        		+ "-AbstractClasses abstractClassFile "
        		+ "-Interfaces interfacesFile "
        		+ "-AbstractClassPath abstractClassPath "
        		+ "-InterfacePath interfacePath "
        		+ "-native nativeFile "
        		+ "-output outputFile");
        System.out.println("Valid options are:");
        System.out.println("-h print help and exit");
    }
    
}

