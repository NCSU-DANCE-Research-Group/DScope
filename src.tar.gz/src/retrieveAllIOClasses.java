import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Map.Entry;
import java.util.logging.Logger;

import utilities.LoopUtils;


public class retrieveAllIOClasses {
	
	static String analysisPath = "";
	static String outputFile = "";
	static List<String> files = new ArrayList<String>();
	public static Logger logger = Logger.getLogger(retrieveAllIOClasses.class.getName());
	static Map<String, Integer> class2ID = new HashMap<String, Integer>();
	static int classID = 0;
	static List<Integer> ioClasses = new ArrayList<Integer>();
	static List<Integer> tobeDeterminedClasses = new ArrayList<Integer>();
	static Map<Integer, List<Integer>> class2filedsMap = new HashMap<Integer, List<Integer>>(); 
	static int maxItNum = 20;
	
	/*
	 * This code can run manually in Eclipse, because it's fast.
	 * The input is the result from the findIOClass 
	 * */
	static public void main(String[] args){		
		String argsManual[] = {
				"-analysisPath", "/home/ting/DataLoopBugDetection/soot-soot-2.5.0/hadoop.0.23.io",
				"-outputFile", "/home/ting/DataLoopBugDetection/soot-soot-2.5.0/hadoop.0.23.ioClass.txt"
				};
		handleArgs(argsManual);
//		String line="field: <org.apache.hadoop.fs.FSDataOutputStream: java.io.OutputStream wrappedStream>";
//		String classname = line.split("field: ")[1].split(":")[0].replace("<", "");
//		System.out.println(classname);
		//logger.info("start processing each Class...");
		readFilesFromDir();
		//int subsetSize = Math.min(1000, files.size());
		//for(int i = 0; i <= files.size()/subsetSize; i++){
			//List<String> subsetFile = files.subList(i*subsetSize, Math.min(files.size(), (i+1)*subsetSize));
			processIOinClass(files);
			//logger.info("end processing each Class...");
			for(int i = 0; i < maxItNum; i++){
				logger.info("Propagate " + (i+1) + "th iteration");
				doPropagration();
				handleAfterPropagration();
			}
			printIOClass2File();
		//}
	}
	
	private static void printIOClass2File(){
		logger.info("start writing io classes into output file");
		
		File outfile = new File(outputFile);
	    if (outfile.exists()) {
	    	outfile.delete();     
	    }
	    
		int i = 0;
		String printStr = "";
		for(int classID : ioClasses){
			String classname = getKeyByValue(class2ID, classID);
			printStr += classname + "\n";
			if(i == 1000 ){
				//writeStr(printStr);
				write2File(outputFile, printStr);
				printStr = "";
				i = 0;
			}
			i++;
		}
		if(printStr != ""){
			//writeStr(printStr);
			write2File(outputFile, printStr);
		}
	}
	
	private static void writeStr(String str){
		try {
		    FileWriter fw = new FileWriter(outputFile);
		    PrintWriter pw = new PrintWriter(fw);
		    pw.write(str);
		    pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void write2File(String filename, String content){
		File fout = new File(filename);
		FileOutputStream fos = null;
		BufferedWriter bw = null;
		try {
			fos = new FileOutputStream(fout, true);
			bw = new BufferedWriter(new OutputStreamWriter(fos));
			bw.write(content);
			bw.flush();
			fos.close();
			bw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static int getIDFromClassesName(String classname){
		if(class2ID.containsKey(classname)){
			return class2ID.get(classname);
		} else {
			class2ID.put(classname, classID);
			classID++;
			return classID-1;
		}
	}
	
	private static void readFilesFromDir(){
		if(analysisPath != null && analysisPath != ""){
			File folder = new File(analysisPath);
			File[] listofFiles = folder.listFiles();
			for(File file : listofFiles){
			    if (file.isFile()) {
			        files.add(file.getName());
			    }
			}
		}
	}
	
	private static void processIOinClass(List<String> files){
		for(String file : files){
			logger.info("start processing " + file + " ...");
			InputStream instream = null;
			BufferedReader reader = null;
			String line = "";
			try {
				instream = new FileInputStream(analysisPath+"/"+file);
				reader = new BufferedReader(new InputStreamReader(instream));
				List<Integer> fields = new ArrayList<Integer>();
				boolean isIOClass = false;
				String className = file.replace(".txt", "");
				if(LoopUtils.match(className) || LoopUtils.matchAppIOClass(className)){
					ioClasses.add(getIDFromClassesName(className));
					isIOClass = true; //don't need to read the files line by line
				} else {
					while ((line = reader.readLine()) != null) {
						if(line.contains("field:")){
							String classname = line.split("field: ")[1].split(":")[0].replace("<", "");
							fields.add(getIDFromClassesName(classname));							
						} else if(line.contains("result:")){
							//result: org.apache.hadoop.fs.FSDataOutputStream Class is Data Related.
							ioClasses.add(getIDFromClassesName(className));
							isIOClass = true;
						} else{
							continue;
						}
					} 
				}
				if(!isIOClass){
					class2filedsMap.put(getIDFromClassesName(className), fields);
				}
			} catch (Exception e) {
				logger.severe("Exception: " + e.toString());
			} finally {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			logger.info("finish processing " + file + " ...");
			//logger.info("start extracting io classes ...");
		}
	}
	
	private static void doPropagration(){
		logger.info("start propagrating io classes ...");
		Iterator<Entry<Integer, List<Integer>>> it = class2filedsMap.entrySet().iterator();
		Entry<Integer,List<Integer>> entry = null;
		while(it.hasNext()){
			entry = it.next();
			int classID = entry.getKey();
			if(isIOClass(classID, 0))
				ioClasses.add(classID);
		}
		logger.info("finish propagrating io classes ...");
	}
	
	
	private static void handleAfterPropagration(){
		logger.info("start cleaning the class2filedMap ...");
		for(int ioclassID : ioClasses){
			if(class2filedsMap.containsKey(ioclassID)){
				class2filedsMap.remove(ioclassID);
			}
		}
		logger.info("finish cleaning the class2filedMap ...");
	}
	
	
	private static boolean isIOClass(int classID, int itnum){
		if(ioClasses.contains(classID)){ //|| checkIOClass(classID)){
			return true;
		} else {
			if(class2filedsMap.containsKey(classID)){
				for(int fieldID : class2filedsMap.get(classID)){
					if(ioClasses.contains(fieldID)){
						return true;
					}
				}
			}
		}
		return false;
	}
	
	private static boolean checkIOClass(int classID){
		String classname = getKeyByValue(class2ID, classID);
		if(LoopUtils.match(classname) || LoopUtils.matchAppIOClass(classname))
			return true;
		else
			return false;
	}
	
	public static <T, E> T getKeyByValue(Map<T, E> map, E value) {
	    for (Entry<T, E> entry : map.entrySet()) {
	        if (Objects.equals(value, entry.getValue())) {
	            return entry.getKey();
	        }
	    }
	    return null;
	}
	
    public static void handleArgs(String[] args)
    {
        int argIndex = 0;
        boolean hasPath = false;
        boolean hasOutput = false;
        while(argIndex < args.length)
        {
            String current = args[argIndex];
            if(current.compareTo("-h") == 0)
            {
                printUsage();
                System.exit(-1);
            }else if(current.compareTo("-analysisPath") == 0)
            {
                argIndex++;
                analysisPath = args[argIndex];
                hasPath = true;
            }
            else if(current.compareTo("-outputFile") == 0)
            {
                argIndex++;
                outputFile = args[argIndex];
                hasOutput = true;
            }
            else
            {
                System.out.println("current arg:" + current);
                System.out.println("Invalid configuration params, use -h for usage");
                System.exit(-1);
            }
            argIndex++;
        }
        if(!(hasPath && hasOutput)){
        	printUsage();
        	System.exit(-1);
        }
    }
    
    public static void printUsage()
    {
    	System.out.println("Valid options are:");
        System.out.println("java retrieveAllIOClasses -analysisPath analysisPath -outputFile outputFile");
    }
	
}
