package findAllJavaAppIOClass;

import java.util.ArrayList;
import java.util.List;

public class handleJavaCollections {
	
	public static boolean hasElements(String valType){
		if(valType.contains("java.util.Collection")
				|| valType.contains("java.util.Deque")
				|| valType.contains("java.util.Enumeration")
				|| valType.contains("java.util.Iterator")
				|| valType.contains("java.util.List")
				|| valType.contains("java.util.ListIterator")
				|| valType.contains("java.util.Map")
				|| valType.contains("java.util.Map.Entry")
				|| valType.contains("java.util.NavigableMap")
				|| valType.contains("java.util.NavigableSet")
				|| valType.contains("java.util.Queue")
				|| valType.contains("java.util.Set")
				|| valType.contains("java.util.SortedMap")
				|| valType.contains("java.util.SortedSet")
				|| valType.contains("java.util.AbstractCollection")
				|| valType.contains("java.util.AbstractList")
				|| valType.contains("java.util.AbstractMap")
				|| valType.contains("java.util.AbstractMap.SimpleEntry")
				|| valType.contains("java.util.AbstractMap.SimpleImmutableEntry")
				|| valType.contains("java.util.AbstractQueue")
				|| valType.contains("java.util.AbstractSequentialList")
				|| valType.contains("java.util.AbstractSet")
				|| valType.contains("java.util.ArrayDeque")
				|| valType.contains("java.util.ArrayList")
				|| valType.contains("java.util.Arrays")
				|| valType.contains("java.util.Collections")
				|| valType.contains("java.util.Dictionary")
				|| valType.contains("java.util.EnumMap")
				|| valType.contains("java.util.EnumSet")
				|| valType.contains("java.util.HashMap")
				|| valType.contains("java.util.HashSet")
				|| valType.contains("java.util.Hashtable")
				|| valType.contains("java.util.IdentityHashMap")
				|| valType.contains("java.util.LinkedHashMap")
				|| valType.contains("java.util.LinkedHashSet")
				|| valType.contains("java.util.LinkedList")
				|| valType.contains("java.util.PriorityQueue")
				|| valType.contains("java.util.Stack")
				|| valType.contains("java.util.TreeMap")
				|| valType.contains("java.util.TreeSet")
				|| valType.contains("java.util.Vector")
				|| valType.contains("java.util.WeakHashMap")
				|| valType.contains("[]")){ //array
			return true;
		}
		return false;
	}
	
	public List<String> getElementType(String valType){
		List<String> eleTypes = new ArrayList<String>();
		//valType.split("")
		if(valType.contains("[]")){
			
		}
		
		return eleTypes;
	}
}
