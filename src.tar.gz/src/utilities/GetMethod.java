package utilities;

public class GetMethod extends IOMethod{	
	GetMethod(String sig){
		signature=sig;
		type="get";
	}
}
