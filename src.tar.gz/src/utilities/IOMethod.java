package utilities;

public abstract class IOMethod{
	public String signature;
	public String type;
	
	public String toString(){
		return "Type: "+type+" Signature: "+signature;
	}
}
