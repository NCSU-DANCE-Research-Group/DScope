package utilities;

public class SetCheckMethod extends CheckMethod{
	public String data;
	
	SetCheckMethod(String sig, String d, String bottom, String top){
		super(sig,bottom,top);
		this.data=d;
		type="set_check";
	}
}