package utilities;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import soot.SootMethod;
import soot.Unit;
import soot.Value;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.InvokeExpr;
import soot.jimple.internal.JCaughtExceptionRef;
import soot.jimple.internal.JIdentityStmt;
import soot.jimple.internal.JIfStmt;
import soot.jimple.internal.JInvokeStmt;
import soot.jimple.internal.JVirtualInvokeExpr;
import soot.tagkit.IntegerConstantValueTag;
import soot.tagkit.Tag;
import soot.toolkits.exceptions.ThrowableSet;
import soot.toolkits.exceptions.UnitThrowAnalysis;

public class LoopUtils {
	static public String stmt_toString(Unit u) {
		List<Tag> tags = u.getTags();
		String s = "";

		for (Tag t : tags) {
			if (t instanceof LoopTag) {
				s += ((LoopTag) t).getInfo() + ": ";
			} else if (t instanceof IntegerConstantValueTag) {
				s += ((IntegerConstantValueTag) t).getIntValue() + ": ";
			}
		}
		return (s + u.toString() + "	Type: " + u.getClass().toString());
	}
	
	static int stmtTag(Unit u){
		List<Tag> tags = u.getTags();
		for (Tag t : tags) {
			if (t instanceof IntegerConstantValueTag) {
				return ((IntegerConstantValueTag) t).getIntValue();
			}
		}
		return -1;
	}

	static String stmt_Additional(JIfStmt s) {
		return "IfStmt TARGET: " + stmt_toString(s.getTarget());
	}

	static String stmt_Additional(JIdentityStmt s) {
		String str = "";
		str += "branches():" + s.branches();

		Value v = s.getRightOp();
		str += "Right：" + v.getType().toString();
		str += "Right：" + v.getClass().toString();

		if (v instanceof JCaughtExceptionRef) { // exception caught statement
			JCaughtExceptionRef caught = (JCaughtExceptionRef) v;
			str += "Right：" + caught.getType().toString();

			v = s.getLeftOp();
			str += "Left：" + v.getType().toString();
			str += "Left：" + v.getClass().toString();
		}

		return str;
	}

	static String stmt_Additional(JInvokeStmt s) {
		String str = "";

		InvokeExpr ie = s.getInvokeExpr();

		if (ie instanceof InstanceInvokeExpr) {
			InstanceInvokeExpr iie = (InstanceInvokeExpr) ie;
			Value v = iie.getBase();
			str += ("TYPE: " + v.getType().toString());

			if (iie instanceof JVirtualInvokeExpr) {
				SootMethod target = ((JVirtualInvokeExpr) iie).getMethod();
				if (target.getSignature().equals(
						"<java.lang.System: void exit(int)>")) {
					/* insert printing statements here */
				}
			}

			ThrowableSet throwExceptions = UnitThrowAnalysis.v().mightThrow(s);

			str += throwExceptions.toString();
		} else {
			str += "Expr TYPE:" + ie.getType().toString();
		}

		return str;
	}

	// static boolean isPrint(String methodname){
	// for(int i=0;i<print_functions.length;i++){
	// if(methodname.equals(print_functions[i])){
	// return true;
	// }
	// }
	//
	// return false;
	// }

	static public boolean isPrint(String classname) { // to filter targeted classes
		// if(map.containsKey(classname)){
		// return map.get(classname);
		// }

		for (String s : packages) {
			if (Pattern.matches(s, classname)) {
				// map.put(classname, true);
				return true;
			}
		}

		// map.put(classname, false);
		return false;
	}

	// static boolean isRequiredFunction(String methodname){
	static public boolean isSkippedFunction(String methodname) {
		for (int i = 0; i < functions.length; i++) {
			if (methodname.equalsIgnoreCase(functions[i])) {
				return true;
			}
		}
		return false;
	}

	static public String getClassFileName(String classname, String predix, String appendix){
		String c_name = classname.replaceAll(prefix, ""); // remove prefix
		return outputDir + predix + c_name + appendix;
	}
	
	static public String getFileName(String classname, String methodname, String predix,
			String appendix) {
		// String c_name=classname.substring(classname.lastIndexOf(".")+1);
		// String m_name=methodname.substring(methodname.indexOf(" ")+1);
		// m_name.replaceAll(prefix, "");

		String c_name = classname.replaceAll(prefix, ""); // remove prefix
		String m_name = methodname.substring(methodname.indexOf(" ") + 1); //start after return name
		m_name = m_name.replaceAll(prefix, ""); // remove prefix
		return outputDir + predix + c_name + "_" + m_name + appendix;
	}
	
	static public String getFileName2(String classname, String methodname, String predix,
			String appendix) {
		// String c_name=classname.substring(classname.lastIndexOf(".")+1);
		// String m_name=methodname.substring(methodname.indexOf(" ")+1);
		// m_name.replaceAll(prefix, "");

		String c_name = classname.replaceAll(prefix, ""); // remove prefix
		String m_name = methodname.substring(methodname.indexOf(" ") + 1); //start after return name
		m_name = m_name.replaceAll(prefix, ""); // remove prefix
		return outputDir + predix + c_name + "=" + m_name + appendix;
	}
	
	static public String getFileName(String classname, String methodname,
			String appendix) {
		// String c_name=classname.substring(classname.lastIndexOf(".")+1);
		// String m_name=methodname.substring(methodname.indexOf(" ")+1);
		// m_name.replaceAll(prefix, "");

		String c_name = classname.replaceAll(prefix, ""); // remove prefix
		String m_name = methodname.substring(methodname.indexOf(" ") + 1); //start after return name
		m_name = m_name.replaceAll(prefix, ""); // remove prefix
		return outputDir + c_name + "_" + m_name + appendix;
	}
	
	static public String getFileName2(String classname, String methodname,String appendix) {
		String c_name = classname.replaceAll(prefix, ""); // remove prefix
		String m_name = methodname.substring(methodname.indexOf(" ") + 1); //start after return name
		m_name = m_name.replaceAll(prefix, ""); // remove prefix
		String[] m_names = m_name.split(".");
		String m_nameShort = m_name;
		if(m_names.length > 0){
			m_nameShort = m_names[m_names.length-1]; //get the last one
		}
		String filePath = outputDir + c_name + "_" + m_nameShort + appendix;
		if(filePath.length() < Integer.MAX_VALUE){
			return filePath;
		} else {
			long millis = System.currentTimeMillis() % 1000;
			String filePathShort = filePath.substring(0, Integer.MAX_VALUE - appendix.length() - Long.SIZE);
			filePathShort += String.valueOf(millis) + prefix;
			return filePathShort;
		}
		//return filePath;
	}

	public static IOMethod match(String cname,String sig){  //to search the io.xml to see if the class and the method signature is include in io.xml
		for(int i = 0; i < cls.size(); i++){
			if(cls.get(i).name.equals(cname)){
				List<IOMethod> methods = cls.get(i).methods;
				for(int j = 0; j < methods.size(); j++){
					if(methods.get(j).signature.equals(sig)){
						return methods.get(j);
					}
				}
			}
		}
		return null;
	}
	
	/*This match might over-catch, this is because not all the java IO classes are used to represent the data*/
	public static boolean match(String cname){
		//Currently, we don't consider the application IO classes.
		//if((cname.startsWith("java.io.") || cname.startsWith("java.nio.") || cname.startsWith("javax.imageio.") || matchAppIOClass(cname))
		if((cname.startsWith("java.io.") || cname.startsWith("java.nio.") || matchAppIOClass(cname))
				&& !cname.contains("Exception")) //we only consider the java io methods, but exclude the io-related exceptions.
			return true;
		return false;
	}
	
	/*This matchApp might over-catch, this is because not all the app io classes are used to represent the data*/
	public static boolean matchAppIOClass(String classname) { // to filter targeted classes
//		for (String s : appIOClassPrefix) {
//			if(classname.startsWith(s)) {
//				return true;
//			}
//		}
		for(String s : appIOClassFullName){ //this has to be strictly matched
			if(classname.equals(s)){
				return true;
			}
		}
		return false;
	}
	
	public static boolean matchArg(String cname){
		for(int i = 0; i < cls.size();i++){
			if(cls.get(i).name.equals(cname)){
				return true;
			}
		}
		return false;
	}

	static String conf_name = "conf";
	static String outputDir;
	static String prefix;
	static ArrayList<String> packages = new ArrayList<String>();
	static ArrayList<String> appIOClassPrefix = new ArrayList<String>();
	static ArrayList<String> appIOClassFullName = new ArrayList<String>();
	static List<IOClass> cls;
	static {
		/*cls=ReadIOFunction.readXML();*/
		
		File filter = new File(conf_name);
		try {
			BufferedReader br = new BufferedReader(new FileReader(filter));
			String s = br.readLine();
			String substr = s.substring(s.indexOf("=") + 1);
//			if (s.startsWith("output")) { // dir
				outputDir = substr;
//			}
			s = br.readLine();
			if(s!=null){
			substr = s.substring(s.indexOf("=") + 1);
//			if (s.startsWith("prefix")) { // dir
				prefix = substr;
//			}
		    System.out.println("prefix:"+prefix);
			}
			
			while (s != null) {
				String str = s.substring(s.indexOf("=") + 1);
				if (s.startsWith("package")) {
					packages.add(str);
				} else if(s.startsWith("appIOClassPrefix")){
					appIOClassPrefix.add(str);
				} else if(s.startsWith("appIOClassFullName")){
					appIOClassFullName.add(str);
				}
				s = br.readLine();
			}
		} catch (FileNotFoundException e) {

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	//currently, we don't use the results from conf2
	// It results from retrieveAllIOClasses, which has a lot of FP
//	static String conf_name2 = "conf2";
//	static {
//		File filter = new File(conf_name2);
//		try {
//			BufferedReader br = new BufferedReader(new FileReader(filter));
//			String s = br.readLine();
//			while (s != null) {
//				appIOClassFullName.add(s);
//				s = br.readLine();
//			}
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//	}
	
	static ArrayList<String> appIPSIOClassFullName = new ArrayList<String>();
	static String conf_IPS = "conf.InputStream";
	static {
//		//add java ips classes
//		appIPSIOClassFullName.add("java.io.InputStream");
//		appIPSIOClassFullName.add("java.io.DataInputStream");
//		appIPSIOClassFullName.add("java.io.FilterInputStream");
//		appIPSIOClassFullName.add("java.io.BufferedInputStream");
//		appIPSIOClassFullName.add("java.io.LineNumberInputStream");
//		appIPSIOClassFullName.add("java.io.PipedInputStream");
//		appIPSIOClassFullName.add("java.io.SequenceInputStream");
//		appIPSIOClassFullName.add("java.io.ByteArrayInputStream");
//		appIPSIOClassFullName.add("java.io.FileInputStream");
//		appIPSIOClassFullName.add("java.io.ObjectInputStream");
//		appIPSIOClassFullName.add("java.io.PushbackInputStream");
//		appIPSIOClassFullName.add("java.io.StringBufferInputStream");
		//add app ips classes
		File filter = new File(conf_IPS);
		try {
			BufferedReader br = new BufferedReader(new FileReader(filter));
			String s = br.readLine();
			while (s != null) {
				appIPSIOClassFullName.add(s);
				s = br.readLine();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static boolean containAppIPSClass(String classname) { // to filter targeted classes
		for(String s : appIPSIOClassFullName){ //this has to be strictly matched
			if(classname.contains(s+":")){//using : to differentiate the class name not the arguments in a method
				return true;
			}
		}
		return false;
	}

	public static List<String> getAppIPSClass(){
		return appIPSIOClassFullName;
	}
	
	static String[] functions = {};
//	static String[] functions = { "scrub" }; //why peipei comment scrub????????

}
