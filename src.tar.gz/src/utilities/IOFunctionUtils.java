package utilities;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class IOFunctionUtils {
	static String conf_name = "ioFunction";
//	static String prefix;
//	static ArrayList<String> packages = new ArrayList<String>();
//	static ArrayList<String> appIOClassPrefix = new ArrayList<String>();
//	static ArrayList<String> appIOClassFullName = new ArrayList<String>();
//	static List<IOClass> cls;
	static Map<String, Map<String, List<String>>> class2FunMap = new HashMap<String, Map<String, List<String>>>();
	static {		
		InputStream instream = null;
		BufferedReader reader = null;
		String line = "";
		try {
			instream = new FileInputStream(conf_name);
			reader = new BufferedReader(new InputStreamReader(instream));
			String className = "";
			String funcName = "";
			
			while ((line = reader.readLine()) != null) {
				String[] lineSplit = line.split(":");
				className = lineSplit[0];
				funcName = lineSplit[1];
				String[] retSplit = lineSplit[2].split(",");
				if(retSplit.length > 0){
					ArrayList<String> returns = new ArrayList<String>(Arrays.asList(retSplit));
					if(class2FunMap.containsKey(className)){
						Map<String, List<String>> func2Rets = class2FunMap.get(className);
						func2Rets.put(funcName, returns);
						class2FunMap.put(className, func2Rets);
					} else {
						Map<String, List<String>> func2Rets = new HashMap<String, List<String>>();
						func2Rets.put(funcName, returns);
						class2FunMap.put(className, func2Rets);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
	
	public static Map<String, Map<String, List<String>>> retriveIOfunMap(){
		return class2FunMap;
	}
}
