package utilities;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class ReadIOFunction {
	static String file_name="/home/ting/DataLoopBugDetection/soot-soot-2.5.0/io.xml";
	
	static List<IOClass> readXML(){
		
		File xmlFile = new File(file_name);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();
			
			NodeList nList = doc.getElementsByTagName("class");
			ArrayList<IOClass> cls = new ArrayList<IOClass>(nList.getLength());
			
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;

					IOClass cl = new IOClass(eElement.getAttribute("name"), eElement.getAttribute("type"));
					cls.add(cl);
					//Testing: we expand the granularity to classes not methods
					/*
					NodeList methods = eElement.getElementsByTagName("method");
					for(int m = 0; m < methods.getLength(); m++){
						Element mElement = (Element) methods.item(m);
						
						String mType = mElement.getAttribute("type");
						String mSig = mElement.getElementsByTagName("signature").item(0).getTextContent();		
						
						if(mType.equals("set")){
							SetMethod mSet=new SetMethod(mSig,mElement.getElementsByTagName("data").item(0).getTextContent());
							cl.add(mSet);
						}else if(mType.equals("check")){
							CheckMethod mCheck=new CheckMethod(mSig,mElement.getElementsByTagName("bottom").item(0).getTextContent(),mElement.getElementsByTagName("top").item(0).getTextContent());
							cl.add(mCheck);	
						}else if(mType.equals("set_check")){
							SetCheckMethod mSetCheck= new SetCheckMethod(mSig,mElement.getElementsByTagName("data").item(0).getTextContent(),mElement.getElementsByTagName("bottom").item(0).getTextContent(),mElement.getElementsByTagName("top").item(0).getTextContent());
							cl.add(mSetCheck);	
						}else{
							GetMethod mGet = new GetMethod(mSig);
							cl.add(mGet);
						}
						
					}
					*/
				}
			}
			return cls;
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (SAXException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	
static void printXML(){
		
		File xmlFile = new File(file_name);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();

			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
			NodeList nList = doc.getElementsByTagName("class");

			System.out.println("----------------------------");

			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);

				System.out.println("\nClass :" + nNode.getNodeName());

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;

					System.out.println("class name : " + eElement.getAttribute("name"));
					System.out.println("class type : " + eElement.getAttribute("type"));
					
					NodeList methods=eElement.getElementsByTagName("method");
					
					for(int m=0;m<methods.getLength();m++){
						Element mElement = (Element) methods.item(m);
						String mType=mElement.getAttribute("type");
						System.out.println("method type: " + mType );						
						System.out.println("method signature: " + mElement.getElementsByTagName("signature").item(0).getTextContent());		
						
						if(mType.equals("set")){
							System.out.println("method data: " + mElement.getElementsByTagName("data").item(0).getTextContent());	
						}else if(mType.equals("check")){
							System.out.println("method range: bottom" + mElement.getElementsByTagName("bottom").item(0).getTextContent());	
							System.out.println("method range top: " + mElement.getElementsByTagName("top").item(0).getTextContent());	
						}else if(mType.equals("set_check")){
							System.out.println("method data: " + mElement.getElementsByTagName("data").item(0).getTextContent());	
							System.out.println("method range: bottom" + mElement.getElementsByTagName("bottom").item(0).getTextContent());	
							System.out.println("method range top: " + mElement.getElementsByTagName("top").item(0).getTextContent());	
						}else if(mType.equals("get_check")){
							System.out.println("method range: bottom" + mElement.getElementsByTagName("bottom").item(0).getTextContent());	
					//		System.out.println("method range top: " + mElement.getElementsByTagName("top").item(0).getTextContent());	
						}
						
					}
				}
			}
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (SAXException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args){
		ReadIOFunction.printXML();
	}
}
