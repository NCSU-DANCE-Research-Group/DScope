package utilities;

public class GetCheckMethod extends CheckMethod{
	String data;
	GetCheckMethod(String sig, String bottom){
		super(sig,bottom,null);
		type="get_check";
	}
}
