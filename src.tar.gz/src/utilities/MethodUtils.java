package utilities;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import datastruct.tree.ArrayMultiTreeNode;
import datastruct.tree.TreeNode;
import soot.Body;
import soot.G;
import soot.SootField;
import soot.SootMethod;
import soot.Unit;
import soot.UnitBox;
import soot.Value;
import soot.ValueBox;
import soot.baf.internal.BFieldPutInst;
import soot.baf.internal.BLoadInst;
import soot.baf.internal.BNewArrayInst;
import soot.baf.internal.BPushInst;
import soot.jimple.Stmt;
import soot.tagkit.IntegerConstantValueTag;
import soot.tagkit.Tag;
import soot.toolkits.graph.ExceptionalUnitGraph;
import soot.toolkits.graph.UnitGraph;
import soot.util.Chain;


public class MethodUtils {
	
	
	/*
	 * This is to get all the stmts in the current class.
	 * */
	public static Map<String, List<Stmt>> getClassAllStmts(Body body){
		Map<String, List<Stmt>> allClassStmts = new HashMap<String, List<Stmt>>();
		for(SootMethod method : body.getMethod().getDeclaringClass().getMethods()){
			List<Stmt> methodStmts = getMethodAllStmts(method.getActiveBody());
			allClassStmts.put(method.getSubSignature(), methodStmts);
		}
		return allClassStmts;
	}
	
	
	public static List<Stmt> getClassAllStmts2(Body body){
		List<Stmt> allClassStmts = new ArrayList<Stmt>();
		for(SootMethod method : body.getMethod().getDeclaringClass().getMethods()){
			List<Stmt> methodStmts = getMethodAllStmts(method.getActiveBody());
			allClassStmts.addAll(methodStmts);
		}
		return allClassStmts;
	}
	
	
	public static List<List<Stmt>> getClassIntilizerStmts(Body body, PrintStream out){
		List<List<Stmt>> allClassStmts = new ArrayList<List<Stmt>>();
		for(SootMethod method : body.getMethod().getDeclaringClass().getMethods()){
//			out.println(method.getSignature());
			if(method.getName().toString().contains("<init>")){
				List<Stmt> methodStmts = getMethodAllStmts2(method.getActiveBody(), out);
				out.println(method.getSignature() + " " + methodStmts.size());
				allClassStmts.add(methodStmts);
			}
		}
		return allClassStmts;
	}
	
	
	public static Map<String, List<Value>> getClassIntialzerFileds(Body body, PrintStream out){
		Map<String, List<Value>> classFieldMap = new HashMap<String, List<Value>>();
		for(SootMethod method : body.getMethod().getDeclaringClass().getMethods()){
			if(method.getName().toString().contains("<init>")){
//				out.println(method.getSignature());
				UnitGraph g = new ExceptionalUnitGraph(method.getActiveBody());
				Iterator<Unit> it = g.iterator();
				List<Unit> allUnits = new ArrayList<Unit>();
				while(it.hasNext()){
					Unit cell = it.next();
					allUnits.add(cell);
				}
				String fieldName = "";
				List<Value> fieldValues = new ArrayList<Value>();
				for(int i = allUnits.size()-1; i >= 0; i--){
					Unit cell = allUnits.get(i);
//					out.println("cell = " + cell + " " + cell.getClass().toString());
					if(cell instanceof BFieldPutInst){
						if(fieldName != "" && fieldValues.size()>0){
							classFieldMap.put(fieldName, fieldValues);
							fieldName = "";
							fieldValues = new ArrayList<Value>();
						}
						BFieldPutInst bfputins = (BFieldPutInst) cell;
						fieldName = bfputins.getField().getSignature();
					} else if(cell instanceof BLoadInst){
						BLoadInst bloadins = (BLoadInst) cell;
						for(ValueBox vb : bloadins.getUseAndDefBoxes()){
//							out.println(vb.getValue());
							fieldValues.add(vb.getValue());
						}
					} else if(cell instanceof BPushInst){
						BPushInst bpushins = (BPushInst) cell;
//						out.println(bpushins);
//						out.println(bpushins.getConstant());
						fieldValues.add(bpushins.getConstant());
					} else if(cell instanceof BNewArrayInst){
						//BNewArrayInst barrayins = (BNewArrayInst) cell;
						//it is only "newarray" string, there is no need to put this in the list
					}
				}
				if(fieldName != "" && fieldValues.size()>0){
					classFieldMap.put(fieldName, fieldValues);
				}
			}
		}
		return classFieldMap;
	}

	
	/*
	 * This is get all the statements of the method/function.
	 * Including all the loop statements and non-loop statements.
	 * */
	public static List<Stmt> getMethodAllStmts(Body body){
		Chain<Unit> units = body.getUnits();
		List<Stmt> statements = new ArrayList<Stmt>();
		for (Iterator<Unit> stmts = units.snapshotIterator();stmts.hasNext();) {
			Unit cell = stmts.next();
			if(cell instanceof Stmt){
				Stmt stmt = (Stmt)cell;
				statements.add(stmt);
			}
			// Remove all the definitions.
			/*for (Iterator boxes = stmt.getDefBoxes().iterator(); boxes.hasNext();) {
				ValueBox box = (ValueBox)boxes.next();
				Value value = box.getValue();
				if (value instanceof FieldRef) {
					FieldRef ref = (FieldRef)value;
					units.remove(stmt);
				}
			}*/
		}
		return statements;
	}
	
	public static List<Stmt> getMethodAllStmts2(Body body,PrintStream out){
		List<Stmt> statements = new ArrayList<Stmt>();
		UnitGraph g = new ExceptionalUnitGraph(body);
		Iterator<Unit> it = g.iterator();
		while(it.hasNext()){
			Unit cell = it.next();
			out.println(cell.toString()+ " " + cell.getClass().toString());
			if(cell instanceof Stmt){
				Stmt stmt = (Stmt)cell;
				statements.add(stmt);
			}
		}
		return statements;
	}
	
	
	public static String conf_name = "conf_srcPath";
	public static String srcpath = "";
	public static String getSrcPath() {
		File filter = new File(conf_name);
		try {
			BufferedReader br = new BufferedReader(new FileReader(filter));
			srcpath = br.readLine();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return srcpath;
	}
	
	public static String conf_name2 = "conf_bytePath";
	public static String bytepath = "";
	public static String getBytePath() {
		File filter = new File(conf_name2);
		try {
			BufferedReader br = new BufferedReader(new FileReader(filter));
			bytepath = br.readLine();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return bytepath;
	}
	
//	static Map<String, String> classSrcPath = new HashMap<String, String>();
//	
//	static {		
//		File filter = new File(conf_name);
//		try {
//			@SuppressWarnings("resource")
//			BufferedReader br = new BufferedReader(new FileReader(filter));
//			String s = br.readLine();
//			while (s != null) {
//				String[] splitStr = s.split(":");
//				String classname = splitStr[0];
//				String srcpath = splitStr[1];
//				if(!classSrcPath.containsKey(classname)){
//					classSrcPath.put(classname, srcpath);
//				}
//				s = br.readLine();
//			}
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//
//	}
	
//	static String conf_name2 = "conf_bytePath";
//	static Map<String, String> classBytePath = new HashMap<String, String>();
//	
//	static {		
//		File filter = new File(conf_name2);
//		try {
//			@SuppressWarnings("resource")
//			BufferedReader br = new BufferedReader(new FileReader(filter));
//			String s = br.readLine();
//			while (s != null) {
//				String[] splitStr = s.split(":");
//				String classname = splitStr[0];
//				String srcpath = splitStr[1];
//				if(!classBytePath.containsKey(classname)){
//					classBytePath.put(classname, srcpath);
//				}
//				s = br.readLine();
//			}
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
	
	
	
	/*read java source file, return the line in a string*/
	//It is not an efficient way to read the specific line, but that's the only way to do it.
	@SuppressWarnings("resource")
	public static String readJavaSrcFile(String srcpath, String classname, int linenum){
		//if(classSrcPath.containsKey(classname)){
		if(srcpath != ""){
			//String filePath = classSrcPath.get(classname);
			FileInputStream fs;
			String lineIwant = "";
			try {
				fs = new FileInputStream(srcpath);
				BufferedReader br = new BufferedReader(new InputStreamReader(fs));
				for(int i = 1; i < linenum; ++i)
					br.readLine();
				lineIwant = br.readLine();
				if(lineIwant.contains("=")){ //currently, we only focus on those new assigned variables, they are called (temporary) local referenced variables
					String[] splitStr = lineIwant.split("=");
					String[] splitStr2 = splitStr[0].split(" ");
					return splitStr2[splitStr2.length-1];
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e){
				e.printStackTrace();
			}
		}
		return null;
	}
	
	
	
	@Deprecated
	public static List<Stmt> getMethodStmts(Body body, int loopID, List<Integer> notwantedLoopIDs){
		if(notwantedLoopIDs == null || notwantedLoopIDs != null && notwantedLoopIDs.size() == 0)
			return getMethodAllStmts(body);
		List<Stmt> statements = new ArrayList<Stmt>();
		for(Stmt stmt: getMethodAllStmts(body)){
			boolean belong = false;
			boolean notbelong = false;
			for(Tag tag : stmt.getTags()){
				if(tag instanceof LoopTag){
					int id = ((LoopTag) tag).getLoopId();
					if(id == loopID)
						belong = true;
					else if(notwantedLoopIDs.contains(id)){
						notbelong = true;
					}
				}
			}
			if(!notbelong)//add the statements belong to loopID and the statements that don't belong to any loop 
				statements.add(stmt);
		}
		return statements;
	}
	
	@Deprecated
	public static Map<Integer, List<Integer>> getLoopTopology(Body body){
		G.v().out.println("----inside func getLoopTopology-----");
		Map<Integer, List<Integer>> looptopo = new HashMap<Integer, List<Integer>>();
		for(Stmt stmt: getMethodAllStmts(body)){
			G.v().out.println(stmt);
			for(Tag tag : stmt.getTags()){
				
				List<Integer> previousIDs = new ArrayList<Integer>();
				if(tag instanceof LoopTag){
					int id = ((LoopTag) tag).getLoopId();
					if(!looptopo.containsKey(id)){
						List<Integer> topo = new ArrayList<Integer>();
						looptopo.put(id, topo);
					}
					if(previousIDs.size() > 0){
						for(int previousID : previousIDs){
							if(!looptopo.containsKey(previousID)){
								List<Integer> topo = new ArrayList<Integer>();
								looptopo.put(previousID, topo);
							}
							List<Integer> innerIDs = looptopo.get(previousID);
							innerIDs.add(id);
							looptopo.put(previousID, innerIDs);
						}
					}
					previousIDs.add(id);
				}
			}
		}
		return looptopo;
	}

	
	/*get the inner loops for loop lg*/
	@Deprecated
	public static ArrayMultiTreeNode<Integer> getLoopTopology(LoopGraph lg){
		G.v().out.println("----inside func getLoopTopology-----");
		int loopID = lg.getLoopID();
		ArrayMultiTreeNode<Integer> root = new ArrayMultiTreeNode<>(loopID);
		for(Stmt stmt: lg.getLoopStmt()){
			ArrayMultiTreeNode<Integer> parent = root;
			boolean foundLoopID = false;
			int previousID = 1;
			List<Tag> allTags = stmt.getTags();
			for(int i = allTags.size()-1; i >= 0; i--){
				Tag tag = allTags.get(i); //the outer loop tag is inner
			//for(Tag tag : stmt.getTags()){
				if(tag instanceof LoopTag){
					int id = ((LoopTag) tag).getLoopId();
					boolean alreadyExist = false;
					if(id == loopID) {
						foundLoopID = true;
					} else if(id != 1 && foundLoopID == true){
						ArrayMultiTreeNode<Integer> child = new ArrayMultiTreeNode<>(id);					
						for (TreeNode<Integer> subroot : root) {
							if(subroot.data() == previousID){
								parent = (ArrayMultiTreeNode<Integer>) subroot; 
							} else if(subroot.data() == id){
								alreadyExist = true;
								break;
							}
						}
						if(alreadyExist == false){
							parent.add(child);
							parent = child;
						}
					}
					previousID = id;
				}
			}
		}
		return root;
	}
	
	@Deprecated
	public static List<Stmt> getMethodStmts(Body body, List<LoopGraph> wantedLoops, List<LoopGraph> notwantedLoops){
		if(notwantedLoops == null || notwantedLoops != null && notwantedLoops.size() == 0)
			return getMethodAllStmts(body);
		List<Stmt> statements = new ArrayList<Stmt>();
		List<Stmt> allMethodStmts = getMethodAllStmts(body);
		List<Integer> wantedLoopIDs = new ArrayList<Integer>();
		List<Integer> notwantedLoopIDs = new ArrayList<Integer>();
		for(LoopGraph lg : notwantedLoops){
			int notwantedID = lg.getLoopID();
			if(!notwantedLoopIDs.contains(notwantedID)){
				notwantedLoopIDs.add(notwantedID);
			}
		}
		for(LoopGraph lg: wantedLoops){
			int wantedLoopID = lg.getLoopID();
			if(!wantedLoopIDs.contains(wantedLoopID)){
				wantedLoopIDs.add(wantedLoopID);
			}
		}
		List<Stmt> notwantedStmts = new ArrayList<Stmt>();
		for(LoopGraph lg: notwantedLoops){
			for(Stmt stmt : lg.getLoopStmt()){
				boolean notwanted = false;
				for(Tag tag : stmt.getTags()){
					if(tag instanceof LoopTag){
						notwanted = true; //this stmt has a loop tag
					}
				}
				if(notwanted){
					notwantedStmts.add(stmt);
				}
			}
		}
		for(int index = 0; index < allMethodStmts.size(); index++){
		//for(Stmt stmt: allMethodStmts){
			Stmt stmt = allMethodStmts.get(index);
			boolean needtoDelete = false;
			for(Stmt notwantedStmt : notwantedStmts){
				if(notwantedStmt.toString().contains(stmt.toString())){
					needtoDelete = true;
					break;
				}
			}
			if(!needtoDelete){
				statements.add(stmt);
			}
			
		}
		return statements;
	}
}
