package utilities;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import soot.Value;
import soot.ValueBox;
import soot.jimple.CastExpr;
import soot.jimple.InvokeExpr;
import soot.jimple.Stmt;
import soot.jimple.internal.JAssignStmt;

public class SameInstanceVars {
	
	public static Map<Value, List<Value>> extractEqualConditions(List<Stmt> stmts, PrintStream out){
//		List<Stmt> stmts = path.getpathStmt();
		
		
		//1. Find the variables which are assigned exactly the same 
		Map<Value, List<Value>> sameVarMap = new HashMap<Value, List<Value>>(); 
		for(int i = 0; i < stmts.size(); i++){
			Stmt stmt = stmts.get(i);
			for(int j = 1; j < stmts.size(); j++){
				Stmt stmt2 = stmts.get(j);
				if(stmt instanceof JAssignStmt && stmt2 instanceof JAssignStmt){
					String stmtAssign = ((JAssignStmt)stmt).rightBox.getValue().toString();
					String stmt2Assign = ((JAssignStmt)stmt2).rightBox.getValue().toString();
					if(stmtAssign.equals(stmt2Assign)){//exactly the same
						Value lhs = ((JAssignStmt)stmt).leftBox.getValue();
						Value rhs = ((JAssignStmt)stmt2).leftBox.getValue();
						if(sameVarMap.containsKey(lhs)){
							List<Value> sameVars = sameVarMap.get(lhs);
							sameVars.add(rhs);
							sameVarMap.put(lhs, sameVars);
						} else {
							List<Value> sameVars = new ArrayList<Value>();
							sameVars.add(rhs);
							sameVarMap.put(lhs, sameVars);
						}
						if(sameVarMap.containsKey(rhs)){
							List<Value> sameVars = sameVarMap.get(rhs);
							sameVars.add(lhs);
							sameVarMap.put(rhs, sameVars);
						} else {
							List<Value> sameVars = new ArrayList<Value>();
							sameVars.add(lhs);
							sameVarMap.put(rhs, sameVars);
						}
					}
				}
			}
		}
			
			
		//2. Find those variables which are assigned with the similar invocation expression.
		// in the invocation expression, the everything is the same, and the arguments are the same variables with different names
//		Map<Value, List<Value>> varUseVars = new HashMap<Value, List<Value>>();
		for(int i = 0; i < stmts.size(); i++){
			Stmt stmt = stmts.get(i);
			for(int j = 1; j < stmts.size(); j++){
				Stmt stmt2 = stmts.get(j);
				if(stmt instanceof JAssignStmt && stmt2 instanceof JAssignStmt && stmt.containsInvokeExpr() && stmt2.containsInvokeExpr()){
					InvokeExpr expr1 = stmt.getInvokeExpr();
					InvokeExpr expr2 = stmt2.getInvokeExpr();
					if(expr1.getMethod().getSignature().equals(expr2.getMethod().getSignature())){
						List<Value> args1 = expr1.getArgs();
						List<Value> args2 = expr2.getArgs();
						boolean issame = true;
						for(int index = 0; index < args1.size(); index++){
							if(!args1.get(index).equals(args2.get(index))){ 
								if(!sameVarMap.containsKey(args1.get(index))){
									issame = false;
									break;
								} else {
									if(!sameVarMap.get(args1.get(index)).contains(args2.get(index))){
										issame = false;
										break;
									}
								}
							}
						}
						if(issame){
							Value lhs = ((JAssignStmt)stmt).leftBox.getValue();
							Value rhs = ((JAssignStmt)stmt2).leftBox.getValue();
							if(sameVarMap.containsKey(lhs)){
								List<Value> sameVars = sameVarMap.get(lhs);
								sameVars.add(rhs);
								sameVarMap.put(lhs, sameVars);
							} else {
								List<Value> sameVars = new ArrayList<Value>();
								sameVars.add(rhs);
								sameVarMap.put(lhs, sameVars);
							}
							if(sameVarMap.containsKey(rhs)){
								List<Value> sameVars = sameVarMap.get(rhs);
								sameVars.add(lhs);
								sameVarMap.put(rhs, sameVars);
							} else {
								List<Value> sameVars = new ArrayList<Value>();
								sameVars.add(lhs);
								sameVarMap.put(rhs, sameVars);
							}
						}
					}
				}
			}
		}
		
		
		
		
//		out.println("sameVarMap:");
//		Iterator<Entry<Value, List<Value>>> it = sameVarMap.entrySet().iterator();
//		Entry<Value, List<Value>> entry = null;
//		while(it.hasNext()){
//			entry = it.next();
//			out.print(entry.getKey().toString() + " : ");
//			for(Value same : entry.getValue()){
//				out.print(same.toString() + " ");
//			}
//			out.println();
//		}
				
		return sameVarMap;
	}
	
}
