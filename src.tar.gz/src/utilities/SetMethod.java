package utilities;

public class SetMethod extends IOMethod{
	public String data;
	
	SetMethod(String sig, String d){
		signature=sig;
		data=d;
		type="set";
	}
}
