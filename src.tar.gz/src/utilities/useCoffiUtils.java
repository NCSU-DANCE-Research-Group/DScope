package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import soot.G;
import soot.Scene;
import soot.coffi.ClassFile;
import soot.coffi.Code_attribute;
import soot.coffi.LocalVariableTable_attribute;
import soot.coffi.LocalVariableTypeTable_attribute;
import soot.coffi.cp_info;
import soot.coffi.method_info;

public class useCoffiUtils {
	private String className;
	private String classFilePath;
	private String methodName;
	private PrintStream out;
	
	public useCoffiUtils(String classname, String classFilePath, String methodname, PrintStream out){
		this.className = classname;
		this.classFilePath = classFilePath;
		this.methodName = methodname;
		this.out = out;
	}
	
	public Map<String, String> getLocalVariableTypeTable(){
		if(this.classFilePath == ""){
			return null;
		}
		File initialFile = new File(this.classFilePath);
        InputStream is = null;
        Map<String, String> var2TypeMap = new HashMap<String, String>();
        try {
			is = new FileInputStream(initialFile);
        } catch (FileNotFoundException e) {
			e.printStackTrace();
        }
        this.out.println("className = " + this.className);
		ClassFile coffiClass = new ClassFile(this.className);
        boolean success = coffiClass.loadClassFile(is);
        if (!success) {
				if (!Scene.v().allowsPhantomRefs())
					throw new RuntimeException("Could not load classfile: ");
				else {
					G.v().out.println("Warning: " + this.className + " is a phantom class!");
					return var2TypeMap;
				}
        }
        cp_info[] constantPool = coffiClass.constant_pool;
        for (int i = 0; i < coffiClass.methods_count; i++) {
			try{
//				out.println("methodName arg = " + methodName);
				method_info methodInfo = coffiClass.methods[i];
				
//				out.println("methodInfo = " + methodInfo.toName(constantPool));
//				out.println("methodInfo Prototype = " + methodInfo.prototypeWOaccess(constantPool));
//				String methodNameSimple = reduceMethodName(methodName);
//				out.println("methodNameSimple = " + methodNameSimple);
				if(//methodInfo.prototypeWOaccess(constantPool).equals(methodNameSimple) ||
						methodInfo.prototypeWOaccess(constantPool).equals(this.methodName)){
					this.out.println("methodInfo inside = " +methodInfo.toName(constantPool));
	  				Code_attribute ca = methodInfo.locate_code_attribute();
//	  				LocalVariableTable_attribute la = ca.findLocalVariableTable();
//	  				out.println("LocalVariableTable: " + la.toString());
	  				LocalVariableTypeTable_attribute lt = ca.findLocalVariableTypeTable();
//					out.println("LocalVariableTypeTable:New:");
//					out.println(lt.printTable(constantPool));
					var2TypeMap = lt.retriveTable(constantPool);
//					out.println("var2TypeMap = " + var2TypeMap);
//					return var2TypeMap;
				}
			}catch(Exception e){
				e.printStackTrace();
				continue;
			}
		}
//        out.println("var2TypeMap = " + var2TypeMap);
		return var2TypeMap;
	}
	
	
	private void printMap(Map<String, String> var2TypeMap){
		Iterator<Entry<String, String>> it = var2TypeMap.entrySet().iterator();
		Entry<String, String> entry = null;
		while(it.hasNext()){
			entry = it.next();
			this.out.println(entry.getKey() + ": " + entry.getValue());
		}
	}
	
	private String reduceMethodName(String methodName){
		//void getMoreSplits(org.apache.hadoop.mapreduce.JobContext,org.apache.hadoop.fs.Path[],long,long,long,java.util.List)
		String methodPrefix = methodName.split("\\(")[0];
		String[] methodSplit = methodName.split("\\(")[1].split("\\)")[0].split(",");
		String args = "";
		for(String arg : methodSplit){
			String[] argSplit = arg.split("\\.");
			if(argSplit.length == 1){
				args += arg+",";
			} else {
				if(argSplit[0].equals("java")){//currently we only consider java, maybe there are some other package, like sun. etc
					args += arg+",";
				} else {
					args += argSplit[argSplit.length-1]+",";
				}
			}
		}
		if(args!=""){
			args = args.substring(0, args.length()-1);
		}
		return methodPrefix+"("+args+")";
	}
}
