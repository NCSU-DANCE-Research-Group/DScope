package utilities;

import java.util.ArrayList;
import java.util.List;


public class IOClass {
	String name;
	String type;
	
	List<IOMethod> methods=new ArrayList<IOMethod>();
	
	public IOClass(String cname, String ctype){
		name=cname;
		type=ctype;
	}
	public void add(IOMethod method){
		methods.add(method);
	}
}
