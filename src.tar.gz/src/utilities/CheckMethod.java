package utilities;

public class CheckMethod extends IOMethod{
	String bottom;
	String top;
	
	CheckMethod(String sig, String bottom, String top){
		signature=sig;
		this.bottom=bottom;
		this.top=top;
		type="check";
	}
}