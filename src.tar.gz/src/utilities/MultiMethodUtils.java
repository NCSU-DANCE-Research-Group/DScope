package utilities;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import datastruct.tree.ArrayMultiTreeNode;
import datastruct.tree.TreeNode;
import soot.Body;
import soot.G;
import soot.Immediate;
import soot.Local;
import soot.SootMethod;
import soot.Unit;
import soot.UnitBox;
import soot.Value;
import soot.ValueBox;
import soot.jimple.Constant;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.InvokeExpr;
import soot.jimple.Ref;
import soot.jimple.Stmt;
import soot.jimple.internal.JAssignStmt;
import soot.jimple.internal.JIdentityStmt;
import soot.jimple.internal.JInvokeStmt;
import soot.tagkit.Tag;
import soot.util.Chain;


public class MultiMethodUtils {
	
	
	
	
	
	static List<Body> otherClassMethodBodies = new ArrayList<Body>();
	public static void setBodies(List<Body> otherBodies){
		for(Body otherbody : otherBodies){
			otherClassMethodBodies.add(otherbody);
		}
	}
	public static List<Body> getBodies(){
		return otherClassMethodBodies;
	}
	
	
	
	private static boolean containIPSstr(String methodStr, List<String> classStrs){
		for(String classStr : classStrs){
			if(methodStr.contains(classStr)){
				return true;
			}
		}
		return false;
	}
	
	
	public static Map<Value, List<Stmt>> getVarNStmts(Body body1, List<Stmt> pathStmts, List<String> classStrs){
		Map<Value, List<Stmt>> var2StmtsMapCur = getVarNStmtsPri(pathStmts, classStrs);
		for(Stmt stmt : pathStmts){
			if(stmt.containsInvokeExpr()){//invoke other app functions
				InvokeExpr ivE = stmt.getInvokeExpr();
				for(Body body2 : otherClassMethodBodies){
					if(ivE.getMethod().equals(body2.getMethod())){
						Map<Value, List<Stmt>> var2StmtsMapInv = getVarNStmtsPri(getMethodAllStmts(body2), classStrs);
						Map<Value, Value> paraMap = findEqualVars(body1, body2);//Key:body2 var, Value:body1 var
						Iterator<Entry<Value, Value>> paraIt = paraMap.entrySet().iterator();
						Entry<Value, Value> paraEntry = null;
						while(paraIt.hasNext()){
							paraEntry = paraIt.next();
							Value body2Var = paraEntry.getKey();
							Value body1Var = paraEntry.getValue();
							if(var2StmtsMapInv.containsKey(body2Var)){
								List<Stmt> var2StmtsInv = var2StmtsMapInv.get(body2Var);
								if(var2StmtsMapCur.containsKey(body1Var)){
									List<Stmt> var2StmtsCur = var2StmtsMapCur.get(body1Var);
									var2StmtsCur.addAll(var2StmtsInv);
									var2StmtsMapCur.put(body1Var, var2StmtsCur);
								} else {
									List<Stmt> var2StmtsCur = new ArrayList<Stmt>();
									var2StmtsCur.addAll(var2StmtsInv);
									var2StmtsMapCur.put(body1Var, var2StmtsCur);
								}
							}
						}
						break;
					}
				}
				
			}
		}
		return var2StmtsMapCur;
	}
	
	
	public static Map<Value, List<Stmt>> getVarNStmts(Body body1, List<String> classStrs){
		Map<Value, List<Stmt>> var2StmtsMapCur = getVarNStmtsPri(getMethodAllStmts(body1), classStrs);
		for(Stmt stmt : getMethodAllStmts(body1)){
			if(stmt.containsInvokeExpr()){//invoke other app functions
				InvokeExpr ivE = stmt.getInvokeExpr();
				for(Body body2 : otherClassMethodBodies){
					if(ivE.getMethod().equals(body2.getMethod())){
						Map<Value, List<Stmt>> var2StmtsMapInv = getVarNStmtsPri(getMethodAllStmts(body2), classStrs);
						Map<Value, Value> paraMap = findEqualVars(body1, body2);//Key:body2 var, Value:body1 var
						Iterator<Entry<Value, Value>> paraIt = paraMap.entrySet().iterator();
						Entry<Value, Value> paraEntry = null;
						while(paraIt.hasNext()){
							paraEntry = paraIt.next();
							Value body2Var = paraEntry.getKey();
							Value body1Var = paraEntry.getValue();
							if(var2StmtsMapInv.containsKey(body2Var)){
								List<Stmt> var2StmtsInv = var2StmtsMapInv.get(body2Var);
								if(var2StmtsMapCur.containsKey(body1Var)){
									List<Stmt> var2StmtsCur = var2StmtsMapCur.get(body1Var);
									var2StmtsCur.addAll(var2StmtsInv);
									var2StmtsMapCur.put(body1Var, var2StmtsCur);
								} else {
									List<Stmt> var2StmtsCur = new ArrayList<Stmt>();
									var2StmtsCur.addAll(var2StmtsInv);
									var2StmtsMapCur.put(body1Var, var2StmtsCur);
								}
							}
						}
						break;
					}
				}
				
			}
		}
		return var2StmtsMapCur;
	}
	
	
	
	private static Map<Value, List<Stmt>> getVarNStmtsPri(List<Stmt> methodAllStmts, List<String> classStrs){
		Map<Value, List<Stmt>> var2StmtsMap = new HashMap<Value, List<Stmt>>();
		for(Stmt stmt : methodAllStmts){
			if(stmt instanceof JAssignStmt && stmt.containsInvokeExpr()){
				InvokeExpr expression = stmt.getInvokeExpr();
//				out.println("getMethodRef = " + expression.getMethodRef().toString());
				if(containIPSstr(expression.getMethodRef().toString(), classStrs)){ 
					//out.println("expression.getType = "+expression.getType().toString());
					if(expression instanceof InstanceInvokeExpr){
						Value insVar = ((InstanceInvokeExpr) expression).getBase();
						if(var2StmtsMap.containsKey(insVar)){
							List<Stmt> varStmts = var2StmtsMap.get(insVar);
							varStmts.add(stmt);
							var2StmtsMap.put(insVar, varStmts);
						} else {
							List<Stmt> varStmts = new ArrayList<Stmt>();
							varStmts.add(stmt);
							var2StmtsMap.put(insVar, varStmts);
						}
					}
				}
			} else if(stmt instanceof JIdentityStmt){
				//to handle this case:
				//private String readLine(BufferedReader reader)
				//r1 := @parameter0: java.io.BufferedReader	Type: class soot.jimple.internal.JIdentityStmt
				JIdentityStmt jidStmt = (JIdentityStmt)stmt;
				Value insVar = jidStmt.leftBox.getValue();
				for(ValueBox vb : stmt.getUseBoxes()){
					Value value = vb.getValue();
					if(containIPSstr(value.toString(), classStrs)){
						if(!var2StmtsMap.containsKey(insVar)){
							List<Stmt> varStmts = new ArrayList<Stmt>();
							varStmts.add(stmt);
							var2StmtsMap.put(insVar, varStmts);
						}
						break;
					}
				}
			}
		}
		return var2StmtsMap;
	}
	
	
	/*
	 * This is get all the statements of the method/function.
	 * Including all the loop statements and non-loop statements.
	 * */
	public static List<Stmt> getMethodAllStmts(Body body){
		Chain<Unit> units = body.getUnits();
		List<Stmt> statements = new ArrayList<Stmt>();
		for (Iterator<Unit> stmts = units.snapshotIterator();stmts.hasNext();) {
			Unit cell = stmts.next();
			if(cell instanceof Stmt){
				Stmt stmt = (Stmt)cell;
				statements.add(stmt);
			}
		}
		return statements;
	}
	
	
	
	public static List<Stmt> mergeMethodStmts(Body body1, Body body2){
		List<Stmt> retStmts = new ArrayList<Stmt>();
		Chain<Unit> units1 = body1.getUnits();
		for (Iterator<Unit> stmts1 = units1.snapshotIterator();stmts1.hasNext();) {
			Unit unit1 = stmts1.next();
			if(unit1 instanceof Stmt){
				Stmt stmt1 = (Stmt)unit1;
				if(((Stmt)unit1).containsInvokeExpr()){
					InvokeExpr ivE = ((Stmt)unit1).getInvokeExpr();
					if(ivE.getMethod().equals(body2.getMethod())){
						retStmts.addAll(getMethodAllStmts(body2));
					}
				}
				retStmts.add(stmt1);
			}
		}
		return retStmts;
	}
	
	
	
	public static Map<Value, Value> findEqualVars(Body body1, Body body2){
		Map<Value, Value> paraMap = new HashMap<Value, Value>();//Key:body2 var, Value:body1 var
		Chain<Unit> units1 = body1.getUnits();
		for(Iterator<Unit> stmts1 = units1.snapshotIterator();stmts1.hasNext();) {
			Unit unit1 = stmts1.next();
			if(unit1 instanceof Stmt){
				Stmt stmt1 = (Stmt)unit1;
				if(stmt1.containsInvokeExpr()){
					InvokeExpr ivE = stmt1.getInvokeExpr();
					if(ivE.getMethod().equals(body2.getMethod())){
						paraMap = findEqualVars(stmt1, body1, body2);
					}
				}
			}
		}
		return paraMap;
	}
	
	
	private static Map<Value, Value> findEqualVars(Stmt ivStmt, Body body1, Body body2){
		Map<String, Value> body1Vars = getAllVarsFromMethod(body1);
		Map<String, Value> body2Vars = getAllVarsFromMethod(body2);
		Map<Value, Value> paraMap = new HashMap<Value, Value>();//Key:body2 var, Value:body1 var
		Iterator<Entry<String, Value>> it1 = body1Vars.entrySet().iterator();
		Entry<String, Value> entry1 = null;
		while(it1.hasNext()){
			entry1 = it1.next();
			String valName = entry1.getKey();
			if(body2Vars.containsKey(valName) && valName.contains("@this:")){
				paraMap.put(body2Vars.get(valName), entry1.getValue());//Key:body2 var, Value:body1 var
			}
		}
		if(ivStmt.containsInvokeExpr()){
			List<Value> args = ivStmt.getInvokeExpr().getArgs();
			Iterator<Entry<String, Value>> it2 = body2Vars.entrySet().iterator();
			Entry<String, Value> entry2 = null;
			while(it2.hasNext()){
				entry2 = it2.next();
				String valName = entry2.getKey();
				if(valName.contains("@parameter")){
					int index = valName.charAt(valName.length()-1) - '0';
					paraMap.put(entry2.getValue(), args.get(index));
				}
			}
		}
		return paraMap;
	}
	
	
	public static Map<String,Value> getAllVarsFromMethod(Body body){
		Map<String, Value> valMaps = new HashMap<String, Value>();
		for(Stmt stmt : getMethodAllStmts(body)){
			if(stmt instanceof JIdentityStmt){
				if(stmt.toString().contains("@this:")){
					valMaps.put(((JIdentityStmt) stmt).getRightOp().toString(), ((JIdentityStmt) stmt).getLeftOp());
  			  	} else if(stmt.toString().contains("@parameter")){
  			  		for(String splitStr : stmt.toString().split(":")){
  			  			if(splitStr.contains("@parameter")){
  			  				valMaps.put(splitStr, ((JIdentityStmt) stmt).getLeftOp());
  			  				break;
  			  			}
  			  		}
  			  	}
			}
		}
		return valMaps;
	}
	
	public static Set<Value> getAllVarFromBody(Body body){
		Set<Value> allVars = new HashSet<Value>();
		for(ValueBox vb : body.getUseAndDefBoxes()){
			Value val = vb.getValue();
			//System.out.println("val = " + val);
			if((val instanceof Ref || val instanceof Local) && !(val instanceof Constant)){
				allVars.add(val);
			}
		}
		return allVars;
	}
	
	
	public static String conf_name = "conf_tobeMergedMethod";
	public static String tobeMergedMethod = "";
	public static String getSrcPath() {
		File filter = new File(conf_name);
		try {
			BufferedReader br = new BufferedReader(new FileReader(filter));
			tobeMergedMethod = br.readLine();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return tobeMergedMethod;
	}
	
	public static String conf_name2 = "conf_mergingMethod";
	public static String mergingMethod = "";
	public static String getBytePath() {
		File filter = new File(conf_name2);
		try {
			BufferedReader br = new BufferedReader(new FileReader(filter));
			mergingMethod = br.readLine();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return mergingMethod;
	}
	
//	static Map<String, String> classSrcPath = new HashMap<String, String>();
//	
//	static {		
//		File filter = new File(conf_name);
//		try {
//			@SuppressWarnings("resource")
//			BufferedReader br = new BufferedReader(new FileReader(filter));
//			String s = br.readLine();
//			while (s != null) {
//				String[] splitStr = s.split(":");
//				String classname = splitStr[0];
//				String srcpath = splitStr[1];
//				if(!classSrcPath.containsKey(classname)){
//					classSrcPath.put(classname, srcpath);
//				}
//				s = br.readLine();
//			}
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//
//	}
	
//	static String conf_name2 = "conf_bytePath";
//	static Map<String, String> classBytePath = new HashMap<String, String>();
//	
//	static {		
//		File filter = new File(conf_name2);
//		try {
//			@SuppressWarnings("resource")
//			BufferedReader br = new BufferedReader(new FileReader(filter));
//			String s = br.readLine();
//			while (s != null) {
//				String[] splitStr = s.split(":");
//				String classname = splitStr[0];
//				String srcpath = splitStr[1];
//				if(!classBytePath.containsKey(classname)){
//					classBytePath.put(classname, srcpath);
//				}
//				s = br.readLine();
//			}
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
}
