import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.logging.Logger;


public class analyzeJNIsrcCode {
	
	static String analysisPath = "";
	static String outputFile="";
	static List<String> files = new ArrayList<String>();
	static Map<String, Map<String,Set<String>>> class2FunMap = new HashMap<String, Map<String,Set<String>>>();
	
	public static Logger logger = Logger.getLogger(analyzeJNIsrcCode.class.getName());

	
	public static void main(String[] args){
		args = new String[] {"-path", 
				             "/home/ting/openjdk7u/jdk/src/share/native/java", 
				             "-output", 
				             "/home/ting/DataLoopBugDetection/ResultIOClasses/JNI.summary"};
		handleArgs(args);
		processFuncinJNIclass();
		write2File();
		
	}
	
	
	public static void DFSallfiles(String path){
		if(path != null && path != ""){
			File folder = new File(path);
			File[] listofFiles = folder.listFiles();
			for(File file : listofFiles){
				if(file.isFile() 
						&& (file.getName().endsWith(".c") || file.getName().endsWith(".cpp"))){
					files.add(file.getAbsolutePath());
				} else if(file.isDirectory()){
					DFSallfiles(file.getAbsolutePath());
				}
			}
		}
	}
	
	public static void processFuncinJNIclass(){
		File outfile = new File(outputFile);
	    if (outfile.exists()) {
	    	outfile.delete();     
	    }
	    
		if(analysisPath != null && analysisPath != ""){
			DFSallfiles(analysisPath);
//			String outputStr="";
			logger.info("start reading each file...");
			for(String file : files){
				logger.info("start processing " + file + " ...");
//				if(!file.equals("/home/ting/openjdk7u/jdk/src/share/native/java/util/zip/Inflater.c")){
//					continue;
//				}
				InputStream instream = null;
				BufferedReader reader = null;
				String line = "";
				String preline="";
				try {
					instream = new FileInputStream(file);
					reader = new BufferedReader(new InputStreamReader(instream));
					boolean startAnalysis = false;
					boolean hasBody = false;
					String className = "";
					String funcName = "";
					Set<String> retVals = new HashSet<String>();
					while ((line = reader.readLine()) != null) {
//						logger.info(line);
						if(line.startsWith("Java_") 
								&& !preline.contains("void")){
							int delIndex = line.indexOf("(");
							String fullname = line.substring(0, delIndex);
							String fullname2 = fullname.replace("Java_", "");
							String[] JNInameSplit = fullname2.split("_");
//							String[] JNInameSplit = line.split("(")[0].replace("Java_","").split("_");
							className = "";
							funcName = "";
							for(int i = 0; i < JNInameSplit.length - 1; i++){
								className += JNInameSplit[i]+".";
							}
							className = className.substring(0, className.length() - 1);//delete last "."
							funcName = JNInameSplit[JNInameSplit.length-1];
							startAnalysis = true;
						} else if(startAnalysis == true 
								&& line.startsWith("{")){
							hasBody = true;
							retVals = new HashSet<String>();
						} else if(startAnalysis == true && hasBody == true
								&& line.startsWith("}")){
							if(!className.equals("") && !funcName.equals("") && retVals.size() > 0){
								if(class2FunMap.containsKey(className)){
									Map<String, Set<String>> fun2RetMap = class2FunMap.get(className);
									fun2RetMap.put(funcName, retVals);
									class2FunMap.put(className, fun2RetMap);
								} else {
									Map<String, Set<String>> fun2RetMap = new HashMap<String, Set<String>>();
									fun2RetMap.put(funcName, retVals);
									class2FunMap.put(className, fun2RetMap);
								}
							}
							startAnalysis = false;
							hasBody = false;
						} else if(startAnalysis == true && hasBody == true && line.contains("return ")){
							if(line.replaceAll("\\s+","").startsWith("return")){
								String retVal = line.replace("return ", "").replace(";","").replaceAll("\\s+","");
								if(retVal.contains("//")){
									int delIndex = retVal.indexOf("//");
									retVal = retVal.substring(0, delIndex);
								} else if(retVal.contains("/*")){
									int delIndex = retVal.indexOf("/*");
									retVal = retVal.substring(0, delIndex);
								}
								retVals.add(retVal);
							}
						}
						preline = line;
					}
				} catch (Exception e) {
					e.printStackTrace();
//					logger.severe("Exception: " + e.toString());
				} finally {
					try {
						reader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				
			}
			logger.info("finish reading all files");
			
		}
	}
	
	
	public static void write2File(){
		logger.info("start writing the output to file...");
		Iterator<Entry<String, Map<String,Set<String>>>> class2FunIt = class2FunMap.entrySet().iterator();
		Entry<String, Map<String,Set<String>>> class2FunEntry = null;
		String outputStr="";
		while(class2FunIt.hasNext()){
			class2FunEntry = class2FunIt.next();
			String className = class2FunEntry.getKey();
			Map<String, Set<String>> fun2RetMap = class2FunEntry.getValue();
			Iterator<Entry<String,Set<String>>> fun2RetIt = fun2RetMap.entrySet().iterator();
			Entry<String,Set<String>> fun2RetEntry = null;
			while(fun2RetIt.hasNext()){
				fun2RetEntry = fun2RetIt.next();
				String funcName = fun2RetEntry.getKey();
				Set<String> funcRets = fun2RetEntry.getValue();
				String outputRetStr="";
				for(String retVal : funcRets){
					if(!retVal.contains("->") && !retVal.contains("*") && !retVal.contains("(")){//not contain
						if(retVal.contains("NULL") 
								|| retVal.contains("JNI_TRUE") 
								|| retVal.contains("JNI_FALSE")
								|| retVal.contains("jlong_zero")
								|| retVal.contains("0")
								|| retVal.contains("1")){//only contain
							outputRetStr += retVal+",";
						}
					}
				}
				if(outputRetStr.equals("")){
					continue;
				}
				outputStr += className + ":" + funcName + ":" + outputRetStr;
				outputStr = outputStr.substring(0, outputStr.length() - 1);//delete last ,
				outputStr+="\n";
			}
//			logger.info("writing " + className +"'s methods into file...");
		}
		write2File(outputFile, outputStr);
		logger.info("finish writing the output to file...");
	}
	
	
	
	public static void write2File(String filename, String content){
		File fout = new File(filename);
		FileOutputStream fos = null;
		BufferedWriter bw = null;
		try {
			fos = new FileOutputStream(fout, true);
			bw = new BufferedWriter(new OutputStreamWriter(fos));
			bw.write(content);
			bw.flush();
			fos.close();
			bw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	public static void handleArgs(String []args)
    {
        int argIndex = 0;
        while(argIndex < args.length)
        {
            String current = args[argIndex];
            if(current.compareTo("-h") == 0)
            {
                printUsage();
                System.exit(-1);
            } else if(current.compareTo("-path") == 0){
            	argIndex++;
            	analysisPath = args[argIndex];
            } else if(current.compareTo("-output") == 0){
            	argIndex++;
            	outputFile = args[argIndex];
            }
            else
            {
                System.out.println("current arg:" + current);
                System.out.println("Invalid configuration params, use -h for usage");
                System.exit(-1);
            }
            argIndex++;
        }
    }
	
    public static void printUsage()
    {
        System.out.println("java analyzeJNIsrcCode [options] -path analysisPath -output outputFile");
        System.out.println("Valid options are:");
        System.out.println("-h print help and exit");
    }
}
