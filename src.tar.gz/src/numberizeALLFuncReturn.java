
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import java.util.regex.PatternSyntaxException;

import datastruct.DiGraphMatrix;
import datastruct.Graph;
//import datastruct.MultiTree;

public class numberizeALLFuncReturn {
	

	
	static String analysisPath = "";
	static String outputFile="";
	static String nativeFile = "";
	static List<String> files = new ArrayList<String>();
//	static List<classFuncRet> allClasses = new ArrayList<classFuncRet>();
//	static Map<String, List<String>> fun2RetMap = new HashMap<String, List<String>>();
//	static Map<String, InterfaceSubSuper> classinfoMap = new HashMap<String, InterfaceSubSuper>();
	static Map<String, Map<String,Set<String>>> class2FunMap = new HashMap<String, Map<String,Set<String>>>();
//	static List<String> interfaceReplaced = new ArrayList<String>();
//	static Map<String, Map<String, List<String>>> class2fun2RetMap = new HashMap<String, Map<String, List<String>>>();
	static Map<String,List<String>> funDependMap = new ConcurrentHashMap<String, List<String>>();
//	static Map<String,List<String>> funDependMapR = new HashMap<String, List<String>>();
//	static Map<String, Map<String, List<String>>> class2funDependMap = new HashMap<String, Map<String, List<String>>>();
 	static Map<String, String> superClassMap = new HashMap<String, String>();//<K,V>=<super,sub>
	static Map<String, String> superClassMapR = new HashMap<String, String>();//<K,V>=<sub,super>
	static Map<String, List<String>> interfaceMap = new HashMap<String, List<String>>();//<K,V>=<implements,interface>
	static Map<String, List<String>> interfaceMapR = new HashMap<String, List<String>>();//<K,V>=<interface,implements>
	static Set<String> allSuperClasses = new HashSet<String>();
	static Set<String> allInterfaces = new HashSet<String>();
	static Map<String, Set<String>> nativeFun2RetMap = new HashMap<String, Set<String>>(); 
	public static Logger logger = Logger.getLogger(numberizeALLFuncReturn.class.getName());
	
	public static void main(String[] args){
		args = new String[] {"-path", 
				             "/home/ting/DataLoopBugDetection/ResultIOClasses/openjdkReturn", 
				             "-output", 
				             "/home/ting/DataLoopBugDetection/ResultIOClasses/openjdkReturn.summary",
				             "-native",
				             "/home/ting/DataLoopBugDetection/ResultIOClasses/JNI.summary"};
		handleArgs(args);
		readNativeFunc();
		processRetinClassFuncs();
		
	}
	
	
	public static void processRetinClassFuncs(){
		File outfile = new File(outputFile);
	    if (outfile.exists()) {
	    	outfile.delete();     
	    }
	    
		if(analysisPath != null && analysisPath != ""){
			File folder = new File(analysisPath);
			File[] listofFiles = folder.listFiles();
			for(File file : listofFiles){
			    if (file.isFile()) {
			        files.add(file.getName());
			    }
			}
//			String outputStr="";
			logger.info("start reading each file...");
			for(String file : files){
//				logger.info("start processing " + file + " ...");
				InputStream instream = null;
				BufferedReader reader = null;
				String line = "";
				try {
					instream = new FileInputStream(analysisPath+"/"+file);
					reader = new BufferedReader(new InputStreamReader(instream));
					Set<String> returnVals = new HashSet<String>();
					Set<String> natives = new HashSet<String>();
//					boolean canPrint=true;
					String funcFullname = file.replace(".txt","");
					String klassName  = funcFullname.split("_")[0];
//					InterfaceSubSuper klassInfo = null;
//					if(classinfoMap.containsKey(klassName)){
//						klassInfo = classinfoMap.get(klassName);
//					} else {
//						klassInfo = new InterfaceSubSuper();
//					}
					while ((line = reader.readLine()) != null) {
						if(line.contains("return=<")){
							String[] returnValSplits = line.replace("return=<","").replace(")>",")").split(": ");
							String returnVal = returnValSplits[0]+"_"+returnValSplits[1].split(" ")[1]; //del the return type
							String nativeName = returnVal.substring(0, returnVal.indexOf("("));//native func is without arguments
							if(natives.contains(nativeName) && nativeFun2RetMap.containsKey(nativeName)){
								Set<String> nativeRets = nativeFun2RetMap.get(nativeName);
								returnVals.addAll(nativeRets);
							} else {
								returnVals.add(returnVal);
//								canPrint=false;
								if(funDependMap.containsKey(funcFullname)){
									List<String> dependedFunList = funDependMap.get(funcFullname);
									dependedFunList.add(returnVal);
									funDependMap.put(funcFullname, dependedFunList);
								} else {
									List<String> dependedFunList = new ArrayList<String>();
									dependedFunList.add(returnVal);
									funDependMap.put(funcFullname, dependedFunList);
								}
							}
						} else if(line.contains("return=")){
							returnVals.add(line.replace("return=",""));
						}
						if(line.contains("natives=")){
							String nativeFunc = line.replace("natives=","");
//							for(String nativeFunc : natives){//add classname
							natives.add(klassName+"_"+nativeFunc);
//							}
						}
						if(line.contains("isAbstract=true")){
							allSuperClasses.add(klassName);
						}
						if(line.contains("isInterface=true")){
							allInterfaces.add(klassName);
						}
						if(line.contains("extends=")){
							String superClass = line.split("extends=")[1];
							if(!superClass.equals("java.lang.Object")){ //we do not consider java.lang.Object, cause its the root of every class.
								                                        //every class has java.lang.Object as the super class.
								superClassMap.put(superClass, klassName);
								superClassMapR.put(klassName, superClass);
							}
//							klassInfo.superClassName = superClass;
						}
						if(line.contains("implements=")){
							String[] allInterfaceSplit = line.split("implements=")[1].split(",");
							List<String> allimplements = new ArrayList<String>();
							for(int i = 0; i < allInterfaceSplit.length; i++){
								String interfaceKlass = allInterfaceSplit[i];
								allInterfaces.add(interfaceKlass);
								allimplements.add(interfaceKlass);
								if(interfaceMapR.containsKey(interfaceKlass)){
									List<String> allimplementations = interfaceMapR.get(interfaceKlass);
									allimplementations.add(klassName);
									interfaceMapR.put(interfaceKlass, allimplementations);
								} else {
									List<String> allimplementations = new ArrayList<String>();
									allimplementations.add(klassName);
									interfaceMapR.put(interfaceKlass, allimplementations);
								}
								
							}
							interfaceMap.put(klassName, allimplements);
						}
					}
					if(returnVals.size() > 0){
						Map<String, List<String>> fun2RetMap = new HashMap<String, List<String>>();
//						fun2RetMap.put(funcFullname, returnVals);
						String[] funcFullSplit = funcFullname.split("_");
						String className = funcFullSplit[0];
						String funcName = funcFullSplit[1];
//						fun2RetMap.put(funcName, returnVals);
//						Map<String, List<String>> func2RetMap = new HashMap<String, List<String>>();
//						func2RetMap.put(funcName, returnVals);
//						if(class2fun2RetMap.containsKey(className)){
//							
//						}
						if(class2FunMap.containsKey(className)){
							Map<String,Set<String>> functions = class2FunMap.get(className);
							functions.put(funcName, returnVals);
							class2FunMap.put(className, functions);
						} else {
							Map<String,Set<String>> functions = new HashMap<String,Set<String>>();
							functions.put(funcName, returnVals);
							class2FunMap.put(className, functions);
						}
					}
//					if(canPrint){
//						String[] splitfile = file.replace(".txt","").split("_");
//						String classname = splitfile[0];
//						String funcname = splitfile[1];
//						outputStr += classname + ":" + funcname + ":";
//						for(String retVal : returnVals){
//							outputStr += retVal+",";
//						}
//						outputStr+="\n";
//					}
				} catch (Exception e) {
					logger.severe("Exception: " + e.toString());
					e.printStackTrace();
				} finally {
					try {
						reader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				
//				logger.info("finish processing " + file + " ...");
			}
			logger.info("finish reading all files");
			
			
			logger.info("start filling interfaces...");
			fillInterfaces();
			logger.info("finish filling interfaces...");
			
			//until all the functions are inheritated from superclass to subclass, from implemented class to interface class
			for(int i = 0; i < 20; i++){
				logger.info("start inheritating, iteration " + i);
				inheritanceIteration();
			}
			
			
			//until all the functions' return is a number not depend on other function's return
			for(int i = 0; i < 20; i++){
				logger.info("start numberizing the return values, iteration " + i);
				numberizeIteration();
			}
			
			logger.info("start writing the output to file...");
			write2File();
			logger.info("finish writing the output to file...");
			
		}
	}
	
	
	
	public static void readNativeFunc(){
		logger.info("starting reading native input file...");
		InputStream instream = null;
		BufferedReader reader = null;
		String line = "";
		try {
			instream = new FileInputStream(nativeFile);
			reader = new BufferedReader(new InputStreamReader(instream));
			String className = "";
			String funcName = "";
			
			while ((line = reader.readLine()) != null) {
				String[] lineSplit = line.split(":");
				className = lineSplit[0];
				funcName = lineSplit[1];
				String[] retSplit = lineSplit[2].split(",");
				Set<String> retVals = new HashSet<String>();
				for(String ret : retSplit){
					if(ret.equals("NULL")){
						retVals.add("null");
					} else if(ret.equals("JNI_TRUE")){
						retVals.add("true");
					} else if(ret.equals("JNI_FALSE")){
						retVals.add("false");
					} else if(ret.equals("jlong_zero")){
						retVals.add("0L");
					} else{
						retVals.add(ret);
					}
				}
				if(retVals.size()>0){
					nativeFun2RetMap.put(className+"_"+funcName, retVals);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
//			logger.severe("Exception: " + e.toString());
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		logger.info("finish reading native input file...");
		
	}
	
	
	//if there is no interface class because the interface only contains abstract classes. 
	//then there is no record of this interface class from Soot.
	//add all the methods from the implementation classes into the interface classes.
	//even though there will be over-fitting, but we just need to include all methods, doesn't matter include more methods.
	//those more methods will be filtered out when do indexing in TP pattern1.
	public static void fillInterfaces(){
		for(String interfaceClass : allInterfaces){
			if(interfaceClass.startsWith("java.lang"))
				continue;
			if(!class2FunMap.containsKey(interfaceClass)){
				if(interfaceMapR.containsKey(interfaceClass)){
					List<String> implementClasses = interfaceMapR.get(interfaceClass);
					for(String implementClass : implementClasses){
						if(class2FunMap.containsKey(implementClass)){
							Map<String,Set<String>> interfaceClassMethods = new HashMap<String, Set<String>>();
							if(class2FunMap.containsKey(interfaceClass)){
								interfaceClassMethods = class2FunMap.get(interfaceClass);
							}
							Map<String,Set<String>> implementClassMethods = class2FunMap.get(implementClass);
							Iterator<Entry<String, Set<String>>> implementClassIt = implementClassMethods.entrySet().iterator();
							Entry<String, Set<String>> implementClassEntry = null;
							while(implementClassIt.hasNext()){
								implementClassEntry = implementClassIt.next();
								String implementMethodName = implementClassEntry.getKey();
								Set<String> implementMethodRets = implementClassEntry.getValue();
								if(!interfaceClassMethods.containsKey(implementMethodName)){
									Set<String> interfaceMethodRets = new HashSet<String>();
									interfaceMethodRets.addAll(implementMethodRets);
									interfaceClassMethods.put(implementMethodName, interfaceMethodRets);
								} else {
									Set<String> interfaceMethodRets = interfaceClassMethods.get(implementMethodName);
									interfaceMethodRets.addAll(implementMethodRets);
									interfaceClassMethods.put(implementMethodName, interfaceMethodRets);
								}
							}
							class2FunMap.put(interfaceClass, interfaceClassMethods);
						}
					}
				}
			}
		}
	}
	
	public static void inheritanceIteration(){
		//1. all methods in superclass is inheritated into subclass, unless override, thus, need to add methods to subclasses
		Iterator<Entry<String, String>> superClassIt = superClassMap.entrySet().iterator();
		Entry<String, String> superClassEntry = null;
		while(superClassIt.hasNext()){
			superClassEntry = superClassIt.next();
			String superClass = superClassEntry.getKey();
			String subClass = superClassEntry.getValue();
			if(class2FunMap.containsKey(superClass) && class2FunMap.containsKey(subClass)){
				Map<String,Set<String>> superClassMethods = class2FunMap.get(superClass);
				Map<String,Set<String>> subClassMethods = class2FunMap.get(subClass);
				Iterator<Entry<String, Set<String>>> superMethodIt = superClassMethods.entrySet().iterator();
				Entry<String, Set<String>> superMethodEntry = null;
				while(superMethodIt.hasNext()){
					superMethodEntry = superMethodIt.next();
					String superMethodName = superMethodEntry.getKey();
					Set<String> superMethodRets = superMethodEntry.getValue();
					if(!subClassMethods.containsKey(superMethodName)){
						subClassMethods.put(superMethodName, superMethodRets);
					}
				}
				class2FunMap.put(subClass,subClassMethods);
			}
			
		}
		//2. all methods in interface should include all the implemented methods, there might be multiple implementation. Currently, we inlcude ALL.
		Iterator<Entry<String, List<String>>> interfaceIt = interfaceMap.entrySet().iterator();
		Entry<String, List<String>> interfaceEntry = null;
		while(interfaceIt.hasNext()){
			interfaceEntry = interfaceIt.next();
			String interfaceClass = interfaceEntry.getKey();
			List<String> implementClasses = interfaceEntry.getValue();
			for(String implementClass : implementClasses){
				if(class2FunMap.containsKey(interfaceClass) && class2FunMap.containsKey(implementClass)){
					Map<String,Set<String>> interfaceClassMethods = class2FunMap.get(interfaceClass);
					Map<String,Set<String>> implementClassMethods = class2FunMap.get(implementClass);
					Iterator<Entry<String, Set<String>>> implementClassIt = implementClassMethods.entrySet().iterator();
					Entry<String, Set<String>> implementClassEntry = null;
					while(implementClassIt.hasNext()){
						implementClassEntry = implementClassIt.next();
						String implementMethodName = implementClassEntry.getKey();
						Set<String> implementMethodRets = implementClassEntry.getValue();
						if(interfaceClassMethods.containsKey(implementMethodName)){
							Set<String> interfaceMethodRets = interfaceClassMethods.get(implementMethodName);
							interfaceMethodRets.addAll(implementMethodRets);
							interfaceClassMethods.put(implementMethodName, interfaceMethodRets);
						}
					}
				}
			}
		}
		//if an interface extends another interface, then the first interface should contain all methods in the second interface
	}
	
	public static void numberizeIteration(){		
		Iterator<Entry<String,List<String>>> funDependIt = funDependMap.entrySet().iterator();
		Entry<String,List<String>> funDependEntry = null;
		List<String> removeDepFuncs = new ArrayList<String>();
		while(funDependIt.hasNext()){
			funDependEntry = funDependIt.next();
			String funcFullName = funDependEntry.getKey();
//			System.out.println(funcFullName);
			String[] funcFullSplit = funcFullName.split("_");
			String funcClassName = funcFullSplit[0];
			String funcName = funcFullSplit[1];
			List<String> dependFuncs = funDependEntry.getValue();
			List<String> removeDepends = new ArrayList<String>();
			for(String func: dependFuncs){
				if(!funDependMap.containsKey(func)){//foo depends on bar, bar doesn't depend on baz
					String[] funcSplit = func.split("_");
					String dependClassName = funcSplit[0];
					String dependfuncName = funcSplit[1];
					if(class2FunMap.containsKey(dependClassName) && class2FunMap.containsKey(funcClassName)){
						Map<String,Set<String>> dependFunc2RetMap = class2FunMap.get(dependClassName);
						Map<String,Set<String>> func2RetMap = class2FunMap.get(funcClassName);
						if(dependFunc2RetMap.containsKey(dependfuncName) && func2RetMap.containsKey(funcName)){
							Set<String> numRets = dependFunc2RetMap.get(dependfuncName);
							Set<String> needReplace = func2RetMap.get(funcName);
//							List<String> replaced = new ArrayList<String>();
//							int replaceIndex = needReplace.indexOf(func);//full name: class_func
//							needReplace.remove(replaceIndex);
//							for(String ret : needReplace){
//								
//								if(!ret.equals(func)){
//									replaced.add(ret);
//								} else {
//									for(String ret2 : numRets){
//										replaced.add(ret2);
//									}
//								}
//							}
							if(needReplace.contains(func)){
								needReplace.remove(func);
							}
//							int deleteIndex = -1;
//							for(int i = 0; i < needReplace.size(); i++){
//								if(needReplace.get(i).equals(func)){
//									deleteIndex = i;
//								}
//							}
//							if(deleteIndex != -1){
//								needReplace.remove(deleteIndex);
//							}
//							for(String ret2 : numRets){
//								needReplace.add(ret2);
//							}
							needReplace.addAll(numRets);
							func2RetMap.put(funcName, needReplace);
							class2FunMap.put(funcClassName, func2RetMap);
							removeDepends.add(func);
						}

					}
				}
			}
			dependFuncs.removeAll(removeDepends);
			if(dependFuncs == null || dependFuncs.size() == 0){
				removeDepFuncs.add(funcName);
				//funDependIt.remove();
			} else {
				funDependMap.put(funcFullName, dependFuncs);
			}
		}
		for(String func : removeDepFuncs){
			funDependMap.remove(func);
		}
	}
	
	
	
	
	public static void write2File(){
		Iterator<Entry<String, Map<String,Set<String>>>> class2FunIt = class2FunMap.entrySet().iterator();
		Entry<String, Map<String,Set<String>>> class2FunEntry = null;
		while(class2FunIt.hasNext()){
			String outputStr="";
			class2FunEntry = class2FunIt.next();
			String className = class2FunEntry.getKey();
			Map<String, Set<String>> fun2RetMap = class2FunEntry.getValue();
			Iterator<Entry<String,Set<String>>> fun2RetIt = fun2RetMap.entrySet().iterator();
			Entry<String,Set<String>> fun2RetEntry = null;
			while(fun2RetIt.hasNext()){
				fun2RetEntry = fun2RetIt.next();
				String funcName = fun2RetEntry.getKey();
				Set<String> funcRets = fun2RetEntry.getValue();
				String outputRetStr="";
				for(String retVal : funcRets){
					if(!retVal.contains("implements=") && !retVal.contains("extends=") &&
							!retVal.contains("isAbstract=true") && !retVal.contains("isInterface=true") &&
//							!retVal.contains("_"))
							!(retVal.contains("_")&&retVal.contains("(")))
						outputRetStr += retVal+",";
				}
				if(outputRetStr.equals("")){
					continue;
				}
				outputStr += className + ":" + funcName + ":" + outputRetStr;
				outputStr = outputStr.substring(0, outputStr.length() - 1);//delete last ,
				outputStr+="\n";
			}
			logger.info("writing " + className +"'s methods into file...");
			write2File(outputFile, outputStr);
		}

		//write2File(outputFile, outputStr);
	}
	
	
	public static void write2File(String filename, String content){
		File fout = new File(filename);
		FileOutputStream fos = null;
		BufferedWriter bw = null;
		try {
			fos = new FileOutputStream(fout, true);
			bw = new BufferedWriter(new OutputStreamWriter(fos));
			bw.write(content);
			bw.flush();
			fos.close();
			bw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void handleArgs(String []args)
    {
        int argIndex = 0;
        while(argIndex < args.length)
        {
            String current = args[argIndex];
            if(current.compareTo("-h") == 0)
            {
                printUsage();
                System.exit(-1);
            } else if(current.compareTo("-path") == 0){
            	argIndex++;
            	analysisPath = args[argIndex];
            } else if(current.compareTo("-output") == 0){
            	argIndex++;
            	outputFile = args[argIndex];
            } else if(current.compareTo("-native") == 0){
            	argIndex++;
            	nativeFile = args[argIndex];
            } else {
                System.out.println("current arg:" + current);
                System.out.println("Invalid configuration params, use -h for usage");
                System.exit(-1);
            }
            argIndex++;
        }
    }
	
    public static void printUsage()
    {
        System.out.println("java numberizeALLFuncReturn [options] -path analysisPath -output outputFile");
        System.out.println("Valid options are:");
        System.out.println("-h print help and exit");
    }
    
}

//class InterfaceSubSuper{
//	public String interfaceName ="";
//	public Set<String> implementations = new HashSet<String>();
//	public String superClassName = "";
//	public Set<String> subClasses = new HashSet<String>();
//	public InterfaceSubSuper(){
//		
//	}
//}

