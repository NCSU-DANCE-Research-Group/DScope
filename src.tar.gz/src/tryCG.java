
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import soot.Body;
import soot.MethodOrMethodContext;
import soot.PackManager;
import soot.Scene;
import soot.SceneTransformer;
import soot.SootClass;
import soot.SootMethod;
import soot.Transform;
import soot.Type;
import soot.Unit;
import soot.UnitBox;
import soot.Value;
import soot.ValueBox;
import soot.jimple.InstanceInvokeExpr;
import soot.jimple.InvokeExpr;
import soot.jimple.Stmt;
import soot.jimple.internal.JAssignStmt;
import soot.jimple.internal.JInvokeStmt;
import soot.jimple.spark.SparkTransformer;
import soot.jimple.toolkits.callgraph.CHATransformer;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.ContextSensitiveCallGraph;
import soot.jimple.toolkits.callgraph.ContextSensitiveEdge;
import soot.jimple.toolkits.callgraph.Edge;
import soot.jimple.toolkits.callgraph.ReachableMethods;
import soot.jimple.toolkits.callgraph.Sources;
import soot.jimple.toolkits.callgraph.Targets;
import soot.jimple.toolkits.callgraph.ObjSensContextManager;
import soot.options.Options;
import soot.util.Chain;
import soot.util.queue.QueueReader;
import utilities.MethodUtils;


public class tryCG { 
	public static void main(final String[] args) {
		
		PackManager.v().getPack("wjtp").add(new Transform("wjtp.myTransform", new SceneTransformer() {
			protected void internalTransform(String phaseName, Map options) {
				  //CHATransformer.v().transform(); //cha
				  setSparkAnalysis();               //spark
				  //setSparkAnalysisPTA(); //it can cause "OutOfMemoryError: GC overhead limit exceeded"
				  Scene.v().loadNecessaryClasses();
				  //Scene.v().setEntryPoints(getAllMethods(args));
				  
		          CallGraph cg = Scene.v().getCallGraph();
//		          ContextSensitiveCallGraph cscg = Scene.v().getContextSensitiveCallGraph();
		          
		          List<SootMethod> methods = getAllMethods(args);
		          for(SootMethod entryPoint : methods){
		        	  System.out.println("entryPoint: " + entryPoint);
		        	  
		          }
		          //List<SootMethod> methods2 = Scene.v().getEntryPoints();
		          //for(SootMethod entryPoint : methods2){
		          //System.out.println("entryPoint2: " + entryPoint);
		          //}

//		          String appPrefix = getPrex(args);
		          String appPrefix = "org.apache";
		          boolean notCarePrefix = false; //true mean not care, false means care.
		          
		          System.out.println("------------add EventHandler start------------");
		          String klassName = args[args.length-1];
		          SootClass klass = Scene.v().getSootClass(klassName);
		          for(SootClass intfClass : klass.getInterfaces()){
		        	  if(intfClass.getName().contains("EventHandler")){
		        		  for(SootMethod m : methods){
		        			  if(m.getName().contains("handle")){
		        				  //this one is a little bit hard-coded, in order to abstract the call relation of EventHandler.handle
		        				  System.out.println(getMethodFullName(m) + " <= " + 
		        						  intfClass.getName()+":"+m.getReturnType().toString() + " handle("+intfClass.getPackageName()+".Event)");
		        			  }
		        		  }
		        	  }
		          }
		          System.out.println("------------add EventHandler end-------------");
		          for(SootMethod entryPoint : methods){
//		        	  Iterator<ContextSensitiveEdge> it = cscg.allEdges();
//		        	  while(it.hasNext()){
//		        		  ContextSensitiveEdge edge = (ContextSensitiveEdge) it.next();
//		        		  System.out.println( edge.src() + " => " + edge.tgt());
//		        	  }
		        	  //for each method
		        	  System.out.println("---------cfg start-------------");
		        	  if(entryPoint.hasActiveBody()){		        		  
		        		  List<Stmt> allStmt = MethodUtils.getMethodAllStmts(entryPoint.getActiveBody());
		        			for(Stmt stmt : allStmt){
		        				if(stmt.containsInvokeExpr()){
		        					InvokeExpr expression = stmt.getInvokeExpr();
		        					//JAssignStmt jassgnStmt = (JAssignStmt) stmt;
		        					//Value iteratorVar = jassgnStmt.leftBox.getValue();
		        					SootMethod invokedMethod = expression.getMethod();
		        					if(notCarePrefix || invokedMethod.getDeclaringClass().toString().contains(appPrefix)){
		        						System.out.println(getMethodFullName(invokedMethod) + " <= " + getMethodFullName(entryPoint));
		        						for(SootClass intfClass : invokedMethod.getDeclaringClass().getInterfaces()){
		        							if(intfClass.getName().contains("java.util.concurrent.Callable")){
		        								//<org.apache.hadoop.yarn.util.FSDownload: java.lang.Object call()>
		        								System.out.println("---------add callable start-----");
		        								System.out.println(invokedMethod.getDeclaringClass().toString()+":java.lang.Object call()" + " <= " + getMethodFullName(entryPoint));
		        								System.out.println("---------add callable end-----");
		        							}
		        						}
		        					}
		        				}
		        			}
		        		  
		        	  }
		        	  System.out.println("---------cfg end------------");
		        	  Iterator<MethodOrMethodContext> sources = new Sources(cg.edgesInto(entryPoint));
		        	  while (sources.hasNext()) {
		        		  SootMethod src = (SootMethod)sources.next();
		        		  if(notCarePrefix || src.getDeclaringClass().toString().contains(appPrefix)){
		        			  System.out.println(getMethodFullName(entryPoint) + " <= " + getMethodFullName(src));
		        		  }
		        	  }
//		        	  System.out.println("==========compare======");
		        	  Iterator<MethodOrMethodContext> targets = new Targets(cg.edgesOutOf(entryPoint));
		        	  while (targets.hasNext()) {
		        		  MethodOrMethodContext targetM = targets.next();
		        		  SootMethod tgt = (SootMethod)targetM;
		        		  //String tgtStr = targetM.toString();
		        		  if(notCarePrefix || tgt.getDeclaringClass().toString().contains(appPrefix)){
		        			  System.out.println(getMethodFullName(tgt) + " <= " + getMethodFullName(entryPoint));
      						for(SootClass intfClass : tgt.getDeclaringClass().getInterfaces()){
    							if(intfClass.getName().contains("java.util.concurrent.Callable")){
    								//<org.apache.hadoop.yarn.util.FSDownload: java.lang.Object call()>
    								System.out.println("---------add callable start-----");
    								System.out.println(tgt.getDeclaringClass().toString()+":java.lang.Object call()" + " <= " + getMethodFullName(entryPoint));
    								System.out.println("---------add callable end-----");
    							}
    						}
		        		  }
		        		  //System.out.println(tgtStr + " =String= is called by " + entryPoint);
		        	  }
//		        	  System.out.println("----------compare------");
//			          ReachableMethods reachableMethods = new ReachableMethods(cg, targets);
//			          QueueReader<MethodOrMethodContext> transitiveMethods = reachableMethods.listener();
//			          reachableMethods.update();
//			          System.out.println("Num transitive methods " + reachableMethods.size());
//			          while (transitiveMethods.hasNext()) {
//			        	  System.out.println(entryPoint + " may reach " + ((SootMethod)transitiveMethods.next()).getName());
//			          }
		        	  //print the reachable methods.(too many methods, might not be useful)
//		        	  	targets = new Targets(cg.edgesOutOf(entryPoint));
//		        	    ReachableMethods reachableMethods = new ReachableMethods(cg, targets, null);
//		        	    reachableMethods.update();
//		        	    for (Iterator<MethodOrMethodContext> iter = reachableMethods.listener(); iter.hasNext();) {
//		        	          SootMethod method = iter.next().method();
//		        	          System.out.println(method + " <=== " + entryPoint);
//		        	    }
		          }
		          
		          

//		          for(SootMethod entryPoint : methods){
//		        	  //System.out.println("--- start"); 
//		        	  Iterator<Edge> itIn = cg.edgesInto(entryPoint);
//			          while(itIn.hasNext()) { 
//			            Edge e = itIn.next(); 
//			            System.out.println( e.getSrc() + " => " + e.getTgt());
//			          }
//			          Iterator<Edge> itOut = cg.edgesOutOf(entryPoint);
//			          while(itOut.hasNext()) { 
//			            Edge e = itOut.next(); 
//			            System.out.println(e.getSrc() + " => " + e.getTgt());
//			          }
//			          //System.out.println("--- end");  
//		          }
		          
			} 
		}));
		soot.Main.main(args); 
		
//		PackManager.v().getPack("wjtp").add(new Transform("wjtp.myTrans",new SceneTransformer() {
//			@Override
//			protected void internalTransform(String phaseName, Map options) {
//				CHATransformer.v().transform();
//				Options.v().set_whole_program(true);
//				//Options.v().set_process_dir(Arrays.asList(libDir)); //library dir
//				//Options.v().set_soot_classpath("../rt.jar:"+libDir+":../jce.jar:.");//library dir along with rt.jar/jce.jar from JRE/JDK
//				
//				Scene.v().setEntryPoints(getAllMethods(args));
//				Scene.v().loadNecessaryClasses();
//				PackManager.v().getPack("wjtp").apply();
//
//				//use call graph:
//				
//				SootClass klass = Scene.v().getSootClass(args[args.length-1]);
//				//SootMethod method = klass.getMethodByName(someMethodYouAreInterested);
//				CallGraph cg = Scene.v().getCallGraph();
//				for(SootMethod entryPoint : Scene.v().getEntryPoints()){
//				Iterator<MethodOrMethodContext> sources = new Sources(cg.edgesInto(entryPoint));
//					while (sources.hasNext()) {
//						SootMethod src = (SootMethod)sources.next();
//				    	System.out.println(entryPoint + " is called by " + src);
//					}
//				}
//			}
//		}));
//		soot.Main.main(args); 
				
	} 
	
	public static String getMethodFullName(SootMethod method){
		String classname = method.getDeclaringClass().getName();
		// use signature instead to avoid same-name functions
		String methodname = method.getSubSignature(); 
		return classname + ":" + methodname;
	}
	
    public static String getPrex(String[] args) {
    	String klassName = args[args.length-1];
    	String[] splitK = klassName.split(".");
    	String prefix = "";
    	prefix = splitK[0] + "." + splitK[1] + "." + splitK[2]; //hard-coded, only choose the first 3 substring
        return prefix;
    }
    
    public static List<SootMethod> getAllMethods(String[] args) {
    	String klassName = args[args.length-1];
        ArrayList<SootMethod> entrypoints = new ArrayList<SootMethod>();
        //for (String klassName : allClasses) {
            // klassName such as org.abc.MyClass
            Scene.v().forceResolve(klassName, SootClass.SIGNATURES);
            //Scene.v().forceResolve(klassName, SootClass.HIERARCHY);
            //Scene.v().forceResolve(klassName, SootClass.BODIES | SootClass.HIERARCHY | SootClass.SIGNATURES);
            SootClass klass = Scene.v().getSootClass(klassName);
            // adding all non-abstract method as entrypoint
            for (SootMethod m : klass.getMethods()) {
              if (!m.isAbstract()) {
                entrypoints.add(m);
              }
            }
         // }
        
        return entrypoints;
    }
    
    private static void setSparkAnalysis() {
        HashMap<String,String> opt = new HashMap<String,String>();
        opt.put("enabled","true");
        opt.put("verbose","false");
        opt.put("vta","true");
        opt.put("on-fly-cg","true");
        opt.put("set-impl","double");
        opt.put("double-set-old","hybrid");
        opt.put("propagator", "iter");
        opt.put("double-set-new","hybrid");

        SparkTransformer.v().transform("",opt);
    }

    /*causing overhead*/
    public static void setSparkAnalysisPTA() {
    	HashMap<String,String> opt = new HashMap<String,String>();
    	opt.put("geom-pta","true");
    	opt.put("geom-encoding", "geom");
    	opt.put("geom-worklist", "PQ");
    	opt.put("geom-eval", "0");
    	opt.put("geom-trans", "false");
    	opt.put("geom-frac-base", "40");
    	opt.put("geom-blocking", "true");
    	opt.put("geom-runs", "1");
    	opt.put("enabled","true");
    	opt.put("verbose","false");
    	opt.put("ignore-types","true");
    	opt.put("force-gc","false");
    	opt.put("pre-jimplify","false");
    	opt.put("vta","false");
    	opt.put("rta","false");
    	opt.put("field-based","false");
    	opt.put("types-for-sites","false");
    	opt.put("merge-stringbuffer","false");
    	opt.put("string-constants","true");
    	opt.put("simulate-natives","true");
    	opt.put("simple-edges-bidirectional","false");
    	opt.put("on-fly-cg","true");
    	opt.put("simplify-offline","false");
    	opt.put("simplify-sccs","false");
    	opt.put("ignore-types-for-sccs","false");
    	opt.put("propagator","worklist");
    	opt.put("set-impl","double");
    	opt.put("double-set-old","hybrid");
    	opt.put("double-set-new","hybrid");
    	opt.put("dump-html","false");
    	opt.put("dump-pag","false");
    	opt.put("dump-solution","false");
    	opt.put("topo-sort","false");
    	opt.put("dump-types","true");
    	opt.put("class-method-var","true");
    	opt.put("dump-answer","false");
    	opt.put("add-tags","false");
    	opt.put("set-mass","false");
    	SparkTransformer.v().transform("",opt);
    }
} 
