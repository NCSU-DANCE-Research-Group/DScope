import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;


public class splitOverrideInputStreams {
	private static String ipsFile="";
	private static String outputFile="";
	private static Map<String, List<String>> IPScallee = new HashMap<String, List<String>>();
	private static List<String> notOverrideIPS = new ArrayList<String>();
	private static List<String> overrideIPS = new ArrayList<String>();
	
	public static void main(String[] args){
		String argsManual[] = {
				"-ipsFile", "/home/ting/DataLoopBugDetection/testsuite_reduceFP/appIPSclass.filter2.log",
				"-outputFile", "/home/ting/DataLoopBugDetection/testsuite_reduceFP/appIPSclass.notOverride.log"
				};
		handleArgs(args);
		readFile(ipsFile);
		
		//considering the overridden parent
		//10 loops should be exhausted enough to extract the subclasses relations
		for(int i = 0; i < 10; i++){
			extractAllIPS();
		}
		System.out.println("after considering the overriden parent:");
		System.out.println("overrideIPS.size = " + overrideIPS.size() + "\tnotOverrideIPS.size = " + notOverrideIPS.size());
//		System.out.println("overrideIPS = " + overrideIPS);
//		System.out.println("notOverrideIPS = " + notOverrideIPS);
		
		//considering the overriden child
		extracAllIPS2();
		System.out.println("after considering the overriden child:");
		System.out.println("overrideIPS.size = " + overrideIPS.size() + "\tnotOverrideIPS.size = " + notOverrideIPS.size());
//		System.out.println("overrideIPS = " + overrideIPS);
//		System.out.println("notOverrideIPS = " + notOverrideIPS);
		
		addExtraIPS();
		System.out.println("after add all the not overriden java IPS:");
		System.out.println("overrideIPS.size = " + overrideIPS.size() + "\tnotOverrideIPS.size = " + notOverrideIPS.size());
		outputNotOverrideIPS();
	}
	
	
	
	private static void readFile(String filename){
		InputStream instream = null;
		BufferedReader reader = null;
		String line = "";
		try {
			instream = new FileInputStream(filename);
			reader = new BufferedReader(new InputStreamReader(instream));
			while ((line = reader.readLine()) != null) {
				if(!line.startsWith("#")){
					String[] splitStr = line.split(":");
					String ipsName = splitStr[0];
					String isOverride = splitStr[1];
					String parentName = splitStr[2];
					//at first, add all the parent into the notOverride list
					if(!notOverrideIPS.contains(parentName)){
						notOverrideIPS.add(parentName);
					}
					if(IPScallee.containsKey(parentName)){
						List<String> callees = IPScallee.get(parentName);
						if(!callees.contains(ipsName)){
							callees.add(ipsName);
						}
						IPScallee.put(parentName, callees);
					} else {
						List<String> callees = new ArrayList<String>();
						callees.add(ipsName);
						IPScallee.put(parentName, callees);
					}
					if(isOverride.equalsIgnoreCase("Y")){
						overrideIPS.add(ipsName);
					} else{
						notOverrideIPS.add(ipsName);
					}
				}
			}
		} catch (Exception e) {
//			logger.severe("Exception: " + e.toString());
			e.printStackTrace();
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	private static void addExtraIPS(){
		String[] javaIPSarray = new String[]{"java.io.InputStream","java.io.DataInputStream","java.io.FilterInputStream",
				"java.io.BufferedInputStream","java.io.LineNumberInputStream","java.io.PipedInputStream",
				"java.io.SequenceInputStream","java.io.ByteArrayInputStream","java.io.FileInputStream",
				"java.io.ObjectInputStream","java.io.PushbackInputStream","java.io.StringBufferInputStream",
				"java.io.RandomAccessFile"};
//		System.out.println(overrideIPS);
		for(String javaIPS : javaIPSarray){
			if(!overrideIPS.contains(javaIPS) && !notOverrideIPS.contains(javaIPS)){
				notOverrideIPS.add(javaIPS);
			}
		}
	}
	
	//if parent is override, but the child is not override, then the child becomes override
	//then search child's child
	private static void extractAllIPS(){
		List<String> tempAdded = new ArrayList<String>();
		for(String overIPS : overrideIPS){
			if(IPScallee.containsKey(overIPS)){
				List<String> callees = IPScallee.get(overIPS);
				for(String callee : callees){
					if(notOverrideIPS.contains(callee)){
						notOverrideIPS.remove(callee);
						tempAdded.add(callee);
					}
				}
			}
		}
		overrideIPS.addAll(tempAdded);
	}
	
	//if all the child IPS classes are not overridden, then it means that this parent IPS class is not overriden.
	//e.g., POI-61300, IOUtils.copy(InputStream ips,...), this ips can be java.io.InputStream 
	// or the subclasses, e.g., org.apache.poi.poifs.filesystem.DocumentInputStream
	private static void extracAllIPS2(){
		List<String> tempDel = new ArrayList<String>();
		for(String notoverIPS : notOverrideIPS){
			if(IPScallee.containsKey(notoverIPS)){
				List<String> callees = IPScallee.get(notoverIPS);
				for(String callee : callees){
					if(overrideIPS.contains(callee)){
						overrideIPS.add(notoverIPS);
						tempDel.add(notoverIPS);
						break;
					}
				}
			}
		}
//		System.out.println("tempDel = " + tempDel);
//		for(String delIPS : tempDel){
//			notOverrideIPS.remove(delIPS);
//		}
		notOverrideIPS.removeAll(tempDel);
	}
	
	private static void outputNotOverrideIPS(){
		File outfile = new File(outputFile);
	    if (outfile.exists()) {
	    	outfile.delete();     
	    }
	    
	    String printStr = "";
	    for(String outputIPS : notOverrideIPS){
	    	printStr += outputIPS + "\n";
	    }
	    
		write2File(outputFile, printStr);
		
	}
	
	private static void write2File(String filename, String content){
		File fout = new File(filename);
		FileOutputStream fos = null;
		BufferedWriter bw = null;
		try {
			fos = new FileOutputStream(fout, true);
			bw = new BufferedWriter(new OutputStreamWriter(fos));
			bw.write(content);
			bw.flush();
			fos.close();
			bw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
    public static void handleArgs(String[] args)
    {
        int argIndex = 0;
        boolean hasSrc = false;
        boolean hasOutput = false;
        while(argIndex < args.length)
        {
            String current = args[argIndex];
            if(current.compareTo("-h") == 0)
            {
                printUsage();
                System.exit(-1);
            }else if(current.compareTo("-ipsFile") == 0)
            {
                argIndex++;
                ipsFile = args[argIndex];
                hasSrc = true;
            }
            else if(current.compareTo("-outputFile") == 0)
            {
                argIndex++;
                outputFile = args[argIndex];
                hasOutput = true;
            }
            else
            {
                System.out.println("current arg:" + current);
                System.out.println("Invalid configuration params, use -h for usage");
                System.exit(-1);
            }
            argIndex++;
        }
        if(!(hasSrc && hasOutput)){
        	printUsage();
        	System.exit(-1);
        }
    }
    
    public static void printUsage()
    {
    	System.out.println("Valid options are:");
        System.out.println("java splitOverrideInputStreams -ipsFile -outputFile outputFile");
    }
}
