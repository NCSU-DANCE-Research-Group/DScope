
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.logging.Logger;
import java.util.regex.PatternSyntaxException;

import datastruct.DiGraphMatrix;
import datastruct.Graph;
//import datastruct.MultiTree;

public class linkCGsfromClasses {
	static String analysisPath = "";
	static String startClass = "";
	static Map<String, Integer> function2ID = new HashMap<String, Integer>();
	static int funcID = 0;
	static List<Integer> focusedCLFuncs = new ArrayList<Integer>();
	static Map<Integer, List<Integer>> functionCG = new HashMap<Integer, List<Integer>>();
	static List<List<Integer>> mergedFuncCG = new ArrayList<List<Integer>>();
	static List<String> files = new ArrayList<String>();
	public static Logger logger = Logger.getLogger(linkCGsfromClasses.class.getName());
	static Graph<Integer> callRs;
	
	public static void main(String[] args){
		args = new String[] {"-path", 
				             "/home/ting/DataLoopBugDetection/soot-soot-2.5.0/hadoop.0.23.cg", 
				             "-class", 
				             "org.apache.hadoop.yarn.server.nodemanager.containermanager.localizer.ResourceLocalizationService"};
		handleArgs(args);
		processCGinClass();
		
	}
	
	public static void processCGinClass(){
		if(analysisPath != null && analysisPath != ""){
			File folder = new File(analysisPath);
			File[] listofFiles = folder.listFiles();
			for(File file : listofFiles){
			    if (file.isFile()) {
			        files.add(file.getName());
			    }
			}
			//if(files.contains(startClass+".txt")){
			for(String file : files){
				logger.info("start processing " + file + " ...");
				InputStream instream = null;
				BufferedReader reader = null;
				String line = "";
				try {
					instream = new FileInputStream(analysisPath+"/"+file);
					reader = new BufferedReader(new InputStreamReader(instream));
					while ((line = reader.readLine()) != null) {
						if(line.contains(" <= ")){
							processEachLine(line);
						} else{
							continue;
						}
					}
				} catch (Exception e) {
					logger.severe("Exception: " + e.toString());
				} finally {
					try {
						reader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				logger.info("finish processing " + file + " ...");
				//System.out.println(function2ID);
				//System.out.println(functionCG);
				//printCGmap();
			}
			logger.info("start creating callgraph matrix...");
			createCGMatrix();
//			System.out.println(funcID);
//			System.out.println(functionCG);
//			System.out.println(function2ID);
			logger.info("finish creating callgrapgh matrix...");
			//callRs.printMatrix();
			logger.info("start identifying caller functions...");
			identifyBuggyFunctions();
			//testingset();
			//testingget();
			logger.info("finish identifying caller functions...");
			
		}
	}
	
	public static void testingset(){
		String funcupdate="org.apache.hadoop.yarn.server.nodemanager.containermanager.localizer.ResourceLocalizationService$LocalizerRunner:org.apache.hadoop.yarn.server.nodemanager.api.protocolrecords.LocalizerHeartbeatResponse update(java.util.List)";
		int funcupdateID=processFuncString(funcupdate);
		System.out.println("update = " + funcupdateID);
		
		String funcfindNextResource="org.apache.hadoop.yarn.server.nodemanager.containermanager.localizer.ResourceLocalizationService$LocalizerRunner:org.apache.hadoop.yarn.api.records.LocalResource findNextResource()";
		int funcfindNextResourceID=processFuncString(funcfindNextResource);
		System.out.println("findNextResource = " + funcfindNextResourceID);
		
		String funcset="org.apache.hadoop.yarn.api.records.LocalResource:void setTimestamp(long)";
		int funcsetID = processFuncString(funcset);
		System.out.println("setTimestamp = " + funcsetID);
		
		String funcprocessHeartbeat="org.apache.hadoop.yarn.server.nodemanager.containermanager.localizer.ResourceLocalizationService$LocalizerTracker:org.apache.hadoop.yarn.server.nodemanager.api.protocolrecords.LocalizerHeartbeatResponse processHeartbeat(org.apache.hadoop.yarn.server.nodemanager.api.protocolrecords.LocalizerStatus)";
		int funcprocessHeartbeatID = processFuncString(funcprocessHeartbeat);
		System.out.println("processHeartbeat = " + funcprocessHeartbeatID);
		
		String funchearBeat="org.apache.hadoop.yarn.server.nodemanager.containermanager.localizer.ResourceLocalizationService:org.apache.hadoop.yarn.server.nodemanager.api.protocolrecords.LocalizerHeartbeatResponse heartbeat(org.apache.hadoop.yarn.server.nodemanager.api.protocolrecords.LocalizerStatus)";
		int funchearBeatID = processFuncString(funchearBeat);
		System.out.println("hearBeat = " + funchearBeatID);
		
//		System.out.println(callRs.containsEdge(funcfindNextResourceID, funcsetID));
//		System.out.println(funcfindNextResourceID + " can reach " + funcsetID + ": " + callRs.isreachable(funcfindNextResourceID, funcsetID));
//		System.out.println(callRs.containsEdge(funcupdateID, funcfindNextResourceID));
//		System.out.println(funcupdateID + " can reach " + funcfindNextResourceID + ": " + callRs.isreachable(funcupdateID, funcfindNextResourceID));
//		System.out.println(callRs.containsEdge(funcprocessHeartbeatID, funcupdateID));
//		System.out.println(funcprocessHeartbeatID + " can reach " + funcupdateID + ": " + callRs.isreachable(funcprocessHeartbeatID, funcupdateID));
		//System.out.println(callRs.BFS(funcsetID));
		List<Integer> reachable = callRs.BFS(funcsetID);
		System.out.println(reachable);
		
		
//		Map<Integer, Integer> lookup = callRs.getLookUp();
//		System.out.println(getKeyByValue(lookup,funcsetID));
//		System.out.println(getKeyByValue(lookup,funcfindNextResourceID));
//		System.out.println(getKeyByValue(lookup,funcprocessHeartbeatID));
//		System.out.println(getKeyByValue(lookup,funcupdateID));
//		System.out.println(reachable[funcupdateIndex]);
//		System.out.println(reachable[funcfindNextResourceID]);
//		System.out.println(reachable[funcprocessHeartbeatID]);
	}
	
	public static void testingget(){
		String funcget="org.apache.hadoop.yarn.api.records.LocalResource:long getTimestamp()";
		int funcgetID=processFuncString(funcget);
		System.out.println("getTimestamp = " + funcgetID);
		
		String funccopy= "org.apache.hadoop.yarn.util.FSDownload:org.apache.hadoop.fs.Path copy(org.apache.hadoop.fs.Path,org.apache.hadoop.fs.Path)";
		int funccopyID=processFuncString(funccopy);
		System.out.println("copy = " + funccopyID);
		
		String funccall="org.apache.hadoop.yarn.util.FSDownload:org.apache.hadoop.fs.Path call()";
		int funccallID=processFuncString(funccall);
		System.out.println("call = " + funccallID);
		
		String funcObjcall="org.apache.hadoop.yarn.util.FSDownload:java.lang.Object call()";
		int funcObjcallID=processFuncString(funcObjcall);
		System.out.println("obj call = " + funcObjcallID);
		
		String funcaddResource="org.apache.hadoop.yarn.server.nodemanager.containermanager.localizer.ResourceLocalizationService$PublicLocalizer:void addResource(org.apache.hadoop.yarn.server.nodemanager.containermanager.localizer.event.LocalizerResourceRequestEvent)";
		int funcaddResourceID=processFuncString(funcaddResource);
		System.out.println("addResource = " + funcaddResourceID);
		
		String funchandle="org.apache.hadoop.yarn.server.nodemanager.containermanager.localizer.ResourceLocalizationService$LocalizerTracker:void handle(org.apache.hadoop.yarn.server.nodemanager.containermanager.localizer.event.LocalizerEvent)";
		int funchandleID=processFuncString(funchandle);
		System.out.println("handle = " + funchandleID);
		
		String funchandleinit="org.apache.hadoop.yarn.server.nodemanager.containermanager.localizer.ResourceLocalizationService:void handleInitApplicationResources(org.apache.hadoop.yarn.server.nodemanager.containermanager.application.Application)";
		int funchandleinitID=processFuncString(funchandleinit);
		System.out.println("handleInitApplicationResources = " + funchandleinitID);
		
		List<Integer> reachable = callRs.BFS(funcgetID);
		System.out.println(reachable);
		
	}
	
	public static void identifyBuggyFunctions(){
		String function1="org.apache.hadoop.yarn.api.records.LocalResource:long getTimestamp()";
		int funcID1 = processFuncString(function1);
//		System.out.println(funcID1);
		List<Integer> reachable1 = callRs.BFS(funcID1);
		
		String function2="org.apache.hadoop.yarn.api.records.LocalResource:void setTimestamp(long)";
		int funcID2 = processFuncString(function2);
//		System.out.println(funcID2);
		List<Integer> reachable2 = callRs.BFS(funcID2);
		
//		String testingFunc="org.apache.hadoop.yarn.server.nodemanager.containermanager.localizer.ResourceLocalizationService$LocalizerRunner:org.apache.hadoop.yarn.api.records.LocalResource findNextResource()";
//		int funcTestID = processFuncString(testingFunc);
//		System.out.println(funcTestID);
//		System.out.println(callRs.isreachable(funcTestID, funcID2));
		System.out.println(focusedCLFuncs);
		List<String> func1Caller = new ArrayList<String>();
		List<String> func2Caller = new ArrayList<String>();
		for(int focusID : focusedCLFuncs){
			//System.out.println(focusID);
			if(reachable1.contains(focusID)){
				String callerName = getKeyByValue(function2ID, focusID);
				func1Caller.add(callerName);
			}
			if(reachable2.contains(focusID)){
				String callerName = getKeyByValue(function2ID, focusID);
				func2Caller.add(callerName);
			}
		}
		System.out.println("getTimestamp <= " + func1Caller);
		System.out.println("setTimestamp <= " + func2Caller);
		
	}
	
	public static void createCGMatrix(){
		List<Integer> v = new ArrayList<Integer>();
		for(Object obj : function2ID.values().toArray()){
			int id = (int) obj;
			v.add(id);
		}
		callRs = new DiGraphMatrix<Integer>(v);
		Iterator<Entry<Integer, List<Integer>>> it = functionCG.entrySet().iterator();
		Entry<Integer,List<Integer>> entry = null;
		while(it.hasNext()){
			entry = it.next(); 
			int callerID = entry.getKey();
//			if(focusedCLFuncs.contains(callerID))
			for(int calleeID : entry.getValue()){
				callRs.addEdge(callerID, calleeID);
			}
		}
		//return callRs;
	}
	
//	public static void DFS(int callerID, List<List<Integer>> callLists){
//		if(functionCG.containsKey(callerID)){
//			for(int callee : functionCG.get(callerID)){
//				DFS(callee);
//			}
//		}
//	}
	
//	public static void printCGmap(){
//		Iterator<Entry<Integer, List<Integer>>> it = functionCG.entrySet().iterator();
//		Entry<Integer,List<Integer>> entry = null;
//		while(it.hasNext()){
//			entry = it.next();
//			int callerID = entry.getKey();
//			List<Integer> calleeIDs = entry.getValue();
//			String callerName = getFuncFullName(getKeyByValue(function2ID, callerID));
//			String calleeNames = "";
//			for(Integer calleeID : calleeIDs){
//				calleeNames += getFuncFullName(getKeyByValue(function2ID, calleeID)) + ",";
//			}
//			System.out.println(callerName + "=>" + calleeNames);
//		}
//	}
	
	//get the first key from the matched value
	public static <T, E> T getKeyByValue(Map<T, E> map, E value) {
	    for (Entry<T, E> entry : map.entrySet()) {
	        if (Objects.equals(value, entry.getValue())) {
	            return entry.getKey();
	        }
	    }
	    return null;
	}
	
	public static String getFuncFullName(funcPair pair){
		return pair.getReturn().toString() 
				+ " " 
				+ pair.getClassName().toString() 
				+ "." 
				+ pair.getFuncName(); 
	}
	
	
	public static void processEachLine(String line){
		String[] splitLine = line.split(" <= ");
		//org.apache.hadoop.yarn.server.nodemanager.containermanager.localizer.LocalResourcesTrackerImpl:void <init>(java.lang.String,org.apache.hadoop.yarn.event.Dispatcher) 
		//<= 
		//org.apache.hadoop.yarn.server.nodemanager.containermanager.localizer.ResourceLocalizationService:void <init>(org.apache.hadoop.yarn.event.Dispatcher,org.apache.hadoop.yarn.server.nodemanager.ContainerExecutor,org.apache.hadoop.yarn.server.nodemanager.DeletionService)
		String caller = splitLine[1];
		String callee = splitLine[0];
		int callerID = processFuncString(caller);
		int calleeID = processFuncString(callee);
		if(functionCG.containsKey(callerID)){
			List<Integer> calleeList = functionCG.get(callerID);
			if(!calleeList.contains(calleeID)){
				calleeList.add(calleeID);
				functionCG.put(callerID, calleeList);
			}
		} else {
			List<Integer> calleeList = new ArrayList<Integer>();
			calleeList.add(calleeID);
			functionCG.put(callerID, calleeList);
		}
		
	}
	
	public static int processFuncString(String function){
		//org.apache.hadoop.yarn.server.nodemanager.containermanager.localizer.LocalResourcesTrackerImpl:void <init>(java.lang.String,org.apache.hadoop.yarn.event.Dispatcher) 
		//logger.info("start processFuncString " + function);
		String classname = "";
		String retStr = "";
		String funcName = "";
		try{
			String[] splitFunc = function.split(":");
			classname = splitFunc[0];
			String[] splitFunc2 = splitFunc[1].split(" ");
			retStr = splitFunc2[0];
			funcName = splitFunc2[1];
		} catch (PatternSyntaxException e){
			e.printStackTrace();
		}
//		funcPair<String, String, String> newPair = new funcPair<String, String, String>(classname, funcName, retStr);
		if(function2ID.containsKey(function)){
			return function2ID.get(function);
		} else {
			function2ID.put(function, funcID);
			funcID++;
			if(classname.equals(startClass)){
				focusedCLFuncs.add(funcID-1); //focus on the functions that in startClass class.
			}
			return funcID-1;
		}
	}
	
	
	public static void handleArgs(String []args)
    {
        int argIndex = 0;
        while(argIndex < args.length)
        {
            String current = args[argIndex];
            if(current.compareTo("-h") == 0)
            {
                printUsage();
                System.exit(-1);
            } else if(current.compareTo("-path") == 0){
            	argIndex++;
            	analysisPath = args[argIndex];
            } else if(current.compareTo("-class") == 0){
            	argIndex++;
            	startClass = args[argIndex];
            }
            else
            {
                System.out.println("current arg:" + current);
                System.out.println("Invalid configuration params, use -h for usage");
                System.exit(-1);
            }
            argIndex++;
        }
    }
	
    public static void printUsage()
    {
        System.out.println("java linkCGsfromClasses [options] -path analysisPath -class analysisClass");
        System.out.println("Valid options are:");
        System.out.println("-h print help and exit");
    }
    
}


class funcPair<F, S, T> {
    private F var1;
    private S var2;
    private T var3;

    public funcPair(F var1, S var2, T var3) {
        this.var1 = var1;
        this.var2 = var2;
        this.var3 = var3;
    }

    public F getClassName() {
        return var1;
    }
    
    public S getFuncName(){
    	return var2;
    }
    
    public T getReturn() {
        return var3;
    }
    
}
